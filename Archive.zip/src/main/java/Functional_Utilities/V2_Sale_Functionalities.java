package Functional_Utilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Number;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Kafka_Utilities.send_Kafka_Message;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;


public class V2_Sale_Functionalities {

    protected static final Logger logger = get_Logger();


    @Step
    public static JsonObject Post_Return(JsonObject got_Data) throws Exception {

        JsonObject return_Data           = new JsonObject();
        JsonObject pass_Data             = new JsonObject();
        String     raw_Payload           = "";
        if (got_Data.has(Reference_Payload))
            raw_Payload = parse_And_Generate_Data(got_Data.get(Reference_Payload).getAsString(), got_Data);
        else
            raw_Payload = got_Data.get(Reference_Payload_Updated).getAsString();

        logger.info("raw_Payload for Return $$$ :" + raw_Payload);

        /*@Remove TODO What are we doing here ?*/
        got_Data.addProperty(Rule_Replace_Transaction_Type_Code, Rule_Replace_Transaction_Type_Code_Return);
        /*@Remove TODO What are we doing here ?*/
        pass_Data.addProperty(Kafka_Topic_name, "MKTG_RETURN");
        pass_Data.addProperty(Kafka_Message_Body, raw_Payload);
        pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom());//Just like that some random key //@TEAM Todo - what do we need

        return_Data = send_Kafka_Message(pass_Data);


        return return_Data;
    }

    @Step
    public static JsonObject Post_Sales(JsonObject got_Data) throws Exception {

        /*Todo Remove Below  @TEAM*/
        JsonObject pass_Data             = new JsonObject();

        String     raw_Payload           = "";
        if (got_Data.has(Reference_Payload))
            raw_Payload = parse_And_Generate_Data(got_Data.get(Reference_Payload).getAsString(), got_Data);
        else
            raw_Payload = got_Data.get(Reference_Payload_Updated).getAsString();


        logger.info("raw_Payload for Sale $$$ :" + raw_Payload);

        pass_Data.addProperty(Kafka_Topic_name, "MKTG_SALE");
        pass_Data.addProperty(Kafka_Message_Body, raw_Payload);
        pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom()); //Just like that some random key //@TEAM Todo - what do we need here for testing?

        JsonObject return_Data = send_Kafka_Message(pass_Data);


        return return_Data;
    }

    @Step
    public static JsonObject Post_Adjustment(JsonObject got_Data) throws Exception {

        JsonObject return_Data           = new JsonObject();
        JsonObject pass_Data             = new JsonObject();

        String raw_Payload = "";
        if (got_Data.has(Reference_Payload))
            raw_Payload = parse_And_Generate_Data(got_Data.get(Reference_Payload).getAsString(), got_Data);
        else
            raw_Payload = got_Data.get(Reference_Payload_Updated).getAsString();

        logger.info("raw_Payload for Adjustment $$$ :" + raw_Payload);

        got_Data.addProperty(Rule_Replace_Transaction_Type_Code, Rule_Replace_Transaction_Type_Code_Return);
        pass_Data.addProperty(Kafka_Topic_name, "MKTG_ADJUSTMENT");
        pass_Data.addProperty(Kafka_Message_Body, raw_Payload);
        pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom());

        return_Data = send_Kafka_Message(pass_Data);


        return return_Data;
    }


    @Step
    public static JsonObject Post_Void(JsonObject got_Data) throws Exception {

        JsonObject return_Data           = new JsonObject();
        JsonObject pass_Data             = new JsonObject();
        String     payload_reference_Key = got_Data.get(Reference_Payload).getAsString();
        /*@Remove TODO  ... Specific Data Use it per scenario not here.*/
        got_Data.addProperty(Rule_Replace_Transaction_Type_Code, Rule_Replace_Transaction_Type_Code_Void);

        String raw_Payload = "";
        if (got_Data.has(Reference_Payload))
            raw_Payload = parse_And_Generate_Data(payload_reference_Key, got_Data);
        else
            raw_Payload = got_Data.get(Reference_Payload_Updated).getAsString();

        logger.info("raw_Payload for Post Void $$$ :" + raw_Payload);

        pass_Data.addProperty(Kafka_Topic_name, "MKTG_VOID");
        pass_Data.addProperty(Kafka_Message_Body, raw_Payload);
        pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom());//Just like that some random key //@TEAM Todo - what do we need

        return_Data = send_Kafka_Message(pass_Data);

        return return_Data;
    }


    public static JsonObject Post_Event(JsonObject got_Data) throws Exception {

        JsonObject pass_Data   = new JsonObject();
        String     raw_Payload = null;

        if (got_Data.has(Reference_Payload))
            raw_Payload = parse_And_Generate_Data(got_Data.get(Reference_Payload).getAsString(), got_Data);
        else
            raw_Payload = got_Data.get(Reference_Payload_Updated).getAsString();


        pass_Data.addProperty(Kafka_Topic_name, "MKTG_LOYALTY_EVENT");
        pass_Data.addProperty(Kafka_Message_Body, raw_Payload);
        pass_Data.addProperty(Kafka_Message_Key, generate_Random_Number(12));//Just like that some random key //@TEAM Todo - what do we need

        return send_Kafka_Message(pass_Data);

    }


    /*@Remove Check for Valid barcode Logic  ask QA*/
    @Step
    public static String get_Valid_Barcode(String current_Sale, JsonObject got_Data) throws Exception {

//        String                  sql_To_Execute_ref = got_Data.get(Reference_SQL).getAsString();
//        String                  sql_To_Execute     = consolidated_Sql.get(sql_To_Execute_ref).getAsString();
        String                  barcode = "";
        ArrayList<List<String>> sql_Result;
        if (current_Sale.toLowerCase().contains("62486")) {
            barcode = "62486";
        }
        if (current_Sale.toLowerCase().contains("62487")) {
            barcode = "62487";
        }
        if (current_Sale.toLowerCase().contains("62485")) {
            barcode = "62485";
        }
        String barcode_Swap = "";

        barcode_Swap = barcode + generate_Random_Number(10);
        /*why @Removed who commented This TODO*/
        /*for (int i = 0; i < 500; i++) {
            barcode_Swap = barcode + generate_Random_Number(10);
            String sql_To_Execute_Swap = sql_To_Execute.replace("Replace_Bar_Code", barcode_Swap);
            sql_Result = execute_SQL_MySQL_DB_CRUD(sql_To_Execute_Swap);
            if (sql_Result.size() == 0) {
                i = 9999999;
            }
        }*/

        int pos = current_Sale.indexOf("ReplaceBarcode");
        if (current_Sale.toLowerCase().contains("62486")) {
            return new StringBuffer(current_Sale).replace(pos, pos + 19, barcode_Swap).toString();
        }
        if (current_Sale.toLowerCase().contains("62487")) {
            return new StringBuffer(current_Sale).replace(pos, pos + 19, barcode_Swap).toString();
        }
        if (current_Sale.toLowerCase().contains("62485")) {
            return new StringBuffer(current_Sale).replace(pos, pos + 19, barcode_Swap).toString();
        }

        throw new Exception("Cant find barcode for which event id we are using? 62485/6/7");

    }


    public static ArrayList<String> get_TransactionValues_From_SaleMessage(JsonObject kafkaJsonResponse) {
        ArrayList<String> send_This = new ArrayList<String>();

        JsonObject kafka_Sale_Body      = convert_String_To_JsonObject(kafkaJsonResponse.get("Kafka_Message_Body").getAsString());
        JsonObject kafka_Message_Header = kafka_Sale_Body.get("messageHeader").getAsJsonObject();
        JsonArray  coupons_Array        = null;
        JsonObject coupons              = null;

        JsonObject message_Body = kafka_Sale_Body.get("messageBody").getAsJsonObject();

        JsonObject transaction_Key = message_Body.get("transactionKey").getAsJsonObject();
        send_This.add(transaction_Key.get("transactionNbr").getAsString());
        send_This.add(transaction_Key.get("storeNbr").getAsString());
        send_This.add(transaction_Key.get("registerId").getAsString());
        send_This.add(transaction_Key.get("transactionDate").getAsString());
        send_This.add(transaction_Key.get("transactionTime").getAsString());
        send_This.add(kafka_Message_Header.get("messageId").getAsString());

        if (kafkaJsonResponse.toString().contains("barcode")) {
            if (message_Body.has("coupons")) {
                coupons_Array = kafka_Sale_Body.get("messageBody").getAsJsonObject().get("coupons").getAsJsonArray();
                coupons = coupons_Array.get(0).getAsJsonObject();
                send_This.add(coupons.get("barcode").getAsString());
            }
        }
        return send_This;
    }

    public static String get_TransactionId_From_SaleMessage(JsonObject kafkaJsonResponse) {

        Assert.assertFalse(kafkaJsonResponse.isJsonNull());
        ArrayList<String> aa               = get_TransactionValues_From_SaleMessage(kafkaJsonResponse);
        String            tx_Number        = aa.get(0);
        String            store_Number     = aa.get(1);
        String            register_Id      = aa.get(2);
        String            transaction_Date = aa.get(3);
        String            transaction_Time = aa.get(4);

        //logger.info(tx_Number + "-S" + store_Number + "R" + register_Id + "T" + StringUtils.remove(transaction_Date, "-") + StringUtils.remove(transaction_Time, ':'));

        return tx_Number + "-S" + store_Number + "R" + register_Id + "T" + transaction_Date.replace("-", "") + transaction_Time.replace(":", "");
        //return tx_Number + "-S" + store_Number + "R" + register_Id + "T" + StringUtils.remove(transaction_Date, "-") + StringUtils.remove(transaction_Time, ':');


    }

}
