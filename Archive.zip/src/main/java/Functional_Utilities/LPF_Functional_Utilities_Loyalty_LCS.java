package Functional_Utilities;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.log4j.Logger;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Method_Get;

public class LPF_Functional_Utilities_Loyalty_LCS {

    protected static final Logger logger = get_Logger();


    public static void main(String[] args) {
        //String zaa = generate_Random_Character(4);
        //String  zaa = generate_Random_Number(5);
        //logger.info(zaa);
        String sss = generate_Random_Number(10);
        logger.info(sss);
    }


    public static String generateLoyaltyId() {

        int        n = 0;
        BigInteger i;
        do {
            Random r = new Random();
            i = new BigInteger("81");
            n = (int) (r.nextDouble() * 999999999);
            logger.info("loyalty  id" + i + "" + n + "  length   " + (i + "" + n).length());
        } while ((i + "" + n).length() != 11);
        return i + "" + n + "";
    }

    public static String generateLoyaltyIdRandom() {

        String loyaltyid = "711"; //Todo
        Random r         = new Random();
        int    numbers   = 10000000 + (int) (r.nextFloat() * 8999000);
        //logger.info("loyalty id" + loyaltyid + numbers + "");
        return loyaltyid + numbers + "";

    }

    @Deprecated /*Todo check @Team*/
    public static String generatetransactionId() {

        String transactionid = "7"; //Todo
        Random r             = new Random();
        int    numbers       = 100 + (int) (r.nextFloat() * 99);
        //logger.info("transaction id" + transactionid + numbers + "");
        return transactionid + numbers;

    }

    @Deprecated /*Todo check @Team*/
    public static String generatebarcode() {

        String barcode = "12345";   //Todo
        Random r       = new Random();
        int    numbers = 1000000000 + (int) (r.nextFloat() * 899990000);
        logger.info("barcode" + barcode + numbers + "");
        return barcode + numbers;

    }

    @Deprecated /*Todo check @Team*/
    public static String generateDate() {

        return new SimpleDateFormat("yyyy-MM-dd").toString();
    }

    @Deprecated /*Todo check @Team*/
    public static String generateTime() {

        return new SimpleDateFormat("HH:mm:ss").format(new java.util.Date());
    }

    public static String generate_Random_Number(Integer next_Integer_Len) {
        String return_Value = "";
        for (int i = 0; i < next_Integer_Len; i++) {
            String  fullalphabet = "1234567890";
            Integer next_Int     = new Random().nextInt(fullalphabet.length());
            char    code         = fullalphabet.charAt(next_Int);
            return_Value += Character.toString(code);
            /*TODO Check if random starts with zero, No re entrant needed*/
            if (return_Value.startsWith("0")) {
                return_Value = new StringBuffer(return_Value).deleteCharAt(0).toString();
                i = i - 1;
            }
        }

        return return_Value;
    }

    public static String generate_Random_Character(Integer next_Integer_Len) {
        String return_Value = "";
        for (int i = 0; i < next_Integer_Len; i++) {
            String  alphabet     = "AB-CDE+F_GH-IJK:LM-NOP+QR-STUV+W_XYZ";
            String  fullalphabet = alphabet + alphabet.toLowerCase() + "12+3_456789" + "_-:";
            Random  random       = new Random();
            Integer next_Int     = random.nextInt(fullalphabet.length());
            char    code         = fullalphabet.charAt(next_Int);
            return_Value += Character.toString(code);
        }
        return return_Value;
    }

    public static String generate_Header_Date_TS() {

        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
    }

    public static String generate_Header_Date_TS_TimeZone() {

        final TimeZone   tz = TimeZone.getTimeZone("UTC");
        final DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(tz);
        return df.format(new Date());
    }

    public static Map generate_Header(String header_Name, String TimeStamp, String system_Cd, String messg_Id, String corrln_Id, String method_Name, String Encoded_Auth_Sig) throws Exception {

        Map        lcs_Data    = read_Yaml(get_Data_Folders() + Lcs_Data);
        JsonObject raw_Headers = consolidated_Data.get("Header_Template_For_Rest").getAsJsonObject();
        raw_Headers.addProperty(X_KOHLS_CreateDateTime, TimeStamp);
        raw_Headers.addProperty(X_KOHLS_MessageID, messg_Id);
        raw_Headers.addProperty(X_KOHLS_CorrelationID, corrln_Id);
        raw_Headers.addProperty(X_KOHLS_From_SystemCode, system_Cd);
        raw_Headers.addProperty(Authorization, Encoded_Auth_Sig);
        if (!method_Name.toLowerCase().contains(Reference_Method_Get)) {
            raw_Headers.addProperty(Api_Accept, Api_Accept_Json);
            raw_Headers.addProperty(Api_Accept_Language, Api_Accept_Language_It);
            raw_Headers.addProperty(Api_Content_Type, Api_Accept_Json);
        } else {
            raw_Headers.remove(Api_Accept);
            raw_Headers.remove(Api_Accept_Language);
            raw_Headers.remove(Api_Content_Type);
        }
        Map<String, String> map = new Gson().fromJson(raw_Headers, new TypeToken<Map<String, String>>() {
        }.getType());

        return map;

    }

    public static String getSignature(String payload, String requestPath, String messageId, String method_name, String requestTimestamp) throws Exception {

        Mac    mac       = Mac.getInstance(HmacSHA256);                                   // Todo Direct Constants
        String SecretKey = "something_Default";
        logger.info("requestPath is $$$ :" + requestPath);
        //Todo Add more Endpoints
        if (requestPath.toLowerCase().contains("pointConversion")) SecretKey = Secret_pointConversion;
        if (requestPath.toLowerCase().contains("balances")) SecretKey = Secret_balances;
        if (requestPath.toLowerCase().contains("digitalcartcheckout") || requestPath.contains("spendTracker") || requestPath.contains("earn")) SecretKey = "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x"; //localtestingsecretkey"; 
        if (requestPath.toLowerCase().contains("activities")) SecretKey = Secret_balances;
        if (requestPath.toLowerCase().contains("rules")) SecretKey = Secret_Rules;
        if (requestPath.toLowerCase().contains("transaction")) SecretKey = Secret_Audit;
        if (requestPath.toLowerCase().contains("return")) SecretKey = Secret_Return;
        if (requestPath.toLowerCase().contains("activities/return")) SecretKey = Secret_balances;
        if (requestPath.toLowerCase().contains("pilot")) {
            if (method_name.equalsIgnoreCase("Put"))
                SecretKey = Secret_Pilot_Checker_Put_Only;
            else
                SecretKey = Secret_Pilot_Checker_Non_Put;
        }
        //if (requestPath.toLowerCase().contains("pilotmembers")) SecretKey = Secret_Pilot;

        logger.info("The secret Key is :" + SecretKey);
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), HmacSHA256);

        mac.init(secretKeySpec);
        //  String requestTimestamp     = generate_Header_Date_TS();

        StringBuilder stringToSign = new StringBuilder();
        logger.info("The request path is **** " + requestPath);
        if (method_name.toLowerCase().contains("get")) {
            stringToSign.append("").append("\n").
                    append("").append("\n").
                    append(method_name.toUpperCase()).append("\n").
                    append(requestPath).append("\n").
                    append(requestTimestamp).append("\n").
                    append(messageId);
        } else {
            stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload))
                    .append("\n").append("application/json")
                    .append("\n").append(method_name.toUpperCase())
                    .append("\n").append(requestPath)
                    .append("\n").append(requestTimestamp)
                    //  .append("\n").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date()))
                    .append("\n").append(messageId);
        }

        String sig;
        // return Signature Encoded
        if (requestPath.toLowerCase().contains("rules"))
            sig = "KOHLS1-HMAC-SHA256 local:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        else
            if (requestPath.toLowerCase().contains("pilot") && method_name.toLowerCase().contains("put"))
                sig = "KOHLS1-HMAC-SHA256 Webstore:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
            else
                if (requestPath.toLowerCase().contains("balances") || requestPath.toLowerCase().contains("activities"))
                    sig = "KOHLS1-HMAC-SHA256 local:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
                else
                    if (requestPath.toLowerCase().contains("digitalcartcheckout") || requestPath.contains("spendTracker") || requestPath.contains("earn"))
                        sig = "KOHLS1-HMAC-SHA256 MASH:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
	               else
	                    sig = "KOHLS1-HMAC-SHA256 QCoE:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        return sig;

    }

    public static String getSignature_1348(String payload, String requestPath, String messageId, String method_name, String requestTimestamp, JsonObject header_Values) throws Exception {

        Mac    mac       = Mac.getInstance(HmacSHA256);                                   // Todo Direct Constants
        String SecretKey = new String();
        logger.info("requestPath is $$$ :" + requestPath);
        //Todo Add more Endpoints
        if (requestPath.toLowerCase().contains("pointConversion")) SecretKey = Secret_pointConversion;
        if (requestPath.toLowerCase().contains("balances") || requestPath.toLowerCase().contains("activities"))
            SecretKey = header_Values.get("SecretKey").getAsString();
        if (requestPath.toLowerCase().contains("digitalcartcheckout") || requestPath.contains("spendTracker") || requestPath.contains("earn")) 
        	SecretKey = header_Values.get("SecretKey").getAsString(); 
        if (requestPath.toLowerCase().contains("rules")) SecretKey = Secret_Rules;
        if (requestPath.toLowerCase().contains("transaction")) SecretKey = Secret_Audit;
        if (requestPath.toLowerCase().contains("return")) SecretKey = Secret_Return;
        if (requestPath.toLowerCase().contains("activities/return")) 
        	SecretKey = header_Values.get("SecretKey").getAsString();//Secret_balances;
        if (requestPath.toLowerCase().contains("pilot")) {
            if (method_name.equalsIgnoreCase("Put"))
                SecretKey = Secret_Pilot_Checker_Put_Only;
            else
                SecretKey = Secret_Pilot_Checker_Non_Put;
        }
        //if (requestPath.toLowerCase().contains("pilotmembers")) SecretKey = Secret_Pilot;

        logger.info("The secret Key is :" + SecretKey);
        
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), HmacSHA256);
        
        if(header_Values.has("Empty_Secret")) 
        	secretKeySpec = new SecretKeySpec("a".getBytes(), "");
        if(header_Values.has("Invalid_MsgId"))
        	messageId = "Invalid_message_Id";
        
        mac.init(secretKeySpec);
        //  String requestTimestamp     = generate_Header_Date_TS();

        StringBuilder stringToSign = new StringBuilder();
        logger.info("The request path is **** " + requestPath);
        if (method_name.toLowerCase().contains("get")) {
            stringToSign.append("").append("\n").
                    append("").append("\n").
                    append(method_name.toUpperCase()).append("\n").
                    append(requestPath).append("\n").
                    append(requestTimestamp).append("\n").
                    append(messageId);
        } else {
            stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload))
                    .append("\n").append("application/json")
                    .append("\n").append(method_name.toUpperCase())
                    .append("\n").append(requestPath)
                    .append("\n").append(requestTimestamp)
                    //  .append("\n").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date()))
                    .append("\n").append(messageId);
        }

        String sig;
        // return Signature Encoded
        if (requestPath.toLowerCase().contains("rules")) {
        	if(!header_Values.has("Invalid_API_KEY"))
        		sig = "KOHLS1-HMAC-SHA256 local:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        	else
        		sig = "KOHLS1-HMAC-SHA256 "+header_Values.get("API_KEY").getAsString()+ ":" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        }
        else
            if (requestPath.toLowerCase().contains("pilot") && method_name.toLowerCase().contains("put"))
                sig = "KOHLS1-HMAC-SHA256 Webstore:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
            else
                if (requestPath.toLowerCase().contains("balances") || requestPath.toLowerCase().contains("activities"))
                    sig = "KOHLS1-HMAC-SHA256 " + header_Values.get("API_KEY").getAsString() + ":" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
                else
                    if (requestPath.toLowerCase().contains("digitalcartcheckout") || requestPath.contains("spendTracker") || requestPath.contains("earn"))
                        sig = "KOHLS1-HMAC-SHA256 " +header_Values.get("API_KEY").getAsString() + ":" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
                    	else
                    		sig = "KOHLS1-HMAC-SHA256 QCoE:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        return sig;

    }

    @Deprecated
    public static String getSignatureForPUTCall(String payload, String requestPath, String messageId) throws Exception {

        Mac           mac           = Mac.getInstance("HmacSHA256");                                   // Todo Direct Constants
        String        SecretKey     = new String("GYSqUleSXkB4X6Ngioc3e3MVRBLO6OZAVsBWy06V");  // Todo Direct Constants
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), "HmacSHA256");

        //Init
        mac.init(secretKeySpec);

        String requestTimestamp = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload)).append("\n").append("application/json").            // Todo Direct Constants?
                append("\n").append("PUT").                         // Todo Direct Constants?
                append("\n").append(requestPath).
                append("\n").append(requestTimestamp).
                append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 QCoE:" + Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes())).toString();
        return sig;

    }

    @Deprecated
    public static String getSignatureForPUTCall(String payload, String requestPath, String messageId, String secretKey) throws Exception {

        Mac           mac           = Mac.getInstance("HmacSHA256");                                   // Todo Direct Constants
        String        SecretKey     = new String(secretKey);
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), "HmacSHA256");
        mac.init(secretKeySpec);
        String        requestTimestamp = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        StringBuilder stringToSign     = new StringBuilder();

        stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload)).
                append("\n").append("application/json").            // Todo Direct Constants?
                append("\n").append("PUT").                         // Todo Direct Constants?
                append("\n").append(requestPath).
                append("\n").append(requestTimestamp).
                append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 QCoE:" +
                     Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes())).toString();
        return sig;

    }

    @Deprecated
    public static String getSignatureForPOSTCall(String payload, String requestPath, String messageId, String secretKey, String timestamp) throws Exception {

        Mac mac = Mac.getInstance("HmacSHA256");                             // Todo Direct Constants
        //String secretKey            = new String("VUuUU6OqEcVE5eXM6rN5iFBvgMtGotNaahQJW4c2");  // Todo Direct Constants
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

        //Init
        mac.init(secretKeySpec);

        //String requestTimestamp     = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload)).
                append("\n").append("application/json").            // Todo Direct Constants?
                append("\n").append("POST").                         // Todo Direct Constants?
                append("\n").append(requestPath).
                append("\n").append(timestamp).
                append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 local:" +
                     Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        return sig;

    }

    @Deprecated
    public static String getSignatureForPOSTCallSpendTrackerMash(String payload, String requestPath, String messageId, String secretKey, String timestamp) throws Exception {

        Mac           mac           = Mac.getInstance("HmacSHA256");                             // Todo Direct Constants
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

        //Init
        mac.init(secretKeySpec);

        //String requestTimestamp     = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append(org.apache.commons.codec.digest.DigestUtils.md5Hex(payload)).
                append("\n").append("application/json").            // Todo Direct Constants?
                append("\n").append("POST").                         // Todo Direct Constants?
                append("\n").append(requestPath).
                append("\n").append(timestamp).
                append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 MASH:" +
                     Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes()));
        return sig;

    }

    @Deprecated
    public static String getSignatureForGetCall(String requestPath, String messageId) throws Exception {

        //Request Path  - Should be full url minus the endpoint / just partial path
        //Message Id    - Can be anything as per Developers information.

        Mac           mac           = Mac.getInstance("HmacSHA256");                                   // Todo Direct Constants
        String        SecretKey     = new String("GYSqUleSXkB4X6Ngioc3e3MVRBLO6OZAVsBWy06V");  // Todo Direct Constants
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), "HmacSHA256");

        //Init
        mac.init(secretKeySpec);

        String requestTimestamp = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append("").append("\n").append("").
                append("\n").append("GET").                         // Todo Direct Constants?
                append("\n").append(requestPath).
                append("\n").append(requestTimestamp).
                append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 QCoE:" +
                     Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes())).toString();
        return sig;

    }

    @Deprecated
    public static String getSignatureForRuleConfigGetCall(String requestPath, String messageId, String requestTimestamp) throws Exception {

        //Request Path  - Should be full url minus the endpoint / just partial path
        //Message Id    - Can be anything as per Developers information.

        Mac           mac           = Mac.getInstance("HmacSHA256");                                   // Todo Direct Constants
        String        SecretKey     = new String("reallybadsecret");  // Todo Direct Constants
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKey.getBytes(), "HmacSHA256");

        //Init
        mac.init(secretKeySpec);

        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append("").append("\n").append("").append("\n").append("GET").append("\n").append(requestPath).append("\n").append(requestTimestamp).append("\n").append(messageId);

        // return Signature Encoded
        String sig = "KOHLS1-HMAC-SHA256 local:" +
                     Base64.getEncoder().encodeToString(mac.doFinal(stringToSign.toString().getBytes())).toString();
        return sig;

    }

}
