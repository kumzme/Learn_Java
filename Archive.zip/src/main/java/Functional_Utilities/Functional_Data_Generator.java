package Functional_Utilities;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Character;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Number;
import static Functional_Utilities.V2_Functional_Utilities.create_New_Loyalty_ID;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Sql;
import static Utilities.Date_Util.current_Ts_Minus_Days;
import static Utilities.Date_Util.current_Ts_Plus_Days;
import static Utilities.UtilConstants.Available_Rules;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class Functional_Data_Generator {


    //@TEAM Use this for any kind of data parser and generate.
    public static String parse_And_Generate_Data(String payload_Reference, JsonObject any_Values_To_Replace) throws Exception {
        /*@Remove Todo ReplaceBarcode99999 wont work .. will it?*/
        final String[] Documentation     = {"Replace_Loyalty_Id", "ReplaceDaysMin_010", "ReplaceDaysPls_020", "Replace_Today", "Replace_Latest_Rule_Version", "GenerateRandomChar_010", "ReplaceDaysMin_010", "ReplaceTstMin_Days_010", "Replace_Time_Min_000", "Refer_Rule_Generate_Loyalty_Id", "ReplaceBarcode99999(rewardseventid)"};
        Integer        counter_Max       = 300;
        Integer        Rules_Counter     = 0;
        Integer        Rules_Counter_Max = Available_Rules.length;
        String         passed_Data       = "";

        if (consolidated_Data.has(payload_Reference))
            passed_Data = consolidated_Data.get(payload_Reference).getAsString();
        else
            if (consolidated_Sql.has(payload_Reference))
                passed_Data = consolidated_Sql.get(payload_Reference).getAsString();
            else
                throw new Exception("Currently supporting data generation only from two places - SQL folders and Data folders");


        String passed_Data_Swap = "";

        /* _______________Data Replacer______________*/
        /*  Only already generated data from previous steps should be here. After this any new data genertion will go to data generator code*/
        /*  Replace any values you need, IF passing data generated from other steps use this, If KEY values not matching then it will just ignore and go to data generator */
        for (Map.Entry<String, JsonElement> entry : any_Values_To_Replace.entrySet()) {
            passed_Data_Swap = passed_Data.replace(entry.getKey(), entry.getValue().getAsString());
            passed_Data = passed_Data_Swap;
        }

        Integer pos, total_Digits;
        Long    total_Days;
        String  date_Today, random_number, ts_Minus, ts_Plus, random_order_number;

        /* _______________Data Generator______________*/
        /* Max 300 for now because no ICD document has more than that fields in a single payload*/
        /* Only new data generation should be here */
        /*Todo @Team break if new needed and not process everything.*/
        for (int i = 0; i < counter_Max; i++) {

            if (passed_Data.toLowerCase().contains(Available_Rules[Rules_Counter].toLowerCase())) {
                switch (Available_Rules[Rules_Counter]) {
                    case Refer_Rule_Generate_Loyalty_Id:
                        String loy_Id = create_New_Loyalty_ID();
                        passed_Data_Swap = passed_Data.replace(Refer_Rule_Generate_Loyalty_Id, loy_Id);
                        passed_Data = passed_Data_Swap;
                        break;
                    case Refer_Rule_ReplaceDaysMin:
                        pos = passed_Data.indexOf(Refer_Rule_ReplaceDaysMin);
                        total_Days = Long.valueOf(Long.parseLong(passed_Data.substring(pos + 15, pos + 18)));
                        date_Today = LocalDate.now().minusDays(total_Days).toString();
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 18, date_Today).toString();
                        break;
                    case Refer_Rule_ReplaceDaysPls:
                        pos = passed_Data.indexOf(Refer_Rule_ReplaceDaysPls);
                        total_Days = Long.valueOf(Integer.parseInt(passed_Data.substring(pos + 15, pos + 18)));
                        date_Today = LocalDate.now().plusDays(total_Days).toString();
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 18, date_Today).toString();
                        break;
                    case Refer_Rule_Replace_Final_Date:
                        pos = passed_Data.indexOf(Refer_Rule_Replace_Final_Date);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 18, "9999-12-10").toString();
                        break;
                    case Refer_Rule_Replace_Final_Past_Date:
                        pos = passed_Data.indexOf(Refer_Rule_Replace_Final_Past_Date);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 23, "2000-12-10").toString();
                        break;
                    case Refer_Rule_Replace_Today:
                        pos = passed_Data.indexOf(Refer_Rule_Replace_Today);
                        date_Today = LocalDate.now().toString();
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 13, date_Today).toString();
                        break;
                    case Refer_Rule_ReplaceTstMin:
                        pos = passed_Data.indexOf(Refer_Rule_ReplaceTstMin);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 14, pos + 17));
                        ts_Minus = current_Ts_Minus_Days(total_Digits);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 17, ts_Minus).toString();
                        break;
                    case Refer_Rule_ReplaceTstPls:
                        pos = passed_Data.indexOf(Refer_Rule_ReplaceTstPls);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 14, pos + 17));
                        ts_Plus = current_Ts_Plus_Days(total_Digits);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 17, ts_Plus).toString();
                        break;
                    case Refer_Rule_Current_Timezone_Ts:
                        passed_Data_Swap = passed_Data.replace(Refer_Rule_Current_Timezone_Ts, current_Ts_Minus_Days(0));
                        passed_Data = passed_Data_Swap;
                        break;
                    case Refer_Rule_Replace_Time_Minus:
                        pos = passed_Data.indexOf(Refer_Rule_Replace_Time_Minus);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 17, pos + 20));
                        String time_To_Replace = LocalDateTime.now().minusHours(total_Digits).format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                        passed_Data_Swap = new StringBuffer(passed_Data).replace(pos, pos + 20, time_To_Replace).toString();
                        passed_Data = passed_Data_Swap;
                        break;
                    case Refer_Rule_Current_Date_TimeZ:
                        pos = passed_Data.indexOf(Refer_Rule_Current_Date_TimeZ);
                        time_To_Replace = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'"));
                        passed_Data_Swap = new StringBuffer(passed_Data).replace(pos, pos + 26, time_To_Replace).toString();
                        passed_Data = passed_Data_Swap;
                        break;
                    case Refer_Rule_GenerateRandomNum:
                        pos = passed_Data.indexOf(Refer_Rule_GenerateRandomNum);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 18, pos + 21));
                        random_number = generate_Random_Number(total_Digits);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 21, random_number).toString();
                        break;
                    /* @TEAM Todo Incorrect Place to add changes. We are just replacing here - should be in 'Data Replace' instead*/
                    /*case Refer_Rule_Replace_Loyalty_Id:
                        String loy_Id_R = any_Values_To_Replace.get(Refer_Rule_Replace_Loyalty_Id).getAsString();
                        passed_Data_Swap = passed_Data.replace(Refer_Rule_Replace_Loyalty_Id, loy_Id_R);
                        passed_Data = passed_Data_Swap;
                        break;*/
                    case Refer_Rule_GenerateRandomChar:
                        pos = passed_Data.indexOf(Refer_Rule_GenerateRandomChar);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 19, pos + 22));
                        random_number = generate_Random_Number(total_Digits);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 22, random_number).toString();
                        break;
                    case Refer_Rule_ReplaceBarcode:
                        passed_Data_Swap = V2_Sale_Functionalities.get_Valid_Barcode(passed_Data, any_Values_To_Replace);
                        passed_Data = passed_Data_Swap;
                        break;
                    case Refer_Rule_Replace_MessageId:
                        pos = passed_Data.indexOf(Refer_Rule_Replace_MessageId);
                        String messg_Id = generate_Random_Character(8) + "-" +
                                          generate_Random_Character(4) + "-" +
                                          generate_Random_Character(4) + "-" +
                                          generate_Random_Character(4) + "-" +
                                          generate_Random_Character(12);
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 17, messg_Id).toString();
                        break;
                    /*@Remove TODO*/
                    case LPF_1342_MessageID:
                        pos = passed_Data.indexOf(LPF_1342_MessageID);
                        total_Digits = Integer.parseInt(passed_Data.substring(pos + 19, pos + 22));
                        random_number = generate_Random_Number(total_Digits);
                        String st = "LPF_1342_MessgageID_" + random_number;
                        passed_Data = new StringBuffer(passed_Data).replace(pos, pos + 22, st).toString();
                        break;

                    /* @TEAM Todo Incorrect Place to add changes. We are just replacing here - should be in 'Data Replace' instead*/
                    /*
                    case Refer_Replace_Transaction_Type_Code:
                    	String SaleOrReturn = any_Values_To_Replace.get("SaleOrReturn").getAsString();
                        passed_Data_Swap = passed_Data.replace(Refer_Replace_Transaction_Type_Code, SaleOrReturn);
                        passed_Data = passed_Data_Swap;
                        break;
                    */

                }
            }

            /*If done searching for the current replace value, increment counter*/
            if (!passed_Data.toLowerCase().contains(Available_Rules[Rules_Counter].toLowerCase())) {
                Rules_Counter++;
            }

            /*If all values are searched and done, break*/
            if (Rules_Counter_Max == Rules_Counter) break;

        }

        return passed_Data;

    }

}
