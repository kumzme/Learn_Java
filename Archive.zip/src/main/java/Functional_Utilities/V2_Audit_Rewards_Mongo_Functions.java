package Functional_Utilities;

import com.google.gson.JsonObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Updates;

import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Mongo_Utilities.mongo_Delete_Many_Or_One;
import static Utilities.Mongo_Utilities.mongo_Select_Query_Cursor;
import static Utilities.Mongo_Utilities.mongo_Update_Query_Cursor;
import static Utilities.UtilConstants.*;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gt;
import static com.mongodb.client.model.Sorts.ascending;
import static com.mongodb.client.model.Sorts.descending;

public class V2_Audit_Rewards_Mongo_Functions {

    protected static final Logger logger = get_Logger();

    @Step
    @Deprecated //Guys pls change this ..
    public static Document get_Rewards_Activity_Rows(JsonObject filter) throws Exception {
        String trnsName = filter.get("trnsName").getAsString();

        MongoCollection<Document> col_02 = new MongoClient(new MongoClientURI(Mongodb_Audit_Connection_Dev_00_Atlas)).
                getDatabase("kohlsrewardsaudit").
                getCollection("activity");
        Bson filter_On_This_Condition = eq("loyaltyId", filter.get("loyaltyId").getAsString());

        //Bson                   filter_On_This_Condition = eq("loyaltyId", filter.get("loyaltyId").toString().replaceAll("\"",""));
        Bson                   sort_On_This_Doc = descending("createdOn");
        FindIterable<Document> cursor_Mongodb   = col_02.find(filter_On_This_Condition).sort(sort_On_This_Doc);
        ArrayList<Document>    doc              = new ArrayList<>();

        for (Document document : cursor_Mongodb) {
            doc.add(document);
        }

        /*Todo Scenario specific stuff pls do not do in @Step functions*/
        if (trnsName.equals("Sale_01") && doc.size() >= 2 && doc.get(1) != null) {
            return doc.get(1);
        } else
            if (trnsName.equals("Sale_02") && doc.size() >= 2 && doc.get(0) != null) {
                return doc.get(0);
            } else {
                return cursor_Mongodb.first();
            }
    }

    @Step
    public static JsonObject get_Rewards_Kohlscash_Rows_First(String loyaltyId) throws Exception {
        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Kohls_Cash);
        query_Details.addProperty(Mongo_Get_First_Condition, "");

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));
        return mongo_Select_Query_Cursor(query_Details, query_Conditions);


    }

    /*Use is step definition first row than here*/
    @Step
    public static JsonObject get_Rewards_Activity_First_Row(String loyaltyId) throws Exception {

        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);
        query_Details.addProperty(Mongo_Get_First_Condition, "");

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));
        return mongo_Select_Query_Cursor(query_Details, query_Conditions);

    }

    /*Use is step definition first row than here*/
    @Step
    public static JsonObject get_Rewards_Activity_Rows(String loyaltyId) throws Exception {

        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));

        return mongo_Select_Query_Cursor(query_Details, query_Conditions);

    }
    @Step
    public static JsonObject update_Rewards_Activity(String loyaltyId, String dateTime) throws Exception {

        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
       
        Date date = f.parse(dateTime);
        query_Conditions.put("Mongo_Update", Updates.set("createdOn", date));

        return mongo_Update_Query_Cursor(query_Details, query_Conditions);

    }
    @Step
    public static JsonObject update_Rewards_Balance(String loyaltyId, String dateTime) throws Exception {

        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        
        Date date = f.parse(dateTime);
        query_Conditions.put("Mongo_Update", Updates.set("createdOn", date));

        return mongo_Update_Query_Cursor(query_Details, query_Conditions);

    }

    @Step
    public static void clear_Activity_And_Balance(String loyaltyId) throws Exception {

        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        if (loyaltyId.equalsIgnoreCase(Mongo_Delete_Condition_All)) {
            query_Conditions.put(Mongo_Filter_Condition, gt("loyaltyId", ""));
        } else {
            query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        }
        mongo_Delete_Many_Or_One(query_Details, query_Conditions);


        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);
        mongo_Delete_Many_Or_One(query_Details, query_Conditions);


    }


    @Step
    public static JsonObject get_Rewards_Activity_With_MessageId_First(String messageId) throws Exception {
        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);
        query_Details.addProperty(Mongo_Get_First_Condition, "");
        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("messageDetail.messageId", messageId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));
        return mongo_Select_Query_Cursor(query_Details, query_Conditions);

    }

    @Step
    public static JsonObject get_Rewards_Loyalty_Balance_From_DB(String loyaltyId) throws Exception {

        JsonObject query_Details = new JsonObject();

        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);
        query_Details.addProperty(Mongo_Get_First_Condition, "");

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));
        return mongo_Select_Query_Cursor(query_Details, query_Conditions);

    }


    @Step
    public static JsonObject get_Rewards_Balance_First_row(String loyaltyId) throws Exception {
        JsonObject query_Details = new JsonObject();

        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);
        query_Details.addProperty(Mongo_Get_First_Condition, "");

        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, descending("createdOn"));

        return mongo_Select_Query_Cursor(query_Details, query_Conditions);

    }

    @Step
    public static boolean check_Loyalty_Id_Exists(String loyaltyId) throws Exception {


      /*
        JsonObject query_Details = new JsonObject();
        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);
        query_Details.addProperty(Mongo_Get_First_Condition, "");
        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();
        query_Conditions.put(Mongo_Filter_Condition, eq("loyaltyId", loyaltyId));
        query_Conditions.put(Mongo_Sort_Condition, ascending("createdOn"));
        JsonObject aa = mongo_Count_Query(query_Details, query_Conditions);
        */

        if (get_Rewards_Loyalty_Balance_From_DB(loyaltyId) != null)
            return true;
        else
            return false;

    }

    @Step
    public static JsonObject count_Of_All_Audit_Collections() throws Exception {

        JsonObject        query_Details    = new JsonObject();
        JsonObject        total_Rows       = new JsonObject();
        Map<String, Bson> query_Conditions = new HashMap<String, Bson>();

        query_Details.addProperty(Mongo_DataBase_Name, Mongo_Db_Rewards_Audit);
        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Balance);

        query_Conditions.put(Mongo_Filter_Condition, gt("loyaltyId", ""));

        JsonObject aaa = mongo_Select_Query_Cursor(query_Details, query_Conditions);
        total_Rows.addProperty(Mongo_Db_Coll_Rewards_Audit_Balance, aaa.entrySet().size());

        query_Details.addProperty(Mongo_Coll_Name, Mongo_Db_Coll_Rewards_Audit_Activity);
        aaa = mongo_Select_Query_Cursor(query_Details, query_Conditions);
        total_Rows.addProperty(Mongo_Db_Coll_Rewards_Audit_Activity, aaa.entrySet().size());


        return total_Rows;

    }

    @Step
    @Deprecated
    public static Document get_Rewards_Balance_Rows(String loyaltyId) throws Exception {
        MongoCollection<Document> col_02 = new MongoClient(new MongoClientURI(Mongodb_Audit_Connection_Dev_00_Atlas)).
                getDatabase(Mongo_Db_Rewards_Audit).
                getCollection("balance");
        Bson                   filter_On_This_Condition = eq("loyaltyId", loyaltyId);
        Bson                   sort_On_This_Doc         = descending("createdOn");
        FindIterable<Document> aaa_02                   = col_02.find(filter_On_This_Condition).sort(sort_On_This_Doc);
        return aaa_02.first();
    }


}
