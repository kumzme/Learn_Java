package Functional_Utilities;

import org.apache.log4j.Logger;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.check_Loyalty_Id_Exists;
import static Utilities.General_Purpose_Utilities.get_Logger;

public class V2_Functional_Utilities {
    protected static final Logger logger = get_Logger();

    public static String create_New_Loyalty_ID() throws Exception {
        String loy_Id = "";
        for (int i = 0; i < 4000; i++) {
            loy_Id = generateLoyaltyIdRandom();
            if (check_Loyalty_Id_Exists(loy_Id) == false) return loy_Id;
        }
        throw new Exception("Could not Find loyalty Id");
    }


}
