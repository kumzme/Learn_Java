package Utilities;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.*;


public class DB_Utilities {

    protected static final Logger logger = get_Logger();
    private static Connection              con          = null;

    public static void main(String[] args) throws Exception {

        String aa = null;
        if (aa != null) {
            if (!aa.equals("")) {
                logger.info("_1");
            }
            logger.info("__");
        } else {
            logger.info("NUL");
        }
        /*String sql                = get_SQL_Value_From_SQL_Folders("Get_Rule_Config_Latest_Version");
        String max_Rule_Version   = execute_SQL_MySQL_DB_CRUD(sql).get(0).get(0).toString();
        int    need_Rules_Version = Integer.parseInt(max_Rule_Version) + 1;

        logger.info(need_Rules_Version);*/
        return;
        //mongo_DB_Connect();
    }
    
    public static void createConnection(String dbName) throws Exception {
    
    	 Session                 ses          = null;
             ses = connect_Mysql_SSH_Session(dbName);
	    try {
	    	String url      = "jdbc:mysql://" + DB_MySql_LocalHost + ":" + String.valueOf(DB_MySql_AnyFree_Port) + "/";
		    String dbUser   = System.getenv(Db_QA_User);
		    String dbPasswd = System.getenv(Db_QA_User_Pwd);
		
		    if (dbUser == null) throw new Exception("System Environment variable for QA/DEV/Etc DB user  is not set");
		    if (dbPasswd == null)
		        throw new Exception("System Environment variable for QA/DEV/Etc DB user PASSWORD is not set");
		
		    Class.forName(MySQL_Driver_Class_Name);
		    con = DriverManager.getConnection(url, dbUser, dbPasswd);
	    
	    } catch (Exception e) {
            logger.info(e.getMessage());
            logger.info(e.getStackTrace());
            e.printStackTrace();
            if (con != null) con.close();
            throw new Exception("Db error - check");
        }
    }
    
    public static void closeConnection() throws Exception {
    	if (con != null) con.close();
    }

    public static ArrayList<List<String>> execute_SQL_MySQL_DB_CRUD(String sql_To_Execute) throws Exception {

        ArrayList<List<String>> rows_Fetched = new ArrayList<List<String>>();
        
        Session                 ses          = null;
        try {
            ses = connect_Mysql_SSH_Session(sql_To_Execute);
            String url      = "jdbc:mysql://" + DB_MySql_LocalHost + ":" + String.valueOf(DB_MySql_AnyFree_Port) + "/";
            String dbUser   = System.getenv(Db_QA_User);
            String dbPasswd = System.getenv(Db_QA_User_Pwd);

            if (dbUser == null) throw new Exception("System Environment variable for QA/DEV/Etc DB user  is not set");
            if (dbPasswd == null)
                throw new Exception("System Environment variable for QA/DEV/Etc DB user PASSWORD is not set");

            Class.forName(MySQL_Driver_Class_Name);
            con = DriverManager.getConnection(url, dbUser, dbPasswd);

            PreparedStatement ps   = con.prepareStatement(sql_To_Execute);
            ResultSet         rset = ps.executeQuery();

            while (rset.next()) {
                List<String>      cols_Fetched      = new ArrayList<String>();
                ResultSetMetaData resultSetMetaData = rset.getMetaData();
                int               col_Count         = resultSetMetaData.getColumnCount();
                for (int i = 1; i <= col_Count; i++) {
                    if (rset.getObject(i) == null) {
                        cols_Fetched.add("null");
                    } else {
                        cols_Fetched.add(rset.getString(i));
                    }
                }
                rows_Fetched.add(cols_Fetched);
            }
            if (con != null) con.close();
            if (ses != null) ses.disconnect();
            return rows_Fetched;

        } catch (Exception e) {
            logger.info(e.getMessage());
            logger.info(e.getStackTrace());
            e.printStackTrace();
            if (con != null) con.close();
            if (ses != null) ses.disconnect();
            throw new Exception("Db error - check");
        }


    }

    private static String get_Env_Host(String sql_To_Execute) throws Exception {
        //Get the Current Environment from Project Options
        String env_Name_01 = project_Parameters.get("Environment").getAsString();
        //Get the SSL URL
        if (env_Name_01.toLowerCase().contains("qa")) {
            if (sql_To_Execute.toLowerCase().contains(QA01_loyalty_Audit_listener_DB)) {
                return QA01_loyalty_Audit_listener;
            }
            if (sql_To_Execute.toLowerCase().contains(QA01_Loyalty_Audit_Service_DB)) return QA01_Loyalty_Audit_Service;
            if (sql_To_Execute.toLowerCase().contains(QA01_Loyalty_Cash_Service_DB)) return QA01_Loyalty_Cash_Service;
            if (sql_To_Execute.toLowerCase().contains(QA01_Loyalty_Pilot_Checker_DB)) return QA01_Loyalty_Pilot_Checker;
            if (sql_To_Execute.toLowerCase().contains(QA01_Loyalty_Rule_Config_DB)) return QA01_Loyalty_Rule_Config;
            if (sql_To_Execute.toLowerCase().contains(QA01_Loyalty_Balance_Lookup_DB)) {
                return QA01_Loyalty_Balance_Lookup;
            }
        }

        if (env_Name_01.toLowerCase().contains("dev")) {
            //Todo Do for other environments
        }

        throw new Exception(" Which environment We are connecting to? do not know :- " + sql_To_Execute);

    }

    public static Session connect_Mysql_SSH_Session(String sql_To_Execute) throws Exception {

        Session session  = null;
        String  user     = System.getenv(SSH_QA_Login);
        String  password = System.getenv(SSH_QA_Login_Pwd);
        String  host     = get_Env_Host(sql_To_Execute);

        if (user == null) throw new Exception("System Environment variable for SSH User/desktop/system is not set");
        if (password == null) {
            throw new Exception("System Environment variable for SSH User/desktop/system PASSWORD is not set");
        }


        int port = 22;
        try {
            JSch jsch = new JSch();
            session = jsch.getSession(user, host, port);
            int    any_Free_Local_port = DB_MySql_AnyFree_Port;
            String local_Host          = DB_MySql_LocalHost;
            int    local_Port          = 3306;
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            logger.debug("Establishing Connection: MySQL");
            session.connect();

            int assinged_port = session.setPortForwardingL(any_Free_Local_port, local_Host, local_Port);
            logger.info("localhost:" + assinged_port + " -> " + local_Host + ":" + local_Port);
        } catch (Exception e) {
            System.err.print(e);
            throw new Exception(e);
        }
        return session;
    }

    public static void mongo_DB_Connect() throws JSchException {


        Session session  = null;
        String  user     = "tkma07x";
        String  password = "QWer1234";
        String  host     = "mkt-atb-qa01-hle-usc1a-mongo-1.tst.kohls.com";
        int     port     = 22;

        JSch jsch = new JSch();
        session = jsch.getSession(user, host, port);
        int    any_Free_Local_port = DB_MySql_AnyFree_Port;
        String local_Host          = DB_MySql_LocalHost;
        int    local_Port          = 3306;
        session.setPassword(password);
        session.setConfig("StrictHostKeyChecking", "no");
        logger.debug("Establishing Connection: MongoDb");
        session.connect();

        int assinged_port = session.setPortForwardingL(any_Free_Local_port, local_Host, local_Port);
        logger.info("localhost:" + assinged_port + " -> " + local_Host + ":" + local_Port);


        String aa = "mongodb://userMfeqaE:07f364d7066c6fe@mkt-atb-qa01-hle-usc1a-mongo-1.tst.kohls.com:27020/?ssl=true&authSource=apptrackerutil&ext.ssh.server=mkt-atb-qa01-hle-usc1a-mongo-1.tst.kohls.com:22&ext.ssh.username=tkma07x&ext.ssh.password=aaaaaaaaazxx";

        MongoClientURI  uri         = new MongoClientURI(aa);
        MongoClient     mongoClient = new MongoClient(uri);
        MongoDatabase   db          = mongoClient.getDatabase("apptrackerutil");
        MongoCollection collection  = db.getCollection("loyaltyTracker");

        BasicDBObject whereQuery = new BasicDBObject();
        whereQuery.put("app", "Loyalty-AuditListener");


        FindIterable fi     = collection.find(whereQuery);
        MongoCursor  cursor = fi.iterator();
        while (cursor.hasNext()) {
            Object aaa1 = cursor.next();
            logger.info("___");
        }

        /*String          mongo_User_Id  = "apptrackerutil";
        String          mongo_User_Pwd = "apptrackerutil";
        MongoCredential credential     = MongoCredential.createCredential("user", "apptrackerutil", "passwd".toCharArray());
        MongoClient     mongoClient    = new MongoClient(new ServerAddress("localhost", 27017), Arrays.asList(credential));
        MongoDatabase   db             = mongoClient.getDatabase( "test" );


        MongoDatabase database       = mongoClient.getDatabase("apptrackerutil");

        List<String> databaseNames = mongoClient.getDatabaseNames();
        logger.info("DB names=" + databaseNames);*/

    }

}
