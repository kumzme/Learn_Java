package Utilities;

@Deprecated
public enum TRANSACTION {
    SALE1,
    SALE2,
    RETURN_SALE1,
    VOID_RETURN1
}
