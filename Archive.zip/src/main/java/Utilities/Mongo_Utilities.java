package Utilities;

//import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.mongodb.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.apache.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.convert_BsonDoc_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.*;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Sorts.*;
import static org.junit.Assert.assertTrue;

public class Mongo_Utilities {
    protected static final Logger logger = get_Logger();

    public static MongoClient get_Mongo_Client(JsonObject parameter_Variable) throws Exception {
        String environment_Name = project_Parameters.get("Environment").getAsString().toLowerCase();
        String db_Name          = parameter_Variable.get(Mongo_DataBase_Name).getAsString();
        switch (environment_Name + db_Name) {
            case "dev00" + Mongo_Db_Rewards_Audit:
                return new MongoClient(new MongoClientURI(Mongodb_Audit_Connection_Dev_00_Atlas));
            case "dev00" + Mongo_Db_Rewards_Rule:
                return new MongoClient(new MongoClientURI(Mongodb_Rule_Connection_Dev_00_Atlas));
            case "dev01" + Mongo_Db_Rewards_Audit:
                return new MongoClient(new MongoClientURI(Mongodb_Audit_Connection_Dev_01_Atlas));
            case "dev01" + Mongo_Db_Rewards_Rule:
                return new MongoClient(new MongoClientURI(Mongodb_Rule_Connection_Dev_01_Atlas));
            case "dev02":
                throw new Exception("dev02 is not set yet, pls add here.");
            case "qa00":
                throw new Exception("qa00 is not set yet, pls add here.");
            case "qa01":
                throw new Exception("qa01 is not set yet, pls add here.");
            case "qa02":
                throw new Exception("qa02 is not set yet, pls add here.");
            case "stress00":
                throw new Exception("Stress is not set yet, pls add here.");
            case "stress01":
                throw new Exception("Stress is not set yet, pls add here.");
        }

        throw new Exception("Not sure which environment we need Connection for - Mongodb");

    }

    /**
     * @param filter_Conditions <br> Two conditions to be passed Map [String, Bson]
     *                          <br>Mongo_Filter_Condition, Bson Document
     *                          <br>Mongo_Sort_Condition, Bson Document <Optional>
     * @param query_Variable    <br> Below Conditions to be passed
     *                          <br>Mongo_DataBase_Name
     *                          <br>Mongo_Coll_Name
     *                          <br>Mongo_Get_First_Condition String , "Empty String"
     * @return Document -         Cursor Rows. Calling methods should be inside the service Functions.
     * @throws Exception
     * @see [Handles most commonly used condition for testing - find and fetch cursor OR get first row only OR sorted fetch cursor/first row]
     */

    public static JsonObject mongo_Select_Query_Cursor(JsonObject query_Variable, Map<String, Bson> filter_Conditions) throws Exception {

        /*Handles First  Sort and find conditions*/
        assertTrue(query_Variable.has(Mongo_DataBase_Name));
        assertTrue(query_Variable.has(Mongo_Coll_Name));
        assertTrue(filter_Conditions.containsKey(Mongo_Filter_Condition));

        MongoClient               client                   = get_Mongo_Client(query_Variable);
        MongoCollection<Document> coll_Mongo               = client.getDatabase(query_Variable.get(Mongo_DataBase_Name).getAsString()).getCollection(query_Variable.get(Mongo_Coll_Name).getAsString());
        JsonObject                return_Final             = new JsonObject();
        Bson                      filter_On_This_Condition = filter_Conditions.get(Mongo_Filter_Condition);
        FindIterable<Document>    cursor_Doc;

        /*Optional Sort condition*/
        if (filter_Conditions.containsKey(Mongo_Sort_Condition))
            cursor_Doc = coll_Mongo.find(filter_On_This_Condition).sort(filter_Conditions.get(Mongo_Sort_Condition));
        else cursor_Doc = coll_Mongo.find(filter_On_This_Condition);

        if (query_Variable.has(Mongo_Get_First_Condition)) {
            Document got_Document = cursor_Doc.first();
            if (got_Document != null) {
                client.close();
                return convert_BsonDoc_To_JsonObject(got_Document);
            } else {
                client.close();
                return null;
            }
        } else {
            MongoCursor<Document> aaa_03  = cursor_Doc.iterator();
            int                   counter = 1;
            while (aaa_03.hasNext()) {
                Document got_Document = aaa_03.next();
                return_Final.add(String.valueOf(counter), convert_BsonDoc_To_JsonObject(got_Document));
                counter += 1;
            }
            aaa_03.close();
            client.close();
        }
        return return_Final;
    }
    
    public static JsonObject mongo_Update_Query_Cursor(JsonObject query_Variable, Map<String, Bson> filter_Conditions) throws Exception {

        /*Handles First  Sort and find conditions*/
        assertTrue(query_Variable.has(Mongo_DataBase_Name));
        assertTrue(query_Variable.has(Mongo_Coll_Name));
        assertTrue(filter_Conditions.containsKey(Mongo_Filter_Condition));

        MongoClient               client                   = get_Mongo_Client(query_Variable);
        MongoCollection<Document> coll_Mongo               = client.getDatabase(query_Variable.get(Mongo_DataBase_Name).getAsString()).getCollection(query_Variable.get(Mongo_Coll_Name).getAsString());
        JsonObject                return_Final             = new JsonObject();
        Bson                      filter_On_This_Condition = filter_Conditions.get(Mongo_Filter_Condition);
        Bson                      update_Condition = filter_Conditions.get("Mongo_Update");
        
        coll_Mongo.updateOne(filter_On_This_Condition, update_Condition);
        
        
        return return_Final;
    }


    /**
     * @param filter_Conditions <br> Two conditions to be passed Map [String, Bson]
     *                          <br>Mongo_Filter_Condition, Bson Document
     *                          <br>Mongo_Sort_Condition, Bson Document <Optional>
     * @param query_Variable    <br> Below Conditions to be passed
     *                          <br>Mongo_DataBase_Name
     *                          <br>Mongo_Coll_Name
     *                          <br>Mongo_Get_First_Condition String , "Empty String"
     * @return Document -         Cursor Rows. Calling methods should be inside the service Functions.
     * @throws Exception
     * @see [Handles most commonly used condition for testing - find and fetch cursor OR get first row only OR sorted fetch cursor/first row]
     */

    public static JsonObject mongo_Delete_Many_Or_One(JsonObject query_Variable, Map<String, Bson> filter_Conditions) throws Exception {

        /*Handles First  Sort and find conditions*/
        assertTrue(query_Variable.has(Mongo_DataBase_Name));
        assertTrue(query_Variable.has(Mongo_Coll_Name));
        assertTrue(filter_Conditions.containsKey(Mongo_Filter_Condition));

        MongoClient               client     = get_Mongo_Client(query_Variable);
        MongoCollection<Document> coll_Mongo = client.getDatabase(query_Variable.get(Mongo_DataBase_Name).getAsString()).getCollection(query_Variable.get(Mongo_DataBase_Name).getAsString());

        coll_Mongo.deleteMany(filter_Conditions.get(Mongo_Filter_Condition));
        client.close();
        return new JsonObject();
    }

    public static JsonObject mongo_Count_Query(JsonObject query_Variable, Map<String, Bson> filter_Conditions) throws Exception {

        /*Handles First  Sort and find conditions*/
        assertTrue(query_Variable.has(Mongo_DataBase_Name));
        assertTrue(query_Variable.has(Mongo_Coll_Name));
        assertTrue(filter_Conditions.containsKey(Mongo_Filter_Condition));

        MongoClient               client       = get_Mongo_Client(query_Variable);
        MongoCollection<Document> coll_Mongo   = client.getDatabase(query_Variable.get(Mongo_DataBase_Name).getAsString()).getCollection(query_Variable.get(Mongo_DataBase_Name).getAsString());
        JsonObject                return_Final = new JsonObject();

        Bson filter_On_This_Condition = filter_Conditions.get(Mongo_Filter_Condition);

        long result = coll_Mongo.countDocuments(filter_On_This_Condition);
        return_Final.addProperty(Mongo_Count_Condition, String.valueOf(result));
        client.close();
        return return_Final;

    }

    @Deprecated
    public static String example_Mongodb_Find_Using_Cursor(String some_Variable) throws Exception {

        /*
        MongoCollection<Document> col_02 = new MongoClient(new MongoClientURI(Mongodb_Connecttion_Dev_00)).
                getDatabase("kohlsrewardsaudit").
                getCollection("balance");
                */
        JsonObject aa = new JsonObject();
        aa.addProperty(Mongo_DataBase_Name, "kohlsrewardsaudit");
        aa.addProperty(Mongo_Coll_Name, "balance");

        MongoClient               client     = get_Mongo_Client(aa);
        MongoCollection<Document> coll_Mongo = client.getDatabase(aa.get(Mongo_DataBase_Name).getAsString()).getCollection(aa.get(Mongo_DataBase_Name).getAsString());

        //MongoCollection<Document> col_02        = get_Mongo_Client(aa);
//        ObjectMapper              object_Mapper = new ObjectMapper();

        /*Sort Example*/
        Bson sort_On_This_Doc     = descending("createdOn");
        Bson sort_On_This_Doc_01  = ascending("createdOn");
        Bson sort_On_This_Doc_02  = ascending("createdOn", "field2", "field3", "etc etc etc..");
        Bson order_On_This_Doc_By = orderBy(sort_On_This_Doc, sort_On_This_Doc_01, sort_On_This_Doc_02);

        /*Filter Example*/
        Bson filter_On_This_Condition = eq("loyaltyId", "81131982724");
        Bson filter_Example_01        = and(eq("field1", "value"), gt("field2", "value2"));
        Bson filter_Example_02        = or(eq("field1", "value"), and(filter_Example_01));
        Bson filter_Example_03        = or(exists("field1", true), or(exists("field2", true)));
        Bson filter_Example_04        = or(exists("field1", true), and(exists("field2", true)));

        /*Iterate Example*/
        //FindIterable<Document> aaa_02_Order_By_Example = col_02.find(filter_On_This_Condition).sort(order_On_This_Doc_By);
        FindIterable<Document> aaa_02    = coll_Mongo.find(filter_On_This_Condition).sort(sort_On_This_Doc);
        MongoCursor<Document>  aaa_03    = aaa_02.iterator();
        JsonObject             aaa_Final = new JsonObject();
        int                    counter   = 1;
        while (aaa_03.hasNext()) {
            Document aaa_02_O = aaa_03.next();
            aaa_Final.add(String.valueOf(counter), new GsonBuilder().create().toJsonTree(aaa_02_O, Document.class));
            counter += 1;
        }
        aaa_03.close();
        client.close();
        /*Select One row Example - get max row value for*/
        Document aaa_04     = coll_Mongo.find(eq("loyaltyId", "71117425496")).sort(sort_On_This_Doc).first();
        String   some_Value = aaa_04.get("updatedBalance").toString();

        return "";


    }


    public static DB connectMongoDB(String dbHost, int dbPort, String dbUser, String dbPass) {

        MongoCredential credential  = MongoCredential.createCredential(dbUser, "kohlsrewardsaudit", dbPass.toCharArray());
        MongoClient     mongoClient = new MongoClient(new ServerAddress(dbHost, dbPort), Arrays.asList(credential));
        DB              db          = mongoClient.getDB("admin");
        return db;
    }

    public static MongoCollection getMongoTempate(String url, String db, String collection) {
        MongoClient     mongoClient     = new MongoClient(new MongoClientURI(url));
        MongoDatabase   mongoDatabase   = mongoClient.getDatabase("kohlsrewardsaudit");
        MongoCollection mongoCollection = mongoDatabase.getCollection("balance");
        return mongoCollection;
    }

    /*    public static Document get_DB_Data_From_Balances(String loyaltyId) throws Exception {
            //Hitting DB and getting balance
            DB databaseConn = connectMongoDB("mkt-las-dev00-shard-00-00-lqhqy.gcp.mongodb.net", 27017, "user_gDpqo", "XV1n0IVLYfgS1bAIoS5gTyLbX4RJUrzO");
            logger.info("DB value...." + databaseConn.getName());

            String          url        = "mongodb://user_gDpqo:XV1n0IVLYfgS1bAIoS5gTyLbX4RJUrzO@mkt-las-dev00-shard-00-00-lqhqy.gcp.mongodb.net:27017,mkt-las-dev00-shard-00-01-lqhqy.gcp.mongodb.net:27017,mkt-las-dev00-shard-00-02-lqhqy.gcp.mongodb.net:27017/kohlsrewardsaudit?ssl=true&&sslInvalidHostNameAllowed=true&authSource=admin";
            String          db         = "kohlsrewardsaudit";
            String          collection = "balance";
            MongoCollection mc         = getMongoTempate(url, db, collection);

            logger.info("LoyID is $$$ :" + loyaltyId);
            BasicDBObject          BD               = new BasicDBObject("loyaltyId", loyaltyId);
            Bson                   sort_On_This_Doc = descending("createdOn");
            FindIterable<Document> ob               = mc.find(BD).sort(sort_On_This_Doc);
            Document               last_record      = ob.first();

            //    logger.info("The updated balance of last record is" + last_record.getDouble("updatedBalance"));

            return last_record;

        }
    */

}
