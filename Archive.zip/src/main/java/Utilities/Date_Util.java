package Utilities;

import org.apache.log4j.Logger;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static Utilities.General_Purpose_Utilities.get_Logger;


public class Date_Util {
    protected static final Logger logger = get_Logger();

    public static String changeDateFormat(String date) {

        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String[]   tem    = date.split("T");
        Date       d      = null;
        try {
            d = format.parse(tem[0].trim());
        } catch (ParseException e) {
            logger.info("UNABLE TO PARSE DATE");
        }
        DateFormat reqformat = new SimpleDateFormat("MM/dd/yyyy");
        String     reqdate   = reqformat.format(d);
        return     reqdate;

    }


    /*public static void main(String[] args) { String aa = current_Ts_Minus_Days(20);logger.info(aa);}*/

    public String generate_Random_Using_Timestamp() {
        final SimpleDateFormat sdf       = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
        Timestamp              timestamp = new Timestamp(System.currentTimeMillis());
        return sdf.format(timestamp).replaceAll(" ", "");
    }

    /*
     * subtract days to date in java
     */

    public Date subtractDays(Date date, int days) {
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, -days);

        return cal.getTime();
    }


    public Double twoDeciRoundOff(Double value) {
        Double round = 0.0;
        if (value != null) {
            value = Math.round(value * 100000) / 100000.0;
            round = Math.round(value * 100) / 100.0;
        } else {
            round = null;
        }
        return round;
    }

    /*
     * add days to date in java
     */
    public Date addDays(Date date, int days) {
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);

        return cal.getTime();
    }

    //changeformat of the date form MM/dd/yyyy to yyyy-MM-dd'T'HH:mm:ss+0000
    public String changeDateFormat1(Date date) {
        DateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        return form.format(date) + "+0000";
    }

    public String returndate(int num) {


        String     monthString;
        DateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        Calendar   cal  = Calendar.getInstance();
        Date       date = new Date();
        cal.setTime(date);
        switch (num) {
            case 1:
                cal.add(Calendar.DATE, 2);
                monthString = form.format(cal.getTime());
                logger.info("Activation date :" + monthString);
                break;
            case 2:
                cal.add(Calendar.DATE, 125);
                monthString = form.format(cal.getTime());
                logger.info("Future date :" + monthString);
                break;
            case 3:
                cal.add(Calendar.DATE, -300);
                monthString = form.format(cal.getTime());
                logger.info("No Event date :" + monthString);
                break;
            default:
                monthString = "Invalid Number";

        }

        return monthString;
    }

    public static String current_Ts_Minus_Days(Integer number_Of_Days) {
        String           pattern          = "yyyy-MM-dd kk:mm:ssZ";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Instant          now              = Instant.now(); //current date
        Instant          before           = now.minus(Duration.ofDays(number_Of_Days));
        Date             dateBefore       = Date.from(before);
        return simpleDateFormat.format(dateBefore).replaceAll(" ", "T");

    }
    
    public static String current_Ts_Plus_Days(Integer number_Of_Days) {
        String           pattern          = "yyyy-MM-dd kk:mm:ssZ";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Instant          now              = Instant.now(); //current date
        Instant          before           = now.plus(Duration.ofDays(number_Of_Days));
        Date             dateBefore       = Date.from(before);
        return simpleDateFormat.format(dateBefore).replaceAll(" ", "T");

    }

    public static String Time_Min_Hours(Integer Hours) {
        String           pattern          = "kk:mm:ss";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Instant          now              = Instant.now(); //current date
        Instant          before           = now.minus(Duration.ofHours(Hours));
        Date             dateBefore       = Date.from(before);
        return simpleDateFormat.format(dateBefore).replaceAll(" ", "T");

    }
}
