package Utilities;

import org.apache.log4j.Logger;
import org.junit.Assert;

import static Utilities.General_Purpose_Utilities.*;


public class Lpf_Assert_Utilities {

    protected static final Logger logger = get_Logger();

    /**
     *
     * @param response_Code Integer
     * @throws Exception
     */
    public static void assert_200_Or_201(Integer response_Code) throws Exception {

        Assert.assertTrue(response_Code == 200 || response_Code == 201);
    }

}
