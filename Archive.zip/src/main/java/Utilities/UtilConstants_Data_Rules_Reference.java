package Utilities;

public class UtilConstants_Data_Rules_Reference {

    /*This constants are for Ruless and Otehr data parsing references*/
    public static final String Balance_Lookup_Payload             = "Balance_Lookup_Payload";
    /**/
    public static final String Total_Loyalty_Ids_Needed           = "Total_Loyalty_Ids_Needed";
    public static final String Reference_Payload                  = "Reference_Payload";
    public static final String Reference_Payload_Updated          = "Reference_Payload_Updated";
    public static final String Reference_SQL                      = "Reference_SQL";
    public static final String Reference_Scenario                 = "Reference_Scenario";
    public static final String Reference_Api_Url                  = "Reference_Api_Url";
    public static final String Reference_Api_Path                 = "Reference_Api_Path";
    public static final String Reference_Api_Param                = "Reference_Api_Param";
    public static final String Reference_Method                   = "Reference_Method";
    public static final String Reference_Method_Get               = "get";
    public static final String Reference_Method_Put               = "put";
    public static final String Reference_Method_Post              = "post";
    public static final String Response_type                      = "Response_type";
    public static final String Text                               = "Text";
    /**/
    public static final String Reference_Scenario_Name            = "Reference_Scenario_Name";
    /**/
    public static final String Refer_Rule_Replace_Final_Past_Date = "Replace_Final_Past_Date";
    public static final String Refer_Rule_ReplaceDaysMin          = "ReplaceDaysMin_";
    public static final String Refer_Rule_ReplaceDaysPls          = "ReplaceDaysPls_";
    public static final String Refer_Rule_Replace_Today           = "Replace_Today";
    public static final String Refer_Rule_Replace_Final_Date      = "Replace_Final_Date";
    public static final String Refer_Rule_Replace_Time_Minus      = "Replace_Time_Min_";
    public static final String Refer_Rule_Current_Timezone_Ts     = "Replace_Current_Timezone_Ts";
    public static final String Refer_Rule_Current_Date_TimeZ      = "Replace_Current_Date_TimeZ";
    public static final String Refer_Rule_ReplaceTstMin           = "ReplaceTstMin_";
    /*@Remove TODO this*/
    public static final String Refer_Rule_ReplaceTstPls                  = "ReplaceTstPls_";
    public static final String Refer_Rule_ReplaceBarcode                 = "ReplaceBarcode";
    public static final String Replace_Order_No                          = "Replace_Order_No";
    public static final String Refer_Rule_Replace_Loyalty_Id             = "Replace_Loyalty_Id";
    public static final String Refer_Rule_Replace_MessageId              = "Replace_MessageId";
    /**/
    public static final String Refer_Rule_Generate_Loyalty_Id            = "Generate_Loyalty_Id";
    public static final String Refer_Rule_Generate_Order_No              = "Generate_Order_No";
    public static final String Refer_Rule_GenerateRandomNum              = "GenerateRandomNum_";
    public static final String Refer_Rule_GenerateRandomChar             = "GenerateRandomChar_";
    /*Todo @Remove*/
    @Deprecated
    public static final String LPF_1342_MessageID                        = "LPF_1342_MessageId_";
    /**/
    /*  Todo @Team Do docs for all rules generation parameters */
    public static final String Refer_Rule_ReplaceDaysMin_Doc             = "ReplaceDaysMin_010";            /*10 Days before yyyy-44-dd*/
    public static final String Refer_Rule_ReplaceDaysPls_Doc             = "ReplaceDaysPls_010";            /*10 Days before yyyy-44-dd*/
    public static final String Refer_Rule_GenerateRandomChar_Doc         = "GenerateRandomChar_040";        /*40 Random Characters*/
    public static final String Refer_Rule_GenerateRandomNum_Doc          = "GenerateRandomNum_040";         /*40 Random Numbers*/
    public static final String Refer_Rule_ReplaceTstMin_Doc              = "ReplaceTstMin_Days_010";        /*2018-12-20T22:54:17-0600 10 days minus from today*/
    /* More functional than utilitarian */
    public static final String Rule_Replace_Transaction_Nbr              = "Replace_transactionNbr";
    public static final String Rule_Replace_Transaction_Date             = "Replace_transactionDate";
    public static final String Rule_Replace_Transaction_Time             = "Replace_transactionTime";
    public static final String Rule_Replace_Transaction_Type_Code        = "Replace_Transaction_Type_Code";
    public static final String Rule_Replace_Bar_Code                     = "Replace_barcode";
    public static final String Rule_Replace_Transaction_Type_Code_Sale   = "01";
    public static final String Rule_Replace_Transaction_Type_Code_Return = "11";
    public static final String Rule_Replace_Transaction_Type_Code_Void   = "33";
    public static final String Rule_Replace_barcode_query_to_check_in_db = "get_barcode_query_to_check_in_db";
    @Deprecated
    public static final String Rule_Replace_1233_Transaction_Table_query = "1233_Original_Transaction_Table_Query";
    //Todo @TEAM @Remove. Query names hardcoded in @Step or from feature files [scenario_name + "SQl_File_Name"].
    @Deprecated
    public static final String Rule_Replace_1233_earn_detail_query       = "1233_Earn_detail_Table_Query";
    @Deprecated
    public static final String Rule_Replace_1233_kohls_cash_query        = "1233_Kohls_Cash_Table_Query";
    /*Todo @Team naming convention*/
    public static final String Rule_Replace_Latest_Rule_Version          = "Replace_Latest_Rule_Version";
    public static final String Rule_Bar_Code                             = "barcode";
    public static final String Qualifying_Amount                         = "Qualifying_Amount";
    public static final String Event_kohlscash                           = "Event_kohlscash";
    public static final String TenderType                                = "TenderType";
    public static final String Tender_Typecode                           = "Tender_Typecode";
    public static final String Total_Amount                              = "Total_Amount";
    public static final String Everyday_Kcc_Earned                       = "Everyday_Kcc_Earned";
    public static final String Everyday_NonKcc_Earned                    = "Everyday_NonKcc_Earned";
    public static final String Earn_Tracker_ReductionAmt                 = "Earn_Tracker_ReductionAmt";
    public static final String Return_Type                               = "Return_Type";
    public static final String Return_Amount                             = "Return_Amount";
    public static final String SKU1_Amount                               = "SKU1_Amount";
    public static final String SKU2_Amount                               = "SKU2_Amount";
    public static final String Adjustment_Type                           = "Adjustment_Type";
    public static final String Adjustment_Amount                         = "Adjustment_Amount";
    public static final String Trans_Type                                = "Trans_Type";
    public static final String Total_1Amount                             = "Total_1Amount";
    public static final String Total_2Amount                             = "Total_2Amount";
    /*Constants for Sale*/
    public static final String Event_Payload                             = "_Event";
    public static final String Event_Payload_01                          = "_Event_01";
    public static final String Event_Payload_02                          = "_Event_02";
    public static final String Sale_Payload                              = "_Sale";
    public static final String Sale_Payload_01                           = "_Sale_01";
    public static final String Sale_Payload_02                           = "_Sale_01";
    public static final String Sale_Payload_03                           = "_Sale_01";
    public static final String Sale_Payload_04                           = "_Sale_01";
    public static final String Sale_Payload_05                           = "_Sale_01";


}
