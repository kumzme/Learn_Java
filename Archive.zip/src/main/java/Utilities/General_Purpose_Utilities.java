package Utilities;

import com.google.gson.*;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.*;
import org.junit.Assert;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.yaml.snakeyaml.Yaml;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.*;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Map;
import java.util.Properties;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static com.mongodb.util.JSON.serialize;


public class General_Purpose_Utilities {

    final static Logger logger = get_Logger();

    private static final String ALGO     = "AES";
    private static       byte[] keyValue = {0x74, 0x68, 0x69, 0x73, 0x49, 0x73, 0x41, 0x53, 0x65, 0x63, 0x72, 0x65, 0x74, 0x4b, 0x65, 0x79};

    static {
        SSLUtilities.trustAllHostnames();
        SSLUtilities.trustAllHttpsCertificates();
    }


    public static final Logger get_Logger() {
        Logger logger = LogManager.getLogger(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.setAdditivity(false);
        ConsoleAppender aa                   = new ConsoleAppender();
        PatternLayout   consolePatternLayout = new PatternLayout();
        //Todo use pattern as needed
        consolePatternLayout.setConversionPattern("[%p] %d %c - %m%n");
        aa.setLayout(consolePatternLayout);
        aa.activateOptions();
        logger.addAppender(aa);
        if (project_Parameters.entrySet().size() <= 0) {
            logger.setLevel(Level.INFO);
        } else {
            switch (project_Parameters.get("Log_Level").getAsString().toLowerCase()) {
                case "debug":
                    logger.setLevel(Level.DEBUG);
                    break;
                case "trace":
                    logger.setLevel(Level.TRACE);
                    break;
                case "error":
                    logger.setLevel(Level.ERROR);
                    break;
                case "warn":
                    logger.setLevel(Level.WARN);
                    break;
                default:
                case "info":
                    logger.setLevel(Level.INFO);
                    break;
            }
        }
        logger.setAdditivity(false);
        return logger;
    }

    public static String soap_Client(String payload, String uri, String namespace, String service_Name, String service_Port) throws Exception {

        SOAPMessage request1 = MessageFactory.newInstance().createMessage(null, new ByteArrayInputStream(payload.getBytes()));
        ;

        String endpointUrl_Soap    = uri;
        QName  serviceName_ForSoap = new QName(namespace, service_Name);
        QName  portName_ForSoap    = new QName(namespace, service_Port);


        Service service_ForSoap = Service.create(serviceName_ForSoap);

        //service_ForSoap.getServiceName();
        //service_ForSoap.addPort(portName_ForSoap, SOAPBinding.SOAP11HTTP_BINDING, endpointUrl_Soap);

        service_ForSoap.addPort(portName_ForSoap, SOAPBinding.SOAP11HTTP_BINDING, endpointUrl_Soap);

        Dispatch<SOAPMessage> dispatch_ForSoap = service_ForSoap.createDispatch(portName_ForSoap, SOAPMessage.class, Service.Mode.MESSAGE);
        SOAPMessage           soapResp         = dispatch_ForSoap.invoke(request1);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        soapResp.writeTo(out);
        String xml = out.toString();

        return xml;

    }

    public static String soap_Client_For_Legacy_Apps(String soapEndpointUrl, String soapAction, String payload) throws Exception {
        // Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection        soapConnection        = soapConnectionFactory.createConnection();

        // Send SOAP Message to SOAP Server
        SOAPMessage request1 = MessageFactory.newInstance().createMessage(null, new ByteArrayInputStream(payload.getBytes()));
        ;
        MimeHeaders headers_Updated = request1.getMimeHeaders();
        headers_Updated.addHeader("SOAPAction", soapAction);
        request1.saveChanges();
        SOAPMessage soapResponse = soapConnection.call(request1, soapEndpointUrl);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        soapResponse.writeTo(out);
        String xml = out.toString();

        soapConnection.close();

        return xml;

    }

    public static Properties kafka_Post(String payload, String uri, String namespace, String service_Name, String service_Port) throws Exception {

        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("linger.ms", 1);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        return props;

    }

    /*@Deprecated public static Map restClient_Put_Method(String payload, Map Headers, String full_URL, String method_Name) throws IOException { logger.info("The Payload is:" + payload); CloseableHttpClient httpclient = HttpClients.createDefault(); *//* StringEntity entity                 = new StringEntity(payload, "UTF-8"); entity.setContentEncoding("UTF8"); entity.setContentType("JSON"); *//* HttpHost proxy = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method); RequestConfig config = RequestConfig.custom()  //Proxy .setProxy(proxy) .build(); HttpResponse response = null; HttpPut http_Method = new HttpPut(full_URL); http_Method.setConfig(config); http_Method.setEntity(new StringEntity(payload)); Headers.forEach((k, v) -> http_Method.setHeader(k.toString(), v.toString())); response = httpclient.execute(http_Method); logger.info("The response of PUT balances is: " + response); *//*Set All Headers and Parms Start*//* Map body = convert_String_To_Map((new BasicResponseHandler()).handleResponse(response)); body.put(Response_Code, response.getStatusLine().getStatusCode()); body.put(Response_Code_Reason, response.getStatusLine().getReasonPhrase()); body.put(Response_Headers, response.getAllHeaders().toString()); body.put(Response_Entity, String.valueOf(response.getEntity())); logger.info(body.toString()); *//*Set All Headers and Parms End*//* ((CloseableHttpResponse) response).close(); return body; }*/

    public static JsonObject generate_Header(String payload, String method_Name, String request_Path) throws Exception {

        JsonObject raw_Headers  = new JsonObject();
        String     message_Id   = "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1"; /* Keep this constant. Dev team says no use of this practically unless to trace */
        String     time_Stamp   = generate_Header_Date_TS();
        String     system_Cd    = "1231";
        String     corrln_Id    = "lpfqe";
        String     encoded_Auth = getSignature(payload, request_Path, message_Id, method_Name, time_Stamp);

        raw_Headers.addProperty(X_KOHLS_CreateDateTime, time_Stamp);
        raw_Headers.addProperty(X_KOHLS_MessageID, message_Id);
        raw_Headers.addProperty(X_KOHLS_CorrelationID, corrln_Id);
        raw_Headers.addProperty(X_KOHLS_From_SystemCode, system_Cd);
        raw_Headers.addProperty(Authorization, encoded_Auth);
        if (!method_Name.toLowerCase().contains("get")) {
            raw_Headers.addProperty(Api_Accept, Api_Accept_Json);
            raw_Headers.addProperty(Api_Accept_Language, Api_Accept_Language_It);
            raw_Headers.addProperty(Api_Content_Type, Api_Accept_Json);
        }

        return raw_Headers;

    }

    public static JsonObject generate_Header_1348(String payload, String method_Name, String request_Path, JsonObject header_Values) throws Exception {

        JsonObject raw_Headers = new JsonObject();
        String     message_Id  = header_Values.get("message_Id").getAsString(); //"5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1"; /* Keep this constant. Dev team says no use of this practically unless to trace */
        String     time_Stamp  = header_Values.get("time_Stamp").getAsString(); //generate_Header_Date_TS();
        String     system_Cd   = header_Values.get("system_Cd").getAsString(); //"1231";
        String     corrln_Id   = header_Values.get("corrln_Id").getAsString(); //"lpfqe";

        String encoded_Auth = null;
        if (header_Values.has("Remove_msgId"))
            encoded_Auth = getSignature_1348(payload, request_Path, "", method_Name, time_Stamp, header_Values);

        else
        if (header_Values.has("Remove_date"))
            encoded_Auth = getSignature_1348(payload, request_Path, message_Id, method_Name, "", header_Values);

        else
            encoded_Auth = getSignature_1348(payload, request_Path, message_Id, method_Name, time_Stamp, header_Values);

        //condition to remove header for test case
        if (!header_Values.toString().contains("No_Header")) {
            raw_Headers.addProperty(X_KOHLS_CreateDateTime, time_Stamp);
            raw_Headers.addProperty(X_KOHLS_MessageID, message_Id);
            raw_Headers.addProperty(X_KOHLS_CorrelationID, corrln_Id);
            raw_Headers.addProperty(X_KOHLS_From_SystemCode, system_Cd);
            raw_Headers.addProperty(Authorization, encoded_Auth);
        }
        if (!method_Name.toLowerCase().contains("get")) {
            raw_Headers.addProperty(Api_Accept, Api_Accept_Json);
            raw_Headers.addProperty(Api_Accept_Language, Api_Accept_Language_It);
            raw_Headers.addProperty(Api_Content_Type, Api_Accept_Json);
        }

        return raw_Headers;

    }

    /**
     * #@param all_values - Use Utilconstants as Keys
     * <br> Mandatory:  Reference_Payload
     * <br> Mandatory:  Reference_Api_Url :Reference Constant from Project options.yaml for url - "Parms_Needed" key
     * <br> Mandatory:  Reference_Method : Put/Get/Post
     * <br> Mandatory:  Reference_Payload :: After base URL, full path needed
     *
     * @return body
     * <br> Mandatory:  Response_Code
     * <br> Mandatory:  Response_Code_Reason
     * <br> Mandatory:  Response_Body as JsonObject
     * @throws Exception
     */
    public static JsonObject restClient_Method(JsonObject all_Values) throws Exception {

        JsonObject     body        = new Gson().fromJson("{}", JsonObject.class);
        HttpHost       proxy       = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);
        HttpUriRequest http_Method = null;
        RequestConfig  config      = RequestConfig.custom().setProxy(proxy).build();   /*Proxy*/

        String method_Api   = all_Values.get(Reference_Method).getAsString().toLowerCase();
        String request_Path = all_Values.get(Reference_Api_Path).getAsString();
        String service_URL  = project_Parameters.get(all_Values.get(Reference_Api_Url).getAsString()).getAsString();
        String Service_Name = service_URL + request_Path;

        if (method_Api.contains("get")) {
            if (all_Values.has(Reference_Api_Param)) {
                Service_Name = Service_Name + all_Values.get(Reference_Api_Param).getAsString();
            }
        }

        String string_Payload = "";
        if (all_Values.has(Reference_Payload)) string_Payload = all_Values.get(Reference_Payload).getAsString();
        StringEntity entity_Payload = new StringEntity(string_Payload);

        if (method_Api.contains("put")) {
            http_Method = new HttpPut(Service_Name);
            ((HttpPut) http_Method).setConfig(config);
            ((HttpPut) http_Method).setEntity(entity_Payload);
        }
        if (method_Api.contains("get")) {
            http_Method = new HttpGet(Service_Name);
            ((HttpGet) http_Method).setConfig(config);
        }
        if (method_Api.contains("post")) {
            http_Method = new HttpPost(Service_Name);
            ((HttpPost) http_Method).setConfig(config);
            ((HttpPost) http_Method).setEntity(entity_Payload);
        }


        JsonObject     headers      = generate_Header(string_Payload, method_Api, request_Path);
        HttpUriRequest final_Method = http_Method;

        for (Map.Entry<String, JsonElement> entry : headers.entrySet()) {
            final_Method.setHeader(entry.getKey(), entry.getValue().getAsString());
        }

        HttpResponse httpResponse = (HttpClients.createDefault()).execute(final_Method);
        System.out.println("httpResponse is $$$ :" + httpResponse.toString());
        Integer resp_code_Int    = Integer.parseInt(String.valueOf(httpResponse.getStatusLine().getStatusCode()));
        String  resp_code_Reason = httpResponse.getStatusLine().getReasonPhrase();
        if (resp_code_Int != 503 && resp_code_Int != 504 && resp_code_Int != 404 && resp_code_Int != 400) {
            if (httpResponse.getEntity() != null) {
                if(all_Values.get(Response_type)!=null) {
                    body.addProperty(Response_Body, EntityUtils.toString(httpResponse.getEntity()));
                } else {
                    body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));
                }

                body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase()); //Add more if needed
                body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());
                /*logger.info("The Response ::- " + body.toString() + " |Payl::- " + string_Payload + " |Hdrs::-" + headers.toString());*/
                ((CloseableHttpResponse) httpResponse).close();
                return body;
            }
        }

        return body;
        /*System.out.print(resp_code_Int + ":Service  Errored out due to : " + resp_code_Reason);
        throw new Exception("While hitting a service some error:" + resp_code_Int + ": And Reason - :" + resp_code_Reason);*/

    }


    /**
     * @throws Exception
     * @Team - Pls do the java doc here
     */
    public static JsonObject restClient_Method_Optional_Or_Negative(JsonObject all_Values) throws Exception {

        JsonObject     body        = new JsonObject();
        HttpHost       proxy       = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);
        HttpUriRequest http_Method = null;
        RequestConfig  config      = RequestConfig.custom().setProxy(proxy).build();   /*Proxy*/

        String request_Path   = all_Values.get(Reference_Api_Path).getAsString();
        String service_URL    = "";
        String string_Payload = "";
        if (project_Parameters.has(all_Values.get(Reference_Api_Url).getAsString())) {
            service_URL = project_Parameters.get(all_Values.get(Reference_Api_Url).getAsString()).getAsString();
        } else {
            service_URL = all_Values.get(Reference_Api_Url).getAsString();
        }
        String Service_Name = service_URL + request_Path;
        String method_Api   = all_Values.get(Reference_Method).getAsString().toLowerCase();
        if (all_Values.has(Reference_Payload))
            string_Payload = all_Values.get(Reference_Payload).getAsString();

        if (all_Values.has(Reference_Api_Param))
            Service_Name = Service_Name + all_Values.get(Reference_Api_Param).getAsString();


        StringEntity entity_Payload = new StringEntity(string_Payload);

        if (method_Api.contains("put")) {
            http_Method = new HttpPut(Service_Name);
            ((HttpPut) http_Method).setConfig(config);
            ((HttpPut) http_Method).setEntity(entity_Payload);
        }
        if (method_Api.contains("get")) {
            http_Method = new HttpGet(Service_Name);
            ((HttpGet) http_Method).setConfig(config);
        }
        if (method_Api.contains("post")) {
            http_Method = new HttpPost(Service_Name);
            ((HttpPost) http_Method).setConfig(config);
            ((HttpPost) http_Method).setEntity(entity_Payload);
        }

        String     message_Id = "";
        String     time_Stamp = "";
        String     system_Cd  = "";
        String     corrln_Id  = "";
        JsonObject headers    = new JsonObject();

        /*Message Id*/
        if (all_Values.has(Api_Pass_Message_Id)) message_Id = all_Values.get(Api_Pass_Message_Id).getAsString();
        else message_Id = "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1";
        /*TimeStamp*/
        if (all_Values.has(Api_Pass_Time_Stamp)) time_Stamp = all_Values.get(Api_Pass_Time_Stamp).getAsString();
        else time_Stamp = generate_Header_Date_TS();
        /*System Code*/
        if (all_Values.has(Api_Pass_System_Cd)) system_Cd = all_Values.get(Api_Pass_System_Cd).getAsString();
        else system_Cd = "1231";
        /*Correlation Id*/
        if (all_Values.has(Api_Pass_Corrln_Id)) corrln_Id = all_Values.get(Api_Pass_Corrln_Id).getAsString();
        else corrln_Id = "lpfqedefault";

        String encoded_Auth = getSignature(string_Payload, request_Path, message_Id, method_Api, time_Stamp);

        headers.addProperty(X_KOHLS_CreateDateTime, time_Stamp);
        headers.addProperty(X_KOHLS_MessageID, message_Id);
        headers.addProperty(X_KOHLS_CorrelationID, corrln_Id);
        headers.addProperty(X_KOHLS_From_SystemCode, system_Cd);
        headers.addProperty(Authorization, encoded_Auth);
        if (!method_Api.toLowerCase().contains("get")) {
            headers.addProperty(Api_Accept, Api_Accept_Json);
            headers.addProperty(Api_Accept_Language, Api_Accept_Language_It);
            headers.addProperty(Api_Content_Type, Api_Accept_Json);
        }

        headers = generate_Header(string_Payload, method_Api, request_Path);
        HttpUriRequest final_Method = http_Method;

        for (Map.Entry<String, JsonElement> entry : headers.entrySet()) {
            final_Method.setHeader(entry.getKey(), entry.getValue().getAsString());
        }

        HttpResponse httpResponse = (HttpClients.createDefault()).execute(final_Method);

        System.out.println("httpResponse is $$$ :"+httpResponse.toString());
        body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase()); //Add more if needed
        body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());

        if (httpResponse.getEntity() != null) {
            System.out.println("HEllo....");

            if(all_Values.has(Response_type))
            {
                if(all_Values.get(Response_type).getAsString().equals(Text)) {
                    body.addProperty(Response_Body, EntityUtils.toString(httpResponse.getEntity()));
                }
            }
            else {
                body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));

            }
        }

        ((CloseableHttpResponse) httpResponse).close();
        return body;

    }


    /*Make this as a negative Rest client method*/
    public static JsonObject restClient_Method_Negative(JsonObject all_Values) throws Exception {

        JsonObject     body        = new Gson().fromJson("{}", JsonObject.class);
        HttpHost       proxy       = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);
        HttpUriRequest http_Method = null;
        RequestConfig  config      = RequestConfig.custom().setProxy(proxy).build();   /*Proxy*/

        String method_Api   = all_Values.get(Reference_Method).getAsString().toLowerCase();
        String request_Path = all_Values.get(Reference_Api_Path).getAsString();
        String service_URL  = project_Parameters.get(all_Values.get(Reference_Api_Url).getAsString()).getAsString();
        String Service_Name = service_URL + request_Path;

        if (method_Api.contains("get")) {
            if (all_Values.has(Reference_Api_Param)) {
                Service_Name = Service_Name + all_Values.get(Reference_Api_Param).getAsString();
            }
        }

        String string_Payload = "";
        if (all_Values.has(Reference_Payload)) string_Payload = all_Values.get(Reference_Payload).getAsString();
        StringEntity entity_Payload = new StringEntity(string_Payload);

        if (method_Api.contains("put")) {
            http_Method = new HttpPut(Service_Name);
            ((HttpPut) http_Method).setConfig(config);
            ((HttpPut) http_Method).setEntity(entity_Payload);
        }
        if (method_Api.contains("get")) {
            http_Method = new HttpGet(Service_Name);
            ((HttpGet) http_Method).setConfig(config);
        }
        if (method_Api.contains("post")) {
            http_Method = new HttpPost(Service_Name);
            ((HttpPost) http_Method).setConfig(config);
            ((HttpPost) http_Method).setEntity(entity_Payload);
        }

        JsonObject     headers      = generate_Header_1348(string_Payload, method_Api, request_Path, all_Values);
        HttpUriRequest final_Method = http_Method;

        for (Map.Entry<String, JsonElement> entry : headers.entrySet()) {
            final_Method.setHeader(entry.getKey(), entry.getValue().getAsString());
        }

        HttpResponse httpResponse = (HttpClients.createDefault()).execute(final_Method);

        logger.info("httpResponse is $$$ :" + httpResponse.toString());
        Integer resp_code_Int    = Integer.parseInt(String.valueOf(httpResponse.getStatusLine().getStatusCode()));
        String  resp_code_Reason = httpResponse.getStatusLine().getReasonPhrase();

        //condition for negative test case 404
        if (all_Values.toString().contains("404_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            Assert.assertTrue(resp_code_Int.toString().contains("404"));
            if (resp_code_Int == 404)
                return body;
        }

        //condition for negative test case 400
        if (all_Values.toString().contains("400_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            Assert.assertTrue(resp_code_Int.toString().contains("400") || resp_code_Int.toString().contains("401"));
            if (resp_code_Int == 400 || resp_code_Int == 401)
            {
                body.addProperty(Response_Code,resp_code_Int.toString());
            }

                return body;
        }

        //condition for negative test case 401
        if (all_Values.toString().contains("401_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            Assert.assertTrue("The actual response code is "+resp_code_Int.toString(), resp_code_Int.toString().contains("401"));
            if (resp_code_Int == 400 || resp_code_Int == 401)
            {
                body.addProperty(Response_Code,resp_code_Int.toString());
            }

            return body;
        }

        //condition for negative test case 503
        if (all_Values.toString().contains("503_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            logger.info("resp_code_Reason is $$$ :" + resp_code_Reason);
            Assert.assertTrue(resp_code_Int.toString().contains("503"));
            Assert.assertTrue(resp_code_Reason.contains("Service Unavailable"));
            if (resp_code_Int == 503 && resp_code_Reason.equals("Service Unavailable"))
                return body;
        }

        //condition for negative test case 200
        if (all_Values.toString().contains("200_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            Assert.assertTrue(resp_code_Int.toString().contains("200"));
            if (resp_code_Int == 200)
            {
                body.addProperty(Response_Code,resp_code_Int.toString());
            }

                return body;
        }

        //condition for negative test case 201
        if (all_Values.toString().contains("201_example")) {
            logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            Assert.assertTrue(resp_code_Int.toString().contains("201"));
            if (resp_code_Int == 201)
            {
                body.addProperty(Response_Code,resp_code_Int.toString());
            }

            return body;
        }

        if (resp_code_Int != 503 && resp_code_Int != 504 && resp_code_Int != 404 && resp_code_Int != 400) {
            if (httpResponse.getEntity() != null) {
                if(all_Values.has(Response_type))
                {
                    if(all_Values.get(Response_type).getAsString().equals(Text)) {
                        body.addProperty(Response_Body, EntityUtils.toString(httpResponse.getEntity()));
                    }
                }
                else {
                    body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));
                    body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase()); //Add more if needed
                    body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());
                }
                /*logger.info("The Response ::- " + body.toString() + " |Payl::- " + string_Payload + " |Hdrs::-" + headers.toString());*/
                ((CloseableHttpResponse) httpResponse).close();
                return body;
            }
        }
        System.out.print(resp_code_Int + ":Service  Errored out due to : " + resp_code_Reason);
        throw new Exception("While hitting a service some error:" + resp_code_Int + ": And Reason - :" + resp_code_Reason);

    }

    /**
     * @deprecated
     */
    public static JsonObject restClient_Any_Method(String payload, Map Headers, String full_URL, String method_Name) throws IOException {
        JsonObject     body        = new Gson().fromJson("{}", JsonObject.class);
        HttpHost       proxy       = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);
        RequestConfig  config      = RequestConfig.custom().setProxy(proxy).build();   /*Proxy*/
        HttpUriRequest http_Method = null;

        String       method = method_Name.toLowerCase();
        StringEntity entity = new StringEntity(payload);
        logger.info("The payload is ******  " + payload);

        //Todo Check and test all combinations Vs Methods // Does get needs proxy?
        if (method.contains("get")) {
            http_Method = new HttpGet(full_URL);
            ((HttpGet) http_Method).setConfig(config);
        }
        if (method.contains("put")) {
            http_Method = new HttpPut(full_URL);
            ((HttpPut) http_Method).setConfig(config);
            ((HttpPut) http_Method).setEntity(entity);
        }
        if (method.contains("post")) {
            http_Method = new HttpPost(full_URL);
            ((HttpPost) http_Method).setConfig(config);
            ((HttpPost) http_Method).setEntity(entity);
        }

        HttpUriRequest finalHttp_Method = http_Method;

        Headers.forEach((k, v) -> finalHttp_Method.setHeader(k.toString(), v.toString()));

        HttpResponse httpResponse = (HttpClients.createDefault()).execute(finalHttp_Method);
        logger.info("The response is:  " + httpResponse);
        body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));
        body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());
        body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase()); //Add more if needed
        Logger logger = (Logger) get_Logger();
        logger.info("The Response ::- " + body.toString() + " |Payl::- " + payload + " |Hdrs::-" + Headers.toString());

        ((CloseableHttpResponse) httpResponse).close();
        return body;
    }

    /*@Deprecated public static JsonObject restClient_Post_Method(String payload, Map Headers, String full_URL, String method_Name) throws IOException { CloseableHttpClient httpclient              = HttpClients.createDefault();HttpHost proxy                              = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);RequestConfig config                        = RequestConfig.custom().setProxy(proxy).build();   *//*Proxy*//*HttpPost http_Method                        = new HttpPost(full_URL);http_Method.setConfig(config);http_Method.setEntity(new StringEntity(payload)); *//*Set the Headers and Entity //logger.info("Item : " + k + " +  value : " + v);*//*Headers.forEach((k, v) -> http_Method.setHeader(k.toString(), v.toString()));HttpResponse  httpResponse                  = httpclient.execute(http_Method);JsonObject body                             = new Gson().fromJson(EntityUtils.toString(httpResponse.getEntity()), JsonObject.class);body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase());logger.info(body.toString());return body; }*/

    public static void delete_Define_File(String file_Path) throws IOException {
        File new_File = new File(file_Path);
        if (new_File.exists()) {
            new_File.delete();
        }
        new_File.createNewFile();
    }


    public static void consolidate_Files(String file_Path, String folder_Path) throws Exception {
        StringBuilder aa2 = new StringBuilder();
        delete_Define_File(file_Path);

        Files.list(Paths.get(folder_Path))
                .filter(Files::isRegularFile)
                .flatMap(
                        s -> {
                            try {
                                return Files.lines(s);
                            } catch (IOException e) {
                                e.printStackTrace();
                                return null;
                            }
                        }
                )
                .forEach(
                        s -> { aa2.append(s).append("\n"); }
                );

        Files.write(Paths.get(file_Path), aa2.toString().getBytes(), StandardOpenOption.APPEND);

    }

    public static void consolidate_Sql() throws Exception {
        consolidate_Files(get_Run_Data_Store_Folders() + Consolidated_Sql_File, get_SQL_Folders());
    }

    public static void consolidate_Data() throws Exception {
        consolidate_Files(get_Run_Data_Store_Folders() + Consolidated_Data_File, get_Data_Folders());

    }


    public static String encrypt_Pwd(String pwd_To_Encrypt) throws Exception {

        try {
            Key    key          = new SecretKeySpec(keyValue, ALGO);
            Cipher cipher_Value = Cipher.getInstance(ALGO);
            byte[] encVal       = cipher_Value.doFinal(pwd_To_Encrypt.getBytes());
            cipher_Value.init(Cipher.ENCRYPT_MODE, key);
            String encrypted_Value = new String(Base64.getEncoder().encode(encVal));
            return encrypted_Value;

        } catch (Exception encex1) {
            logger.error("Encryp exception", encex1);
        }
        throw new Exception("Why it did not return ? Pls check the encryption / values");

    }

    public static String decrypt_Pwd(String pwd_To_Decrypt) throws Exception {

        try {
            //Key key = generateKey();
            Key    key = new SecretKeySpec(keyValue, ALGO);
            Cipher c   = Cipher.getInstance(ALGO);
            c.init(Cipher.DECRYPT_MODE, key);
            byte[] decordedValue  = Base64.getDecoder().decode(pwd_To_Decrypt);
            byte[] decValue       = c.doFinal(decordedValue);
            String decryptedValue = new String(decValue);
            return decryptedValue;
        } catch (Exception de1) {
            logger.error("Decryption failed: ", de1);
        }
        throw new Exception("Why it did not return ? Pls check the decryption / values");
    }

    public static String get_Data_Folders()           { return System.getProperty("user.dir") + "/src/main/resources/Data_Folders"; }

    public static String get_Certs_Folders()          { return System.getProperty("user.dir") + "/src/main/resources/Certs"; }

    public static String get_SQL_Folders()            { return System.getProperty("user.dir") + "/src/main/resources/Sqls"; }

    public static String get_Run_Data_Store_Folders() { return System.getProperty("user.dir") + "/src/main/resources/Dynamically_Generated_Data_Store_Folders"; }

    public static void store_Scenario_Data(String full_File_Name, Map store_Data) throws Exception {
        JsonObject map_Store_Json = new Gson().fromJson("{}", JsonObject.class);

        if (check_File_Exists_In_Data_Folder(full_File_Name)) {
            Map map_Store = read_Yaml(full_File_Name);
            map_Store.forEach((key, value) ->
                    map_Store_Json.addProperty(key.toString(), value.toString())
            );
        }

        store_Data.forEach((key, value) ->
                map_Store_Json.addProperty(key.toString(), value.toString())
        );
        write_Yaml(full_File_Name, map_Store_Json);

    }

    public static WebDriver get_WebDriver() throws Exception {
        WebDriver driver        = null;
        String    driver_Needed = project_Parameters.get("Webdriver_Needed").getAsString().toLowerCase();
        switch (driver_Needed) {
            case "chrome":
                ChromeOptions options = new ChromeOptions(); //Todo General Options in the Profile itself.
                options.setAcceptInsecureCerts(true);
                options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
                options.addArguments("--disable-plugins");
                options.addArguments("--disable-extensions");
                options.addArguments("--start-maximized");
                options.setProxy(new Proxy().setHttpProxy(Kohls_Proxy + ":" + Kohls_Proxy_Port));
                options.setExperimentalOption("useAutomationExtension", false);
                System.setProperty("webdriver.chrome.driver", get_Driver_Path_and_Name());
                //Todo Binary Needed ?// options.setBinary();
                driver = new ChromeDriver(options);
                break;
            case "firefox": //Todo
                break;
        }

        return driver;
    }

    public static String get_Platform_Name() throws Exception {
        String OS = System.getProperty("os.name").toLowerCase();
        if (OS.indexOf("win") >= 0)
            return "windows";
        if (OS.indexOf("mac") >= 0)
            return "macosx";
        if (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") > 0 || OS.indexOf("sunos") >= 0)
            return "unix";
        throw new Exception("Unable to find which System");
    }

    public static String get_Driver_Folders() { return System.getProperty("user.dir") + "/src/main/resources/Drivers_Check_If_Fine_Jenkins"; }

    public static String get_Driver_Path_and_Name() throws Exception {
        String platform_Name      = get_Platform_Name();
        String driver_Folder_Path = get_Driver_Folders();

        if (platform_Name.equalsIgnoreCase("windows"))
            return driver_Folder_Path + "/chromedriver_Windows32_v69_71.exe";

        if (platform_Name.equalsIgnoreCase("macosx"))
            return driver_Folder_Path + "/chromedriver_MacOsx64_v69_71";

        if (platform_Name.equalsIgnoreCase("unix"))
            return driver_Folder_Path + "/chromedriver_Linux64_v69_71";

        throw new Exception("Unable to find which System we need Driver for");
    }

    public static String get_project_Options_File()                                                      { return System.getProperty("user.dir") + "/Project_Options.yaml"; }

    public static String get_project_Parameters_File()                                                   { return get_Run_Data_Store_Folders() + "/Project_Parameters.yaml"; }

    public static Map convert_String_To_Map(String stringJson)                                           { return new Gson().fromJson(stringJson, Map.class); }

    public static JsonObject convert_String_To_JsonObject(String stringJson)                             { return new Gson().fromJson(stringJson, JsonObject.class); }

    public static JsonObject convert_BsonDoc_To_JsonObject(org.bson.Document bson_Document)              { return new Gson().fromJson(serialize(bson_Document), JsonObject.class);}

    public static JsonArray convert_String_To_JsonArray(String stringJson)                               { return new Gson().fromJson(stringJson, JsonArray.class); }

    public static JsonElement convert_JsonObject_To_JsonElement(JsonObject received_Object)              { return (new GsonBuilder().create()).toJsonTree(received_Object, JsonObject.class);}

    public static JsonElement convert_String_Array_To_JsonElement(String[] received_Object)              { return (new GsonBuilder().create()).toJsonTree(received_Object, String[].class); }

    public static JsonElement convert_String_ArrayList_To_JsonElement(ArrayList<String> received_Object) { return (new GsonBuilder().create()).toJsonTree(received_Object, ArrayList.class); }

    public static JsonObject convert_Map_To_JsonObject(Map mapObject)                                    { return new Gson().toJsonTree(mapObject).getAsJsonObject(); }

    public static boolean check_File_Exists_In_Data_Folder(String file_Name) {
        File file = new File(file_Name);
        if (file.exists()) {
            return true;
        }
        return false;
    }

    public static Document convert_Soap_Response_To_XML_Doc(String stringXML) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(stringXML.getBytes("UTF-8")));
    }

    public static ArrayList<String> get_Xml_elements_By_Tag_Name(Document doc_xml, String tagName) throws Exception {
        NodeList          node_List      = doc_xml.getElementsByTagName(tagName);
        ArrayList<String> list_Of_Values = new ArrayList<>();
        for (int i = 0; i < node_List.getLength(); i++) {
            list_Of_Values.add(node_List.item(i).getTextContent());
        }
        return list_Of_Values;
    }

    public static void write_Yaml(String full_File_Path, JsonObject data) throws Exception {
        delete_Define_File(full_File_Path);
        BufferedWriter writer = new BufferedWriter(new FileWriter(full_File_Path));
        writer.write(data.toString());
        writer.close();
    }

    public static Map read_Yaml(String full_File_Path) throws Exception {
        File            file_c = new File(full_File_Path);
        FileInputStream f_I    = new FileInputStream(file_c);
        return new Yaml().load(f_I);
    }

    /**
     * Provide a Key reference to retrieve.
     * Can be in any file SQL folder.
     * Key should be always unique in any YAML file
     *
     * @param folder_Path_Full
     * @param key_Reference
     * @return sql Query string from any file in SQL folder
     * @throws Exception
     */
    public static String get_Key_Value_From_Any_Folder(String folder_Path_Full, String key_Reference) throws Exception {

        File[] list_Of_Files = new File(folder_Path_Full).listFiles();

        for (File file : list_Of_Files) {
            if (file.isFile()) {
                JsonObject get_Map = convert_Map_To_JsonObject(read_Yaml(file.getAbsolutePath()));
                if (get_Map.has(key_Reference)) {
                    return get_Map.get(key_Reference).getAsString();
                }
            }
        }
        throw new Exception("Error getting SQL/Data's:: Check if the reference is correct");
    }

    public static JsonObject restClient_Method_Neg(JsonObject all_Values) throws Exception {

        JsonObject     body        = new JsonObject();
        HttpHost       proxy       = new HttpHost(Kohls_Proxy, Kohls_Proxy_Port, Http_Method);
        HttpUriRequest http_Method = null;
        RequestConfig  config      = RequestConfig.custom().setProxy(proxy).build();   /*Proxy*/

        String request_Path   = all_Values.get(Reference_Api_Path).getAsString();
        String service_URL    = "";
        String string_Payload = "";
        if (project_Parameters.has(all_Values.get(Reference_Api_Url).getAsString())) {
            service_URL = project_Parameters.get(all_Values.get(Reference_Api_Url).getAsString()).getAsString();
        } else {
            service_URL = all_Values.get(Reference_Api_Url).getAsString();
        }
        String Service_Name = service_URL + request_Path;
        String method_Api   = all_Values.get(Reference_Method).getAsString().toLowerCase();
        if (all_Values.has(Reference_Payload))
            string_Payload = all_Values.get(Reference_Payload).getAsString();

        if (all_Values.has(Reference_Api_Param))
            Service_Name = Service_Name + all_Values.get(Reference_Api_Param).getAsString();


        StringEntity entity_Payload = new StringEntity(string_Payload);

        if (method_Api.contains("put")) {
            http_Method = new HttpPut(Service_Name);
            ((HttpPut) http_Method).setConfig(config);
            ((HttpPut) http_Method).setEntity(entity_Payload);
        }
        if (method_Api.contains("get")) {
            http_Method = new HttpGet(Service_Name);
            ((HttpGet) http_Method).setConfig(config);
        }
        if (method_Api.contains("post")) {
            http_Method = new HttpPost(Service_Name);
            ((HttpPost) http_Method).setConfig(config);
            ((HttpPost) http_Method).setEntity(entity_Payload);
        }

        String     message_Id = "";
        String     time_Stamp = "";
        String     system_Cd  = "";
        String     corrln_Id  = "";
        String      encoded_Auth = "";
        JsonObject headers    = new JsonObject();

        /*Message Id*/
        if (all_Values.has(Api_Pass_Message_Id)) message_Id = all_Values.get(Api_Pass_Message_Id).getAsString();
        else message_Id = "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1";
        /*TimeStamp*/
        if (all_Values.has(Api_Pass_Time_Stamp)) time_Stamp = all_Values.get(Api_Pass_Time_Stamp).getAsString();
        else time_Stamp = generate_Header_Date_TS();
        /*System Code*/
        if (all_Values.has(Api_Pass_System_Cd)) system_Cd = all_Values.get(Api_Pass_System_Cd).getAsString();
        else system_Cd = "1231";
        /*Correlation Id*/
        if (all_Values.has(Api_Pass_Corrln_Id)) corrln_Id = all_Values.get(Api_Pass_Corrln_Id).getAsString();
        else corrln_Id = "lpfqedefault";

        if (all_Values.has(Api_Pass_Authorization)) encoded_Auth = all_Values.get(Api_Pass_Authorization).getAsString();
        else encoded_Auth = getSignature(string_Payload, request_Path, message_Id, method_Api, time_Stamp);


        headers.addProperty(X_KOHLS_CreateDateTime, time_Stamp);
        headers.addProperty(X_KOHLS_MessageID, message_Id);
        headers.addProperty(X_KOHLS_CorrelationID, corrln_Id);
        headers.addProperty(X_KOHLS_From_SystemCode, system_Cd);
        headers.addProperty(Authorization, encoded_Auth);

        if (all_Values.has(Missing_Header))
        {
            headers.remove(all_Values.get(Missing_Header).getAsString());
        }
        if (!method_Api.toLowerCase().contains("get")) {
            headers.addProperty(Api_Accept, Api_Accept_Json);
            headers.addProperty(Api_Accept_Language, Api_Accept_Language_It);
            headers.addProperty(Api_Content_Type, Api_Accept_Json);
        }

        //   headers = generate_Header(string_Payload, method_Api, request_Path);
        HttpUriRequest final_Method = http_Method;

        for (Map.Entry<String, JsonElement> entry : headers.entrySet()) {
            final_Method.setHeader(entry.getKey(), entry.getValue().getAsString());
        }

        HttpResponse httpResponse = (HttpClients.createDefault()).execute(final_Method);

        System.out.println("httpResponse is $$$ :"+httpResponse.toString());
        body.addProperty(Response_Code_Reason, httpResponse.getStatusLine().getReasonPhrase()); //Add more if needed
        body.addProperty(Response_Code, httpResponse.getStatusLine().getStatusCode());
        if(!httpResponse.toString().contains("503")) {
            if (httpResponse.getEntity() != null) {
                //    body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));


                if(all_Values.has(Response_type))
                {
                    if(all_Values.get(Response_type).getAsString().equals(Text)) {
                        body.addProperty(Response_Body, EntityUtils.toString(httpResponse.getEntity()));
                    }
                }
                else {
                    body.add(Response_Body, convert_String_To_JsonObject(EntityUtils.toString(httpResponse.getEntity())));

                }
            }
        }

        if (httpResponse.toString().contains("503")) {
            //    logger.info("resp_code_Int is $$$ :" + resp_code_Int);
            //   logger.info("resp_code_Reason is $$$ :" + resp_code_Reason);
            //      Assert.assertTrue(resp_code_Int.toString().contains("503"));
            Assert.assertTrue(httpResponse.getStatusLine().getReasonPhrase().contains("Service Unavailable"));
           /* if (resp_code_Int == 503 && resp_code_Reason.equals("Service Unavailable"))
                return body;*/
        }

        ((CloseableHttpResponse) httpResponse).close();
        return body;

    }


}
