package Utilities;

import com.google.gson.JsonObject;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.*;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Certs_Folders;
import static Utilities.General_Purpose_Utilities.logger;
import static Utilities.UtilConstants.*;

public class Kafka_Utilities {

    /**
     * @param BOOTSTRAP_SERVERS
     * @return Properties for Producer Tailored to QE
     * @throws Exception
     */
    private static Properties form_Kafka_Properties_Producer(String BOOTSTRAP_SERVERS) throws Exception {

        Properties props_Kafka_Producer = new Properties();
        //General
        props_Kafka_Producer.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, UtilConstants.SSL_Config);
        props_Kafka_Producer.put(SslConfigs.SSL_PROTOCOL_CONFIG, UtilConstants.SSL_Config);

        //Needed for LPF
        props_Kafka_Producer.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, get_Certs_Folders() + UtilConstants.Cacerts_File_Name);
        props_Kafka_Producer.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, UtilConstants.Cacerts_PWD);
        props_Kafka_Producer.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);

        //Miscellaneous
        props_Kafka_Producer.put(ProducerConfig.CLIENT_ID_CONFIG, UtilConstants.Kafka_Producer_Consumer_Team);
        props_Kafka_Producer.put(ProducerConfig.RETRIES_CONFIG, 4); //If the request fails, the producer can automatically retry,
        props_Kafka_Producer.put(ProducerConfig.CLIENT_ID_CONFIG, UtilConstants.Kafka_Team_Client_ID);
        props_Kafka_Producer.put(ProducerConfig.ACKS_CONFIG, UtilConstants.Kafka_All);
        props_Kafka_Producer.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384); //Specify buffer size in config
        props_Kafka_Producer.put(ProducerConfig.LINGER_MS_CONFIG, 3); //Reduce the no of requests less than 0
        props_Kafka_Producer.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432);  //The buffer.memory controls the total amount of memory available to the producer for buffering.
        props_Kafka_Producer.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props_Kafka_Producer.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props_Kafka_Producer.put(UtilConstants.AUTO_CREATE_TOPICS_ENABLE, UtilConstants.AUTO_CREATE_TOPICS_ENABLE_FALSE);

        return props_Kafka_Producer;

    }

    /**
     * @param topic_Name
     * @return SSL IP for Kafka for current environment[Env as set in Project_Options.yaml]
     * @throws Exception
     */
    public static String get_Kafka_IP(String topic_Name) throws Exception {
        String env_Name = project_Parameters.get(Current_Region).getAsString().toLowerCase();
        if (Arrays.asList(Kafka_List_Topics_LPF).contains(topic_Name)) {
            switch (env_Name) { /*SSL IP's Only here Start*/
                case "qa":
                    return Kafka_Qa_Bootstrap_Servers_LPF;
                case "dev":
                    return Kafka_Dev_Bootstrap_Servers_LPF;
                case "dev00":
                    return Kafka_Dev_00_Bootstrap_Servers_LPF;
                case "dev01": /*@Note: Same as Dev 00 currently*/
                    return Kafka_Dev_00_Bootstrap_Servers_LPF;

            }
        }
        throw new Exception("Kafka Topic not found for PosTing - Pls Check" + topic_Name + ":In ::-" + env_Name);
    }


    /**
     * @param all_Values <br> Kafka_Topic_name
     *                   <br> Kafka_Message_Body
     *                   <br> Optional Kafka_Message_Key :Unique identifier for that posting
     * @return JsonObject os  4 values
     * <br> Kafka_Message_Key
     * <br> Kafka_Message_Body
     * <br> Kafka_Message_Partition :that was posted to
     * <br> Kafka_Message_Offset :that the message resides in
     * @throws Exception
     */
    public static JsonObject send_Kafka_Message(JsonObject all_Values) throws Exception {

        String topic_Name          = all_Values.get(Kafka_Topic_name).getAsString();
        String kafka_Message_Value = all_Values.get(Kafka_Message_Body).getAsString();
        String kafka_Key_Value     = Kafka_Message_Key;

        if (all_Values.has(Kafka_Message_Body)) {
            kafka_Key_Value = all_Values.get(Kafka_Message_Key).getAsString();
        }

        String                         ip_List                        = get_Kafka_IP(topic_Name);
        Properties                     form_Kafka_Properties_Producer = form_Kafka_Properties_Producer(ip_List);
        final Producer<String, String> producer                       = new KafkaProducer<String, String>(form_Kafka_Properties_Producer);

        if (all_Values.has(Kafka_Message_Key)) {
            kafka_Key_Value = all_Values.get(Kafka_Message_Key).getAsString();
        } else {
            kafka_Key_Value = new Date_Util().generate_Random_Using_Timestamp();
        }


        JsonObject return_Object = new JsonObject();
        try {
            final ProducerRecord<String, String> record      = new ProducerRecord<>(topic_Name, kafka_Key_Value, kafka_Message_Value);
            RecordMetadata                       metadata_01 = producer.send(record).get();

            logger.info("Message sent successfully:- Partn::" + metadata_01.partition() + ":: & Offset::" + metadata_01.offset());
            return_Object.addProperty(Kafka_Message_Key, record.key());
            return_Object.addProperty(Kafka_Message_Body, record.value());
            return_Object.addProperty(Kafka_Message_Partition, metadata_01.partition());
            return_Object.addProperty(Kafka_Message_Offset, metadata_01.offset());

        } catch (Exception x) {
            logger.info(x);
        }
        producer.close();
        return return_Object;

    }


    /**
     * @param kafka_Search_Values <br>Kafka_Message_Body
     *                            <br>Kafka_Topic_name
     *                            <br>Kafka_Message_Partition    [If Optional, Searches the entire Topic, OPTIONAL IMPORTANT::::pls give more time be4 search starts]
     *                            <br>param Kafka_Message_Offset [If Optional, returns array of messages, else only the offset message]
     *                            <br>param Kafka_Message_Key    [If Optional, Searches the message found]
     * @return Object Of Kafka_Message_Key, Kafka_Message_Body, Kafka_Message_Offset, Kafka_Message_Partition
     * @throws Exception
     */
    public static List<JsonObject> seek_Specific_Kafka_Message(JsonObject kafka_Search_Values) throws Exception {
        //Todo Mandatory

        String                              topic_Name                     = kafka_Search_Values.get(Kafka_Topic_name).getAsString();
        String                              ip_List                        = get_Kafka_IP(topic_Name);
        List<JsonObject>                    return_Object_Array            = new ArrayList<JsonObject>();
        Properties                          form_Kafka_consumer_Properties = form_Kafka_Properties_Consumer(ip_List);
        final KafkaConsumer<String, String> consumer                       = new KafkaConsumer<>(form_Kafka_consumer_Properties);
        if (kafka_Search_Values.has(Kafka_Message_Partition)) {
            final TopicPartition topic_Partition = new TopicPartition(topic_Name, kafka_Search_Values.get(Kafka_Message_Partition).getAsInt());
            consumer.assign(Collections.singleton(topic_Partition));
        }
        consumer.subscribe(Collections.singletonList(topic_Name));

        Integer kafka_Polling_Time = 0;
        if (kafka_Search_Values.has(Kafka_Message_Polling_Time))
            kafka_Polling_Time = kafka_Search_Values.get(Kafka_Message_Polling_Time).getAsInt();
        else
            kafka_Polling_Time = Kafka_Message_Polling_Time_Default;

        final ConsumerRecords<String, String> consumerRecords = consumer.poll(kafka_Polling_Time);
        //String                                value_To_Search_For       = ;
        Integer offset_To_Search_For_Swap = 0;

        if (kafka_Search_Values.has(Kafka_Message_Offset))
            offset_To_Search_For_Swap = kafka_Search_Values.get(Kafka_Message_Offset).getAsInt();

        final long offset_To_Search_Provided = offset_To_Search_For_Swap;

        consumerRecords.forEach(record -> {
            JsonObject return_Object = new JsonObject();
            Boolean    true_Flag     = false;
            String     aa            = record.key();    /*FOR TRACE during dev*/
            String     ab            = record.value();  /*FOR TRACE during dev*/
            long       ab1           = record.offset(); /*FOR TRACE during dev*/
            /*Search by Key_______________________________________________________________________*/
            if (kafka_Search_Values.has(Kafka_Message_Key)) {
                String kafka_Key = kafka_Search_Values.get(Kafka_Message_Key).getAsString();
                if (record.key().toLowerCase().equalsIgnoreCase(kafka_Key)) {
                    if (offset_To_Search_Provided == 0) /*No Offset, so accumulate all*/
                        true_Flag = true;
                    else
                        if (record.offset() == offset_To_Search_Provided)
                            true_Flag = true; /*Else offset being provided , message not matching*/
                }
            }
            /*Search by Message__________________________________________________________________*/
            else {
                String kafka_Message = kafka_Search_Values.get(Kafka_Message_Body).getAsString();
                if (record.value().toLowerCase().equalsIgnoreCase(kafka_Message)) {
                    if (offset_To_Search_Provided == 0)  /*No Offset, so accumulate all*/
                        true_Flag = true;
                    else
                        if (record.offset() == offset_To_Search_Provided)
                            true_Flag = true; /*Else offset being provided , message not matching*/
                }
            }

            if (true_Flag) {
                return_Object.addProperty(Kafka_Message_Key, record.key());
                return_Object.addProperty(Kafka_Message_Body, record.value());
                return_Object.addProperty(Kafka_Message_Offset, record.offset());
                return_Object.addProperty(Kafka_Message_Partition, record.partition());
                return_Object_Array.add(return_Object);

            }

        });
        return return_Object_Array;

    }


    public static JsonObject search_Kafka_Message(String value_To_Search_For, String Ip_Address, String topic_Name) throws Exception {
        //Todo  -  Ineficient Pls mostly Asssign partition and then search. Too long to search one by one. Create seperate method using consumer seek
        //Todo  - Check if needed?
        Properties                          form_Kafka_consumer_Properties = form_Kafka_Properties_Consumer(Ip_Address);
        JsonObject                          return_Object                  = new JsonObject();
        final int                           how_Many_Seconds_To_Poll       = 50;
        final int                           how_many_Times_B4_Give_Up      = 100;
        int                                 noRecordsCount                 = 0;
        final KafkaConsumer<String, String> consumer                       = new KafkaConsumer<>(form_Kafka_consumer_Properties);

        consumer.subscribe(Collections.singletonList(topic_Name));

        while (true) {
            final ConsumerRecords<String, String> consumerRecords = consumer.poll(how_Many_Seconds_To_Poll);
            if (consumerRecords.count() == 0) {
                noRecordsCount++;
                if (noRecordsCount > how_many_Times_B4_Give_Up)
                    break;
                else
                    continue;
            }
            int finalNoRecordsCount = noRecordsCount;
            consumerRecords.forEach(record -> {
                System.out.printf("Consumer Record From top:%s, Partition:%s, Offset:%s, %s, %s", finalNoRecordsCount, record.partition(), record.offset(), String.valueOf(record.key()), record.value());
                if (record.toString().toLowerCase().contains(value_To_Search_For.toLowerCase())) {
                    logger.info("Searched and got this: Values:" + record.value());
                    return_Object.addProperty(Kafka_Message_Body, record.value());
                    return_Object.addProperty(Kafka_Message_Key, record.key());
                    return_Object.addProperty(Kafka_Message_Offset, record.offset());
                    return_Object.addProperty(Kafka_Message_Partition, record.partition());
                }
            });
            consumer.commitAsync();
        }
        consumer.close();

        return return_Object;


    }

    private static Properties form_Kafka_Properties_Consumer(String Ip_Address) {

        final Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, Ip_Address);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, UtilConstants.Kafka_Producer_Consumer_Team);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, UtilConstants.ENABLE_AUTO_COMMIT_CONFIG_TRUE);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, UtilConstants.Kafka_MAX_POLL_RECORDS_CONFIG); //Increase for more records
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 500);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, get_Certs_Folders() + UtilConstants.Cacerts_File_Name);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, UtilConstants.Cacerts_PWD);
        props.put(SslConfigs.SSL_PROTOCOL_CONFIG, UtilConstants.SSL_Config);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, UtilConstants.SSL_Config);


        return props;
    }


}
