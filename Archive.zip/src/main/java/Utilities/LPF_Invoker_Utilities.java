package Utilities;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.yaml.snakeyaml.Yaml;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

import static Utilities.General_Purpose_Utilities.*;

public class LPF_Invoker_Utilities {


    public static ArrayList<String> form_Cucumber_Options(Map cuke_Parms) throws Exception {

        ArrayList<String> cuc_Test_Run_Options = new ArrayList<String>() {
        };

        if (cuke_Parms.containsKey("glue")) {
            cuc_Test_Run_Options.add("--glue");
            cuc_Test_Run_Options.add(cuke_Parms.get("glue").toString());
        }

        if (cuke_Parms.containsKey("plugins")) {
            cuc_Test_Run_Options.add("--plugin");
            cuc_Test_Run_Options.add(cuke_Parms.get("plugins").toString());
        }

        if (cuke_Parms.containsKey("strict")) {
            cuc_Test_Run_Options.add("-s");
        } else {
            cuc_Test_Run_Options.add("--no-strict");
        }

        if (cuke_Parms.containsKey("tags")) {
            Map tags = (Map) cuke_Parms.get("tags");


            String tag_Args = System.getProperty("tags");
            /*TODO*/
            /*If Gradle task is smoketest, it should pass '-Dsmoketest=Smoke_Tests' as properties*/
            if (tag_Args != null) {
                if (tag_Args.length() > 1) {
                    String tag_Args_Repl = tag_Args.replaceAll(" ", ",");
                    cuc_Test_Run_Options.add("--tags");
                    cuc_Test_Run_Options.add(tag_Args_Repl); /*Update from hard coded value, takes any tags from Gradle*/
                }
            } else {
                if (tag_Args != null) {
                    if (tag_Args.length() > 1) {
                        cuc_Test_Run_Options.add("--tags");
                        cuc_Test_Run_Options.add(tag_Args); /*Tags passed via Gradle*/
                    }
                } else {
                    if (tags.containsKey("File_Path_From_Project_Root")) {
                        final Map tags_Needed = new Yaml().load(new FileInputStream(new File(tags.get("File_Path_From_Project_Root").toString())));
                        if (tags.containsKey("Service_Needed")) {
                            String serv_Needed = ((Map) tags.get("Service_Needed")).get("Name").toString();
                            String tag_Set     = ((Map) tags.get("Service_Needed")).get("Tag_Set").toString();
                            String tags_To_Add = String.valueOf(((Map) tags_Needed.get(serv_Needed)).get(tag_Set));
                            cuc_Test_Run_Options.add("--tags");
                            cuc_Test_Run_Options.add(tags_To_Add);
                        } else {
                            //Todo Examples # Second Example of Tags Default tags
                            //Todo Examples # Third  Example With no Service
                        }
                    } else {
                        //Todo Examples # Second Example of Tags Default tags
                    }
                }
            }

            if (cuke_Parms.containsKey("features")) {
                cuc_Test_Run_Options.add(cuke_Parms.get("features").toString());
            } else {
                cuc_Test_Run_Options.add("src/resources/features ");
            }
        }

        //TODO add all options for cucumber here And or split smaller methods

        return cuc_Test_Run_Options;
    }

    public static Map get_This_Project_Options() throws Exception { return read_Yaml(get_project_Options_File()); }

    public static void create_Clean_Directory() throws Exception {
        File run_Data_Folder = new File(get_Run_Data_Store_Folders());

        if (!run_Data_Folder.exists()) run_Data_Folder.mkdir();

        Arrays.stream(run_Data_Folder.listFiles()).forEach(File::delete);
    }

    public static String get_Allure_Reports_Directory() throws Exception {
        Map all_Parms = new Gson().fromJson(new BufferedReader(new FileReader(get_project_Parameters_File())), Map.class);

        if (all_Parms.containsKey("Allure_Vars"))
            return all_Parms.get("Allure_Vars").toString();
        else
            return null;

    }

    public static Map get_This_Project_Parameters() throws Exception {
        write_Proj_Parameters_file_For_This_Run_Only();
        BufferedReader br = new BufferedReader(new FileReader(get_project_Parameters_File()));
        /*Keep this */
        logger.info(" Created project parameters File now + Cleaned Data Directory");
        return new Gson().fromJson(br, Map.class);
    }

    public static JsonObject replace_Env_Options_From_Os(JsonObject options_Provided, Map parameters) throws Exception {
        Iterator<Map.Entry<String, String>> aa = parameters.entrySet().iterator();
        while (aa.hasNext()) {
            Map.Entry<String, String> key = aa.next();
            if (!options_Provided.has(key.getKey())) {
                String a  = key.getKey();
                String a1 = String.valueOf(key.getValue());
                options_Provided.addProperty(a, String.valueOf(a1));
            }
        }
        return options_Provided;
    }

    public static String get_Env_Profile_From_Os() throws Exception {
        if (System.getenv("Environment_Profile") != null) { /*Jenkins Variables*/
            return System.getenv("Environment_Profile");
        } else {
            return null;
        }
    }

    public static JsonObject get_Env_Options_From_Os(ArrayList<String> options_Needed_4This_Run) throws Exception { /*Can be used for local builds also*/
        JsonObject for_Return             = new JsonObject();
        int        count_Tot_Env_Vars_Got = 0;

        for (String env_Var : options_Needed_4This_Run) {
            if (System.getenv(env_Var) != null) {
                count_Tot_Env_Vars_Got += 1;
                for_Return.addProperty(env_Var, System.getenv(env_Var));
            }
        }

        if (count_Tot_Env_Vars_Got == options_Needed_4This_Run.size())
            return for_Return; /*All variables retrieved from parametrized Run local/jenkins*/
        if (count_Tot_Env_Vars_Got == 0) return new JsonObject();      /*Non parametrized local run*/
        throw new Exception("Did not get All system Environment Variables needed for this Run, so aborting");
    }


    public static Map write_Proj_Parameters_file_For_This_Run_Only() throws Exception {
        String run_This_Profile;
        String env_Profile_From_Os = get_Env_Profile_From_Os();
        Map    cucumber_Options    = get_This_Project_Options();

        if (env_Profile_From_Os != null) {
            run_This_Profile = (String) cucumber_Options.get(env_Profile_From_Os);
        } else { /*Take the Default profile*/
            run_This_Profile = (String) cucumber_Options.get("Run_This_Profile");
        }

        Map        needed_Profile           = (Map) cucumber_Options.get(run_This_Profile);
        JsonObject got_Sys_OS_Vars4_Jenk    = get_Env_Options_From_Os((ArrayList<String>) needed_Profile.get("Parms_Needed"));

        JsonObject final_Project_Parameters = replace_Env_Options_From_Os(got_Sys_OS_Vars4_Jenk, (Map) needed_Profile.get("Project_Parameters"));


        write_Yaml(get_project_Parameters_File(), final_Project_Parameters);
        return needed_Profile;

    }

    public static String[] get_Cucumber_Options() throws Exception {

        Map               needed_Profile       = write_Proj_Parameters_file_For_This_Run_Only();
        Map               cuke_Parms           = (Map) needed_Profile.get("Cucumber_Parameters");
        ArrayList<String> cuc_Test_Run_Options = form_Cucumber_Options(cuke_Parms);
        return cuc_Test_Run_Options.toArray(new String[cuc_Test_Run_Options.size()]);

    }

}
