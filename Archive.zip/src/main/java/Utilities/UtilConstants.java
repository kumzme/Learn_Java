package Utilities;

import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class UtilConstants {


    /*Todo - @Team - Implement groups rather and name it in convention instead of multiple classes*/
    /*public interface UtilConstants
    {
        String TopLevelConstant1 = "RootLevelConstant1";
        interface Sub_Func_Consts_01 {
            String Sub_Func_Const1 = "Sub_1Constant1";
            String Sub_Func_Const2 = "Sub_1Constant2";
        }
        interface Sub_Func_Reference_Constants_02 {
            String Sub_Func_Const1 = "Sub_2Constant1";
            String Sub_Func_Const2 = "Sub_2Constant2";
        }
    }
    UtilConstants.Sub_Func_Consts_01.Sub_Func_Const1;
    UtilConstants.Sub_Func_Reference_Constants_02.Sub_Func_Const1;
    UtilConstants.TopLevelConstant1;
    */

    public static final String[] Available_Rules
            = {Refer_Rule_Generate_Loyalty_Id, Refer_Rule_Generate_Order_No, Refer_Rule_Replace_Final_Past_Date, Refer_Rule_ReplaceDaysMin, Refer_Rule_ReplaceDaysPls,
            Refer_Rule_Replace_Today, Refer_Rule_Replace_Final_Date, Refer_Rule_Replace_Time_Minus, Refer_Rule_Current_Timezone_Ts, Refer_Rule_GenerateRandomNum, Refer_Rule_GenerateRandomChar, Refer_Rule_ReplaceTstMin,
            Refer_Rule_ReplaceBarcode, Refer_Rule_Replace_Loyalty_Id, Refer_Rule_ReplaceTstPls, LPF_1342_MessageID, Refer_Rule_Replace_MessageId, Refer_Rule_Current_Date_TimeZ};
    /* Pls add any rules for generation here into UtilConstants_Data_Rules_Reference */

    public static final String  Current_Region                         = "Environment";
    public static final String  Kohls_Proxy                            = "proxy.kohls.com";
    public static final Integer Kohls_Proxy_Port                       = 3128;
    public static final String  Http_Method                            = "http";
    public static final String  Response_Code                          = "Response_Code";
    public static final String  Response_Body                          = "Response_Body";
    public static final String  Response_Code_Reason                   = "Response_Code_Reason";
    public static final String  Lcs_Data                               = "/Loyalty_Lcs_Data.yaml";
    public static final String  Balance_Lookup_Data                    = "/Data.yaml";
    public static final String  Rule_Config                            = "/Loyalty_Rule_Config.yaml";
    public static final String  Balance_Lookup                         = "/Balance_Lookup_Data.yaml";
    public static final String  HmacSHA256                             = "HmacSHA256";
    public static final String  Secret_pointConversion                 = "VUuUU6OqEcVE5eXM6rN5iFBvgMtGotNaahQJW4c2";
    public static final String  Secret_balances                        = "localtestingsecretkey"; //GYSqUleSXkB4X6Ngioc3e3MVRBLO6OZAVsBWy06V";
    public static final String  Secret_Rules                           = "reallybadsecret";
    public static final String  Secret_Audit                           = "t7oxCiU8fw7PbJLV8Ku99qy2eGEGZ8K6SZXiuqJ2";
    public static final String   Secret_Return                          = "VUuUU6OqEcVE5eXM6rN5iFBvgMtGotNaahQJW4c2";
    public static final String   Secret_Pilot                           = "e1QZ0DF56FaladusFv2LBcI2hb9MaLuSRj6ogDj1";
    public static final String   Consolidated_Data_File                 = "/Total_Data.yaml";
    public static final String   Consolidated_Sql_File                  = "/Total_Sqls.yaml";
    //
    public static final String   Non_Lcs_Data                           = "/Loyalty_Non_Lcs_Data.yaml";
    public static final String   Secret_Pilot_Checker_Put_Only          = "e1QZ0DF56FaladusFv2LBcI2hb9MaLuSRj6ogDj1";
    public static final String   Secret_Pilot_Checker_Non_Put           = "N0RaRZI6Rl0ZuMMKmZgh5ri7nSSZ6DAbi5hkWlPc";
    public static final String   Authorization                          = "Authorization";
    public static final String   X_KOHLS_CreateDateTime                 = "X-KOHLS-CreateDateTime";
    public static final String   X_KOHLS_MessageID                      = "X-KOHLS-MessageID";
    public static final String   X_KOHLS_CorrelationID                  = "X-KOHLS-CorrelationID";
    public static final String   X_KOHLS_From_SystemCode                = "X-KOHLS-From-SystemCode";
    public static final String   Api_Accept                             = "Accept";
    public static final String   Api_Accept_Json                        = "application/json";
    public static final String   Api_Accept_Language                    = "Accept-Language";
    public static final String   Api_Accept_Language_It                 = "it-IT,it";
    public static final String   Api_Content_Type                       = "Content-Type";
    /*Api Header values if needed for negative*/
    public static final String   Api_Pass_Message_Id                    = "Api_Pass_Message_Id";
    public static final String   Api_Pass_Time_Stamp                    = "Api_Pass_Time_Stamp";
    public static final String   Api_Pass_System_Cd                     = "Api_Pass_System_Cd";
    public static final String   Api_Pass_Corrln_Id                     = "Api_Pass_Corrln_Id";
    public static final String   Api_Pass_Authorization                 = "Api_Pass_Authorization";
    public static final String   Missing_Header                 = "Missing_Header";
    /*Api Header values if needed for negative*/
    public static final String   Rest_Api_Header_Name                   = "Header_Template_For_Rest";
    public static final String   AUTO_CREATE_TOPICS_ENABLE              = "auto.create.topics.enable";
    public static final String   AUTO_CREATE_TOPICS_ENABLE_FALSE        = "false";
    public static final String   ENABLE_AUTO_COMMIT_CONFIG_TRUE         = "true";
    public static final String   Cacerts_PWD                            = "changeit";
    public static final String   Cacerts_File_Name                      = "/cacerts";
    public static final String  SSL_Config                            = "SSL";
    public static final String  Kafka_Producer_Consumer_Team          = "LPF_QE";
    public static final String  Kafka_Team_Client_ID                  = "LPF_QE_Kafka_Producer_Consumer";
    public static final String  Kafka_All                             = "all";
    public static final String  Kafka_MAX_POLL_RECORDS_CONFIG         = "300";
    public static final Integer DB_MySql_AnyFree_Port                 = 4321;
    public static final String  DB_MySql_LocalHost                    = "localhost";
    public static final String  Get_Rule_Config_Latest_Version        = "Get_Rule_Config_Latest_Version";
    public static final String  MySQL_Driver_Class_Name               = "com.mysql.cj.jdbc.Driver";
    //public static final String   Mongodb_Connecttion_Dev_00           = "mongodb://user_gDpqo:XV1n0IVLYfgS1bAIoS5gTyLbX4RJUrzO@mkt-las-dev00-shard-00-00-lqhqy.gcp.mongodb.net:27017/admin?ssl=true&replicaSet=mkt-las-dev00-shard-0&authSource=admin";
    public static final String  Mongodb_Audit_Connection_Dev_00_Atlas = "mongodb://user_wVFYI:9tUtERuPjJwnhEiW@mkt-kra-dev00-shard-00-00-fuxjh.gcp.mongodb.net:27017/admin?replicaSet=mkt-kra-dev00-shard-0&authSource=admin&ssl=true";
    public static final String  Mongodb_Audit_Connection_Dev_01_Atlas = "mongodb://user_wVFYI:9tUtERuPjJwnhEiW@mkt-kra-dev01-shard-00-00-fuxjh.gcp.mongodb.net:27017,mkt-kra-dev01-shard-00-01-fuxjh.gcp.mongodb.net:27017,mkt-kra-dev01-shard-00-02-fuxjh.gcp.mongodb.net:27017/admin?replicaSet=mkt-kra-dev01-shard-0&authSource=admin&ssl=true";
    public static final String  Mongodb_Rule_Connection_Dev_00_Atlas  = "mongodb://user_w5iW3:YZY2SKzrXzFyZuPq@mkt-krrc-dev00-shard-00-00-l1bcj.gcp.mongodb.net:27017/admin?replicaSet=mkt-krrc-dev01-shard-0&authSource=admin&ssl=true";
    public static final String  Mongodb_Rule_Connection_Dev_01_Atlas  = "mongodb://user_w5iW3:YZY2SKzrXzFyZuPq@mkt-krrc-dev01-shard-00-00-l1bcj.gcp.mongodb.net:27017,mkt-krrc-dev01-shard-00-01-l1bcj.gcp.mongodb.net:27017,mkt-krrc-dev01-shard-00-02-l1bcj.gcp.mongodb.net:27017/admin?replicaSet=mkt-krrc-dev01-shard-0&authSource=admin&ssl=true";
    public static final String  Mongodb_Connection_Qa_01_Atlas        = "TBD";
    public static final String  Mongodb_Connection_Stress_01_Atlas    = "TBD";
    //public static final String   Mongodb_Connecttion_Dev_Atlas        = "mongodb+srv://user_wVFYI:9tUtERuPjJwnhEiW@mkt-kra-dev00-fuxjh.gcp.mongodb.net/admin?ssl=false&authSource=admin";
    public static final String  Mongo_DataBase_Name                    = "Mongo_DataBase_Name";
    public static final String  Mongo_Coll_Name                        = "Mongo_Coll_Name";
    public static final String  Mongo_Filter_Condition                 = "Mongo_Filter_Condition";
    public static final String  Mongo_Sort_Condition                   = "Mongo_Sort_Condition";
    public static final String  Mongo_Get_First_Condition              = "Mongo_Get_First";
    public static final String  Mongo_Count_Condition                  = "Mongo_Get_Count";
    public static final String  Mongo_Delete_Condition_One             = "Mongo_Delete_Condition_One";
    public static final String  Mongo_Delete_Condition_All             = "Mongo_Delete_Condition_All";
    /*Only 35 is SSL*/
    /*Mongo DB Names*/
    public static final String  Mongo_Db_Rewards_Audit                 = "kohlsrewardsaudit";
    public static final String  Mongo_Db_Rewards_Rule                  = "kohlsrewardsruleconfig";
    public static final String  Mongo_Db_Coll_Rewards_Audit_Activity   = "activity";
    public static final String  Mongo_Db_Coll_Rewards_Audit_Balance    = "balance";
    public static final String  Mongo_Db_Coll_Rewards_Audit_Kohls_Cash = "kohlscash";
    public static final String  Mongo_Db_Coll_Rewards_Rule             = "rule";
    /*Mongo DB Names End*/
    public static final String  Kafka_Qa_Bootstrap_Servers_LPF         = "10.186.119.35:9094";
    /*_________________*/
    public static final String  Rules_Service_Url                      = "RulesEndpoint";
    public static final String  Rules_Service                          = "/rules";
    public static final String  Pilot_Service_Url                      = "PilotEndpoint";
    public static final String  Pilot_Service_Pilot_Members            = "/pilotMembers";
    public static final String  Loyalty_Balance_Url                    = "LBLEndpoint";
    public static final String  Loyalty_Balance_Balances               = "/balances";
    /*V2 Url's Start*/
    public static final String  Audit_Balance_Service_Url              = "Audit_Balance_Service";
    public static final String  Digital_Cart_Service_Url               = "Digital_Cart_Service";
    public static final String  Spend_Tracker_Service_Url              = "Spend_Tracker_Service";
    public static final String  Audit_Balance_Service                  = "/balances";
    public static final String  Rule_Config_Service_Master_Url         = "Rule_Config_Master";
    public static final String  Rule_Config_Service_Master_Url_Invalid = "Rule_Config_Master_Invalid";
    public static final String  Month_End_Service_Master_Url           = "Month_End_Service_Master";
    public static final String  Month_End_Service_Worker_Url           = "Month_End_Service_Worker";
    public static final String  V2_Health_Check                        = "/health";
    public static final String  Month_End_Execute                      = "/execute";
    public static final String  V2_Health_Check_Actuator               = "/actuator/health";
    public static final String  Rule_Config_service                    = "/rules";
    public static final String  Rule_Config_atest                    = "/latest";
    public static final String  Rule_Config_everyday                   = "/everyday";

    public static final String  Rule_Config_service_Url                = "Rule_Config_service";
    /**/
    public static final String  LCS_Url                                = "LCSEndpoint";
    public static final String  LCS_Path_PreTender_Cart                = "/pretendercart";
    public static final String  LCS_Path_Return                        = "/return";
    public static final String  LCS_Path_Post_Sale_KC_Activation       = "/lcspostsalekcactivation";
    public static final String  LCS_Path_Spend_Tracker                 = "/spendTracker";
    public static final String  LCS_Path_Point_Conversion              = "/pointConversion";
    public static final String  LCS_Path_Earn                          = "/earn";
    public static final String  LCS_Path_Legacy_Earn                   = "/legacy/earn";
    public static final String  LCS_Path_Estimate_Product              = "/estimate/product";
    public static final String  LCS_Path_Dig_Cart_Checkout             = "/digitalcartcheckout";
    public static final String  LCS_Path_Update_Rules                  = "/updaterules";
    public static final String  LCS_Path_Update_Rules_rulesUrl_Param   = "?rulesUrl=";
    /*_________________*/
    public static final String  Kafka_Message_Body                     = "Kafka_Message_Body";
    public static final String  Kafka_Message_Key                      = "Kafka_Message_Key";
    public static final String  Kafka_Message_Offset                   = "Kafka_Message_Offset";
    public static final String  Kafka_Topic_name                       = "Kafka_Topic_name";
    public static final String  Kafka_Message_Partition                = "Kafka_Message_Partition";
    public static final String   Kafka_Message_Polling_Time             = "Kafka_Message_Polling_Time";
    public static final Integer  Kafka_Message_Polling_Time_Default     = 8000;
    public static final String   Db_QA_User                             = "Db_QA_User";
    public static final String   Db_QA_User_Pwd                         = "Db_QA_User_Pwd";
    public static final String   SSH_QA_Login                           = "SSH_QA_Login";
    public static final String   SSH_QA_Login_Pwd                       = "SSH_QA_Login_Pwd";
    public static final String   Kafka_Message_Key_LpfQE                = "Kafka_Message_Key_LpfQE";
    public static final String[] Kafka_List_Topics_LPF                  = {"MKTG_ACCOUNT_CONVERSION", "MKTG_ADJUSTMENT", "MKTG_LOYALTY_ENROLLMENT", "MKTG_LOYALTY_EVENT", "MKTG_LOYALTY_EVENT_DKC", "MKTG_LOYALTY_EVENT_RETRY_AUDIT", "MKTG_LOYALTY_PILOTACTION", "MKTG_POINT_ACTIVITY_FAILURE", "MKTG_POINT_ACTIVITY_RETRY", "MKTG_RETURN", "MKTG_SALE", "MKTG_SALE_DKC", "MKTG_SALE_RETRY_MTX", "MKTG_SHOPPER_RETRY", "MKTG_SHOPPER_RETRY_FAILURE", "MKTG_VOID", "MKTG_VOID_BALANCE"};
    /* TODO Move out start*/
    public static final String   Kafka_Dev_Bootstrap_Servers_LPF        = "10.186.119.35:9094,10.186.119.35:9094,10.186.119.36:9094";
    public static final String   Kafka_Dev_00_Bootstrap_Servers_LPF     = "10.186.112.26:9094";
    public static final String   QA01_Loyalty_Audit_Service             = "mkt-las-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    public static final String   QA01_loyalty_Audit_listener            = "mkt-las-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    public static final String   QA01_Loyalty_Balance_Lookup            = "mkt-lbl-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    public static final String   QA01_Loyalty_Cash_Service              = "mkt-lcs-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    public static final String   QA01_Loyalty_Pilot_Checker             = "mkt-lpc-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    public static final String   QA01_Loyalty_Rule_Config               = "mkt-lrc-qa01-hle-usc1a-mysql-1.tst.kohls.com";
    /* todo move out end*/
    public static final String   QA01_Loyalty_Audit_Service_DB          = "auditservices";
    public static final String   QA01_loyalty_Audit_listener_DB         = "auditservices";
    public static final String   QA01_Loyalty_Balance_Lookup_DB         = "balancelookup";
    public static final String   QA01_Loyalty_Cash_Service_DB           = "cashservice";
    public static final String   QA01_Loyalty_Pilot_Checker_DB          = "pilotchecker";
    public static final String   QA01_Loyalty_Rule_Config_DB            = "ruleconfig";
    //
    public static final String   ReplaceBarcode62487                    = "62487";
    public static final String   ReplaceBarcode62486                    = "62486";
    public static final String   ReplaceBarcode62485                    = "62485";
    //
    public static final String   DKC_Endpoint_Uri                       = "https://dkc-qa.tst.kohls.com/DKCWebService/DKCWebService/";
    public static final String   DKC_Namespace                          = "https://dkc-qa.tst.kohls.com/";
    public static final String   DKC_Service_Name                       = "DKCWebService";
    public static final String   DKC_Service_Port                       = "DKCWebServicePort";
    //public static final String Payload_DKC                          = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:dkc=\"http://kohls.com/DKCService/\"><SOAP-ENV:Header><urn:MessageHeader version=\"1.0\"><MessageID>replace_MessageID</MessageID><CreateDateTime>2016-02-11 00:00:00</CreateDateTime><From app=\"ATG\" module=\"coupon\" nodeID=\"ATG\" systemCode=\"ATG\"/></urn:MessageHeader></SOAP-ENV:Header><SOAP-ENV:Body><CreateActivateBulkRequest xmlns=\"http://kohls.com/DKCService/\"><KohlsCashBarcodeList xmlns=\"\"><KohlsCashBarcode><EventID>replace_Event_Id</EventID><Timestamp>2016-04-06T17:57:09.000-05:00</Timestamp><AdditionalCouponSource>false</AdditionalCouponSource><ScanIndicator>true</ScanIndicator><StoreNumber>873</StoreNumber><RegisterID>78</RegisterID><TransactionNumber>2000</TransactionNumber><Amount>100</Amount><QualifiedMerchandiseAmount>55.96</QualifiedMerchandiseAmount><CustomerOrderNumber>5500102950</CustomerOrderNumber><MessageType>coupon</MessageType></KohlsCashBarcode></KohlsCashBarcodeList></CreateActivateBulkRequest></SOAP-ENV:Body></SOAP-ENV:Envelope>";
    public static final String   Payload_DKC                            = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:dkc=\"http://kohls.com/DKCService/\"><SOAP-ENV:Header><urn:MessageHeader version=\"1.0\"><MessageID>1234567899812</MessageID><CreateDateTime>2016-02-11 00:00:00</CreateDateTime><From app=\"ATG\" module=\"coupon\" nodeID=\"ATG\" systemCode=\"ATG\"/></urn:MessageHeader></SOAP-ENV:Header><SOAP-ENV:Body><CreateActivateBulkRequest xmlns=\"http://kohls.com/DKCService/\"><KohlsCashBarcodeList xmlns=\"\"><KohlsCashBarcode><EventID>replace_Event_Id</EventID><Timestamp>2016-04-06T17:57:09.000-05:00</Timestamp><AdditionalCouponSource>false</AdditionalCouponSource><ScanIndicator>true</ScanIndicator><StoreNumber>873</StoreNumber><RegisterID>78</RegisterID><TransactionNumber>2000</TransactionNumber><Amount>replace_Amount</Amount><QualifiedMerchandiseAmount>55.96</QualifiedMerchandiseAmount><CustomerOrderNumber>5500102950</CustomerOrderNumber><MessageType>coupon</MessageType></KohlsCashBarcode></KohlsCashBarcodeList></CreateActivateBulkRequest></SOAP-ENV:Body></SOAP-ENV:Envelope>";
    public static final String   Payload_LBL_Create_Account             = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:ns=\"http://www.kohls.com/object/Loyalty/0.1/\"> <soapenv:Header> <urn:MessageHeader version=\"1.0\"> <urn:MessageID>0987658111</urn:MessageID> <urn:CreateDateTime>2014-06-24T10:49:52.332+05:30</urn:CreateDateTime> <urn:From app=\"Open API HTTP Client\" module=\"UpdateAccount\" nodeID=\"invkUpdateAccount\" systemCode=\"SC\"/> </urn:MessageHeader> </soapenv:Header> <soapenv:Body> <ns:loyaltyMaintainAccountRequest> <ns:payload> <ns:storeNbr>880</ns:storeNbr> <ns:origin>X</ns:origin> <ns:person> <ns:firstName>subham13</ns:firstName> <ns:middleName>I</ns:middleName> <ns:lastName>wipro13</ns:lastName> <ns:dateOfBirth>1950-12-14</ns:dateOfBirth> <ns:gender>Male</ns:gender> <ns:isKCC>0</ns:isKCC> <ns:isAssociate>1</ns:isAssociate> </ns:person> <ns:address> <ns:line1>N88W15559 Main St</ns:line1> <ns:line2>APt 1</ns:line2> <ns:city>Menomonee Falls</ns:city> <ns:state code=\"WI\" territory=\"false\">WISCONSIN</ns:state> <ns:postalCode>53051</ns:postalCode> <ns:country code=\"US\">United States</ns:country> <ns:source>ly</ns:source> <ns:lastUpdateDateTime>2014-06-24T16:27:18.147</ns:lastUpdateDateTime> </ns:address> <ns:phone> <ns:typeBase typeCode=\"loy\" typeSubCode=\"\" typeText=\"\"/> <ns:phoneNumber>324-435-4789</ns:phoneNumber> </ns:phone> <ns:emails>               <!--Zero or more repetitions:--> <ns:email> <ns:typeBase typeCode=\"loy\" typeSubCode=\"\" typeText=\"\"/> <ns:emailAddress>LOYALTYTST3@GMAIL.COM</ns:emailAddress> </ns:email> </ns:emails> <ns:tier>Kohl's Charge</ns:tier> <ns:memberSinceDate>2014-04-10T16:27:18.147</ns:memberSinceDate> </ns:payload> </ns:loyaltyMaintainAccountRequest> </soapenv:Body> </soapenv:Envelope>";
    public static final String   LBS_PAYLOAD                            = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:ns=\"http://www.kohls.com/object/Loyalty/0.1/\"> <soapenv:Header><urn:MessageHeader version=\"1.0\"></urn:MessageHeader></soapenv:Header> <soapenv:Body><ns:getShopperByRetailerIDRequest><ns:LoyaltyID>loyalty_id</ns:LoyaltyID><ns:pointChange>loyalty_points</ns:pointChange><ns:message>testmsg1</ns:message></ns:getShopperByRetailerIDRequest></soapenv:Body></soapenv:Envelope>";
    public static final String   ADJUST_POINT_SOAP_HOST                 = "https://qlty-xi11.kohls.com:8203";
    public static final String   ADJUST_POINT_SOAP_URI                  = "/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
    public static final String   CREATE_ACCOUNT_METHOD                  = "/CreateAccount";
    public static final String   CREATE_ACCOUNT_PAYLOAD                 = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:ns=\"http://www.kohls.com/object/Loyalty/0.1/\"><soapenv:Header><urn:MessageHeader version=\"1.0\"><urn:MessageID>0987658111</urn:MessageID><urn:CreateDateTime>2018-11-21T07:00:00.00+05:30</urn:CreateDateTime> <urn:From app=\"Open API HTTP Client\" module=\"UpdateAccount\" nodeID=\"invkUpdateAccount\" systemCode=\"SC\"/></urn:MessageHeader></soapenv:Header><soapenv:Body><ns:loyaltyMaintainAccountRequest><ns:payload><ns:emails><ns:email><ns:typeBase typeCode=\"loy\" typeSubCode=\"\" typeText=\"\"/><ns:emailAddress>email_id</ns:emailAddress></ns:email></ns:emails><ns:memberSinceDate>2015-10-27T07:00:00.000</ns:memberSinceDate></ns:payload></ns:loyaltyMaintainAccountRequest></soapenv:Body></soapenv:Envelope>";
    public static final String   UPDATE_MEMBER_POINT_PAYLOAD            = "<soapenv:Envelope xmlns:soapenv=\\\"http://schemas.xmlsoap.org/soap/envelope/\\\" xmlns:urn=\\\"urn:kohls:xml:schemas:message-header:v1_0\\\" xmlns:ns=\\\"http://www.kohls.com/object/Loyalty/0.1/\\\"><soapenv:Header> <urn:MessageHeader version=\\\"1.0\\\"></urn:MessageHeader></soapenv:Header><soapenv:Body><ns:getShopperByRetailerIDRequest><ns:LoyaltyID>Loyalty_Id</ns:LoyaltyID><ns:pointChange>Loyalty_Point</ns:pointChange><ns:message>testmsg1</ns:message></ns:getShopperByRetailerIDRequest></soapenv:Body></soapenv:Envelope>";
    public static final String   UPDATE_MEMBER_POINT_METHOD             = "/UpdateMemberPointBalance";
    public static       String   Rules_Version                          = "1";
    //    public static final String CREATE_ACCOUNT_ENDPOINT_URI			= "https://qlty-xi11.kohls.com:8203/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
    //    public static final String CREATE_ACCOUNT_SERVICE_PORT          = "KohlsLoyaltyOpenAPIHTTPEndpoint";//KohlsLoyaltyOpenAPIHTTPEndpoint";

}
