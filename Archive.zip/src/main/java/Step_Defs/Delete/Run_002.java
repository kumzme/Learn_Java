package Step_Defs.Delete;

import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;


public class Run_002  {
    protected static final Logger logger = get_Logger();


    @Given("I Create a step to check Check_Feature_There")
    public void i_Create_a_step_to_check_Check_Feature2() throws Throwable {
        logger.info("__2");
        logger.info(project_Parameters.get("Environment"));
    }


}
