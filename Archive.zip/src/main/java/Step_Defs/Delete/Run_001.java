package Step_Defs.Delete;

import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;

import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;


public class Run_001 {
    protected static final Logger logger = get_Logger();


    @Given("I Create a step to check Check_Feature")
    public void i_Create_a_step_to_check_Check_Feature() throws Throwable {
        logger.info("__1");
        logger.info(project_Parameters.get("Environment"));
        logger.info(consolidated_Data.get("Kafka_Sample_Payload"));
    }

    @Given("I Create a {string} to check Check_Feature")
    public void i_Create_a_to_check_Check_Feature22(String arg1) throws Throwable {
        logger.info("_");

    }

}
