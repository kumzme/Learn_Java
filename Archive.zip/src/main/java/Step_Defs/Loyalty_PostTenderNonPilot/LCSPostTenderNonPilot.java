
package Step_Defs.Loyalty_PostTenderNonPilot;

import Utilities.Date_Util;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.LPF_Invoker_Utilities.get_This_Project_Parameters;
import static Utilities.UtilConstants.Lcs_Data;
import static Utilities.UtilConstants.Response_Code;
import static org.junit.Assert.assertEquals;


public class LCSPostTenderNonPilot {

	protected static final Logger logger = LogManager.getLogger(new Object().getClass().getSimpleName());

	String sdf1;
	private Map raw_Headers, raw_Headers_get, project_Options, rule_config, lcs_Data;
	private JsonObject response;
	private String loyalty_Id, version;
	private String service_Name, service_Path, raw_Payload_get, pilot_base_Url, full_Url, raw_Payload,
			XKohls_Message_ID, secretKey, sys_Cd, corr_Id, message_Hdr, method_Name;
	private static boolean got_Parms = false;
	Date_Util dateUtil = new Date_Util();

	/*
	 * @Before public void setUpForLoyalty_Steps(Scenario Loyalty_Lcs) throws
	 * Exception{ String scenario = Loyalty_Lcs.getName(); // Needed ? Todo
	 * logger.info(scenario); }
	 *
	 * @Given("I am able to retrieve and set the project environment data for LCSPreTender$"
	 * ) public void setUpFor_Rule_Config_Steps() throws Exception {
	 * this.project_Options = get_This_Project_Parameters();
     * logger.info("project_Options "+project_Options); }
	 */

	@Given("I am able to retrieve and set the project environment data for LCSpostTenderNonPilot")
	public void setUpFor_Rule_Config_Steps() throws Exception {
		this.project_Options = get_This_Project_Parameters();
        logger.info("project_Options " + project_Options);
	}

	/*
	 * POST Tender non pilot starts
	 */

	@Given("Connected with {string} service to {string} for {string} type for LCSpostTenderNonPilot")
	public void serviceConnection(String service_NameFrom_Feature, String endpoint, String testCase) throws Exception {
		service_Name = service_NameFrom_Feature;
		this.pilot_base_Url = this.project_Options.get(endpoint).toString();
        logger.info("urls   " + pilot_base_Url);
		logger.info("service_Name " + service_Name + " for testcase +" + testCase);
	}

	@When("I {string} to LCSpostTenderNonPilot type with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
	public void formatHeaderPreTender(String methodType, String format, String standard_Post_Header,
			String xKOHLS_From_System_Code, String xKOHLS_Correlation_ID, String xKOHLS_Message_ID, String secretKey)
			throws Exception {
		this.service_Path = "/" + this.service_Name;
        logger.info("xKOHLS_Correlation_ID " + xKOHLS_Correlation_ID);
        logger.info("xKOHLS_Message_ID " + xKOHLS_Message_ID);
		this.sdf1 = generate_Header_Date_TS();
		this.XKohls_Message_ID = xKOHLS_Message_ID;
		this.secretKey = secretKey;
		this.corr_Id = xKOHLS_Correlation_ID;
		this.sys_Cd = xKOHLS_From_System_Code;
		this.message_Hdr = standard_Post_Header;
		this.method_Name = methodType;
        logger.info("corr_Id " + corr_Id);
        logger.info("XKohls_Message_ID " + XKohls_Message_ID);

	}

	@When("I have create the payload for LCSpostTenderNonPilot Test Case Number {string} with loyaltyID as {string} storeNumber as {string} departmentOne as {string} skuOne as {string} yourPriceOne as {string} quantityOne as {string} departmenTwo as {string} skuTwo as {string} yourPriceTwo as {string} quantityTwo as {string} departmentThree as {string} skuThree as {string} yourPriceThree as {string} quantityThree as {string} typeCode as {string} tenderAmount as {string} transactionDate as {string} for payload as {string}")
	public void I_Post_PayloadPreTender_LoyaltyID(String testCaseNumber, String localtyID, String storeNumber, String department1, String sku1,
			String yourPrice1, String quantity1, String department2, String sku2, String yourPrice2, String quantity2,
			String department3, String sku3, String yourPrice3, String quantity3, String typeCode, String tenderAmount, String transactionDate,
			String payload) throws Exception {

		lcs_Data = read_Yaml(get_Data_Folders() + Lcs_Data);
		raw_Payload = (String) lcs_Data.get(payload);
		String TransactionDate = dateUtil.returndate(1);
		
		if(testCaseNumber.contains("Test_007") || testCaseNumber.contains("Test_008")
				|| testCaseNumber.contains("Test_009") || testCaseNumber.contains("Test_010")
				|| testCaseNumber.contains("Test_011") || testCaseNumber.contains("Test_012")) {
			raw_Payload = raw_Payload.replace("replace_loyaltyId", localtyID).replace("replace_storeNumber", storeNumber)
					.replace("replace_department1", department1).replace("replace_sku1", sku1)
					.replace("replace_yourPrice1", yourPrice1).replace("replace_quantity1", quantity1)
					.replace("replace_department2", department2).replace("replace_sku2", sku2)
					.replace("replace_yourPrice2", yourPrice2).replace("replace_quantity2", quantity2)
					.replace("replace_department3", department3).replace("replace_sku3", sku3)
					.replace("replace_yourPrice3", yourPrice3).replace("replace_quantity3", quantity3)
					.replace("replace_typeCode", typeCode).replace("replace_tenderAmount", tenderAmount)
					.replace("replace_transactionDate", TransactionDate);
		}else {
			raw_Payload = raw_Payload.replace("replace_loyaltyId", localtyID).replace("replace_storeNumber", storeNumber)
					.replace("replace_department1", department1).replace("replace_sku1", sku1)
					.replace("replace_yourPrice1", yourPrice1).replace("replace_quantity1", quantity1)
					.replace("replace_typeCode", typeCode).replace("replace_tenderAmount", tenderAmount);
			if(testCaseNumber.contains("Test_015")) {
				raw_Payload = raw_Payload.replace("replace_transactionDate", "");
			}else {
				raw_Payload = raw_Payload.replace("replace_transactionDate", TransactionDate);
			}
		}

        logger.info("The payload is: " + raw_Payload);

		String encoded_Auth_String = getSignatureForPOSTCallSpendTrackerMash(raw_Payload, service_Path,
				XKohls_Message_ID, secretKey, sdf1);
        logger.info("corr_Id " + corr_Id);
		this.raw_Headers = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id,
				method_Name.toLowerCase(), encoded_Auth_String);

        logger.info("The raw_headers url for PreTender is: " + this.raw_Headers);
		full_Url = this.pilot_base_Url + service_Path;
        logger.info("The full url is: " + full_Url);

		response = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

        logger.info("The response of PreTender: " + response);
        logger.info("The response Code of PreTender:'\n' " + response.get(Response_Code));
		logger.info(response.get(Response_Code));

	}

	@Then("I should be able to verify the LCSpostTenderNonPilot Response of test case number {string} as {string}")
	public void verifyPostTenderNonPilot(String testCaseNum, String success_Or_Fail) throws Throwable {
		if(testCaseNum.contains("Test_013")) {
			assertEquals(true, this.response.get("Response_Body").toString().contains("Invalid request parameter: yourPrice"));
			assertEquals(success_Or_Fail, this.response.get(Response_Code).toString());
		}else if(testCaseNum.contains("Test_014")) {
			assertEquals(true, this.response.get("Response_Body").toString().contains("Invalid Signature"));
			assertEquals(success_Or_Fail, this.response.get(Response_Code).toString());
		}else if(testCaseNum.contains("Test_015")) {
			assertEquals(success_Or_Fail, this.response.get(Response_Code).toString());
			assertEquals(true, this.response.get("Response_Body").toString().contains("\"eventKohlsCashEarnTol\":10"));
			assertEquals(true, this.response.get("Response_Body").toString().contains("\"earnThresholdforEventKc\":10"));
			assertEquals(true, this.response.get("Response_Body").toString().contains("\"transKcAmountToActivateTol\":10"));
			assertEquals(true, this.response.get("Response_Body").toString().contains("\"qualifyingPurchaseAmount\":60"));
		}
		else
			assertEquals(success_Or_Fail, this.response.get(Response_Code).toString());
	}

}
