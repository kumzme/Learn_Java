package Step_Defs.XHooks;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.log4j.Logger;

import static Utilities.General_Purpose_Utilities.*;
import static Utilities.LPF_Invoker_Utilities.get_This_Project_Parameters;
import static Utilities.UtilConstants.Consolidated_Data_File;
import static Utilities.UtilConstants.Consolidated_Sql_File;

public class Hooks {

    protected static final Logger logger = get_Logger();

    @Before
    public void beforeScenario(Scenario scenario) throws Exception {

        /*
            StackTraceElement[] aaa = Thread.currentThread().getStackTrace();
            for (StackTraceElement stackTraceElement : aaa) {
                logger.info(stackTraceElement.getClassName().toString());
            }
        */

        /* Todo @Team  Check for Dup keys and warn when building */
        /* Todo @Team  Perform anything here that is needed for whole project */
        Project_Before_Hooks.scenario_Name = scenario.getName().toLowerCase();

        if (Project_Before_Hooks.project_Parameters.entrySet().size() <= 0) {
            Project_Before_Hooks.before_Methods();
            String data_Path = get_Run_Data_Store_Folders() + Consolidated_Data_File;
            String sql_Path  = get_Run_Data_Store_Folders() + Consolidated_Sql_File;

            /*Project Parameters Project Options Yaml*/
            Project_Before_Hooks.project_Parameters = convert_Map_To_JsonObject(get_This_Project_Parameters());

            /*All Data from "src/main/resources/Data_Folders"*/
            Project_Before_Hooks.consolidated_Data = convert_Map_To_JsonObject(read_Yaml(data_Path));

            /*All Data from "src/main/resources/SQL_Folders"*/
            Project_Before_Hooks.consolidated_Sql = convert_Map_To_JsonObject(read_Yaml(sql_Path));

            logger.info("Hooks executed...");
        }

    }

    @After
    public void afterScenario() throws Exception {

    }

}
