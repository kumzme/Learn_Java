package Step_Defs.XHooks;

import com.google.gson.JsonObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

import static Utilities.General_Purpose_Utilities.consolidate_Data;
import static Utilities.General_Purpose_Utilities.consolidate_Sql;
import static Utilities.LPF_Invoker_Utilities.*;

public class Project_Before_Hooks {

    public static JsonObject    project_Parameters = new JsonObject();
    public static JsonObject    consolidated_Data  = new JsonObject();
    public static String        scenario_Name      = "";
    public static JsonObject    consolidated_Sql   = new JsonObject();
    public static MongoClient   client_for_Rule    = new MongoClient();
    public static MongoDatabase db;
    /*Add Any other Vars needed that needs to be Run at one go :: Above only*/
    /*Do not Use in project Start*/
    public static String[]      cucke_Options;
    public static ClassLoader   contextClassLoader;
    /*Do not Use in project End*/

    public static void before_Methods() throws Exception {
        create_Clean_Directory();
        cucke_Options = get_Cucumber_Options();
        String allure_Dir = get_Allure_Reports_Directory();
        contextClassLoader = Thread.currentThread().getContextClassLoader();
        consolidate_Data();
        consolidate_Sql();

        if (allure_Dir != null) System.setProperty("allure.results.directory", allure_Dir);
    }

    public static byte invoke_Project() throws Exception {

        before_Methods();
        return cucumber.api.cli.Main.run(cucke_Options, contextClassLoader);


    }


}
