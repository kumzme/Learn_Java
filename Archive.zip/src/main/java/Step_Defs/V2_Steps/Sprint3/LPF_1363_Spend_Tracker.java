package Step_Defs.V2_Steps.Sprint3;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.junit.Assert;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_Functional_Utilities.create_New_Loyalty_ID;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Service_Functions.V2.V2_Digital_Cart_Service.get_Digital_Cart_Details_Negative;
import static Service_Functions.V2.V2_Rule_Config_Functions.post_Rule_Config;
import static Service_Functions.V2.V2_Spend_Tracker_Service.get_Spend_Tracker_Details;
import static Service_Functions.V2.V2_Spend_Tracker_Service.get_Spend_Tracker_Details_Negative;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static io.qameta.allure.Allure.addAttachment;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LPF_1363_Spend_Tracker {

	protected static final Logger logger = get_Logger();

	JsonObject result_Object = new JsonObject();
	JsonObject this_Object = new JsonObject();
	JsonObject message_Posted = new JsonObject();
	JsonObject sale_message_Posted = new JsonObject();
	JsonObject kafka_Object_Res_For_Sale;
	JsonObject service_body_negative = new JsonObject();
	JsonObject negative_this_Object = new JsonObject();
	
	String code;
	String spentTrackerPayload = "1363_Sc1_Ex1_Service_Payload";
	String randomLoyaltyID;
	String loyaltyId = null;

	@Given("Audit DB,audit services,rule config,audit POD should be up and running for spent tracker")
	public void audit_DB_audit_services_rule_config_audit_POD_should_be_up_and_running_for_spent_tracker() {
		logger.info("PODs Up and Running");
	}

	// SC-1
	@Given("loyaltyID has {string} existing in earn tracker balance for spent tracker with {string}")
	public byte[] loyaltyid_has_existing_in_earn_tracker_balance_for_spent_tracker_with(String balanceVlaue,
			String payload) throws Exception {
		String raw_Payload = parse_And_Generate_Data("1363_Rule_Payload", this_Object);
		System.out.println("raw_Payload is $$$ :" + raw_Payload);
		Allure.addAttachment("Payload::", raw_Payload);
		post_Rule_Config(raw_Payload);

		this_Object.addProperty(Reference_Payload, payload);
		kafka_Object_Res_For_Sale = Post_Sales(this_Object);
		message_Posted = convert_String_To_JsonObject(kafka_Object_Res_For_Sale.get(Kafka_Message_Body).getAsString());
		loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();

		payload = consolidated_Data.get(spentTrackerPayload).getAsString();
		System.out.println("Loyalty Id is $$$$$$ : " + loyaltyId);
		String loyaltyIdForSTService = payload.replace("Loyalty_Id", loyaltyId); // '{"loyaltyId": "Loyalty_Id"}'
		result_Object = get_Spend_Tracker_Details(loyaltyIdForSTService);
		//Allure.addAttachment("Response::", result_Object.get(Response_Code).getAsString());

		logger.info("Response_spent_tracker  $$$$$$ " + result_Object);
		logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_Res_For_Sale);
		return payload.getBytes();
	}

	@When("LCS - Rewards Spend Tracker Service is hit with set data,Valid headers")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_set_data_Valid_headers() {
		System.out.println("Written in Given");
	}

	@Then("LCS - Rewards Spend Tracker Service should respond successfully {string}")
	public void lcs_Rewards_Spend_Tracker_Service_should_respond_successfully(String validation) {
		String expected = consolidated_Data.get(validation).getAsString();
		String actual = result_Object.toString();
		assertEquals("Spent Tracker value is  ", actual, expected);
	}

	// SC-2
	@Given("loyaltyID is not present in Audit DB")
	public void loyaltyid_is_not_present_in_Audit_DB() throws Exception {
		randomLoyaltyID = create_New_Loyalty_ID();
		String payload = consolidated_Data.get(spentTrackerPayload).getAsString();
		String loyaltyIdForSTService = payload.replace("Loyalty_Id", randomLoyaltyID);
		result_Object = get_Spend_Tracker_Details(loyaltyIdForSTService);

		logger.info("Loyalty Id $$$ " + randomLoyaltyID);
		logger.info("Response_spent_tracker  $$$$$$ " + result_Object);
	}

	@Then("LCS - Rewards Spend Tracker Service should respond successfully")
	public void lcs_Rewards_Spend_Tracker_Service_should_respond_successfully() {
		String expected = consolidated_Data.get("1363_Sc2_Ex1_Payload_Validation").getAsString();
		String actual = result_Object.toString();
		assertEquals("Spent Tracker value is  ", actual, expected);
	}

	// SC-3
	@Given("Loyalty Id as {string} and {string}")
	public void loyalty_Id_as_and(String value, String data) throws Exception {
		String loyalty = data;
		String payload = consolidated_Data.get(spentTrackerPayload).getAsString();
		String loyaltyIdForSTService = payload.replace("Loyalty_Id", loyalty);
		result_Object = get_Spend_Tracker_Details(loyaltyIdForSTService);
		//code = result_Object.get("Response_Code").getAsString();
		logger.info("Loyalty Id $$$ " + loyalty);
		logger.info("Response_spent_tracker  $$$$$$ " + result_Object);
	}

	@Then("LCS - Rewards Spend Tracker Service should respond with {string}")
	public void lcs_Rewards_Spend_Tracker_Service_should_respond_with(String status_code) {
		if (status_code.equals("200"))
			assertTrue(result_Object.get(Response_Code).getAsString().equals(status_code));
		else if (status_code.equals("500"))
			assertTrue("400".equals(status_code));
	}

	// SC-4
	@Given("Loyalty Id value as empty")
	public void loyalty_Id_value_as_empty() throws Exception {
		String payload = consolidated_Data.get(spentTrackerPayload).getAsString();
		String loyaltyIdForSTService = payload.replace("Loyalty_Id", " ");
		result_Object = get_Spend_Tracker_Details(loyaltyIdForSTService);
		//code = result_Object.get("Response_Code").getAsString();
		logger.info("Response_spent_tracker  $$$$$$ " + result_Object);
	}

	@Then("LCS - Rewards Spend Tracker Service should responds with {string} status code")
	public void lcs_Rewards_Spend_Tracker_Service_should_respond_with_status_code(String statusCode) {
		if (statusCode.equals("400"))
			assertTrue("400".equals(statusCode));
	}

	@Then("Error message as {string}")
	public void error_message_as(String string) {
		logger.info("string");
	}

	// SC-5
	@When("LCS - Rewards Spend Tracker Service is hit with invalid value for {string} with header values {string} {string} {string} {string} {string}")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_invalid_value_for_with_header_values(String header,
			String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String status_code)
			throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();

		/* sending invalid header values from feature */
		if (CreateDateTime.equals("Dynamic"))
			CreateDateTime = generate_Header_Date_TS();
		else
			CreateDateTime = "9999-01-27T20:00:23+0530";

		negative_this_Object.addProperty("message_Id", MessageID);
		negative_this_Object.addProperty("time_Stamp", CreateDateTime);
		negative_this_Object.addProperty("system_Cd", SystemCode);
		negative_this_Object.addProperty("corrln_Id", CorrelationID);
		negative_this_Object.addProperty("API_KEY", "MASH");
		negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

		if (status_code.equals("400") || status_code.equals("401"))
			negative_this_Object.addProperty("400_example", "400_example");

		// passing invalid msg id
		if (MessageID.contains("wrong"))
			negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");
		

		String payload = consolidated_Data.get("1363_Sc1_Ex1_Service_Payload").getAsString();
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

		negative_this_Object.addProperty("body_Payload", payload);
		service_body_negative = get_Spend_Tracker_Details_Negative(negative_this_Object);

		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS - Rewards Spend Tracker Service service should provide {string}")
	public void lcs_Rewards_Spend_Tracker_Service_service_should_provide(String status_code) {
		System.out.println("Assertions are completed in utility for negative test cases...");
		if (status_code.equals("200"))
			assertTrue(service_body_negative.get(Response_Code).getAsString().equals(status_code));
	}

	// SC-6
	@When("LCS - Rewards Spend Tracker Service is hit with {string} for Authorization header with Authorization values as {string} {string}")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_for_Authorization_header_with_Authorization_values_as(
			String string, String header_key, String header_secret) throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();

		negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
		negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
		negative_this_Object.addProperty("system_Cd", "1231");
		negative_this_Object.addProperty("corrln_Id", "lpfqe");
		negative_this_Object.addProperty("API_KEY", header_key);
		negative_this_Object.addProperty("SecretKey", header_secret);

		negative_this_Object.addProperty("400_example", "400_example");
		if (header_secret.equals("empty_secret")) {
			negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
		}

		String payload = consolidated_Data.get("1363_Sc1_Ex1_Service_Payload").getAsString();
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

		negative_this_Object.addProperty("body_Payload", payload);
		service_body_negative = get_Spend_Tracker_Details_Negative(negative_this_Object);

		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS - Rewards Spend Tracker Service should provide {string} status code")
	public void lcs_Rewards_Spend_Tracker_Service_should_provide_status_code(String value) {
		System.out.println("Assertions are completed in utility for negative test cases...");
	}

	// SC-7
	@When("LCS - Rewards Spend Tracker Service is hit with no value for {string} with header values {string} {string} {string} {string} {string} {string}")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_no_value_for_with_header_values(String header,
			String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key,
			String Status_Code) throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();

		// sending invalid header values from feature
		if (CreateDateTime.equals("Dynamic"))
			CreateDateTime = generate_Header_Date_TS();
		else
			CreateDateTime = "";

		negative_this_Object.addProperty("message_Id", MessageID);
		negative_this_Object.addProperty("time_Stamp", CreateDateTime);
		negative_this_Object.addProperty("system_Cd", SystemCode);
		negative_this_Object.addProperty("corrln_Id", CorrelationID);
		negative_this_Object.addProperty("API_KEY", "MASH");
		negative_this_Object.addProperty("SecretKey", Secret_Key);

		// Based on this property, we will remove message id in utility
		if (header.equals("X-KOHLS-MessageID"))
			negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

		if (header.equals("X-KOHLS-CreateDateTime"))
			negative_this_Object.addProperty("Remove_date", "Remove_date");

		if (Status_Code.equals("400") || Status_Code.equals("401"))
			negative_this_Object.addProperty("400_example", "400_example");

		String payload = consolidated_Data.get("1363_Sc1_Ex1_Service_Payload").getAsString();
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

		negative_this_Object.addProperty("body_Payload", payload);
		service_body_negative = get_Spend_Tracker_Details_Negative(negative_this_Object);

		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());

	}

	// SC-8-missing values
	@When("LCS - Rewards Spend Tracker Service is hit with {string} for Headers")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_for_Headers(String string) throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();

		negative_this_Object.addProperty("message_Id", "");
		negative_this_Object.addProperty("time_Stamp", "");
		negative_this_Object.addProperty("system_Cd", "");
		negative_this_Object.addProperty("corrln_Id", "");
		negative_this_Object.addProperty("API_KEY", "MASH");
		negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

		// Remove headers in utility based on this property
		negative_this_Object.addProperty("No_Header", "No_Header");
		negative_this_Object.addProperty("400_example", "400_example");
		String payload = consolidated_Data.get("1363_Sc1_Ex1_Service_Payload").getAsString();
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

		System.out.println("payload of service is $$$ :" + payload);
		negative_this_Object.addProperty("body_Payload", payload);
		service_body_negative = get_Spend_Tracker_Details_Negative(negative_this_Object);

		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	// SC-9
	@Given("Bring LCS pod down")
	public void bring_LCS_pod_down() {
		logger.info("LCS POD DOWN");
	}

	// SC-9
	@When("LCS - Rewards Spend Tracker Service is hit with valid request fields,Valid headers")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_valid_request_fields_Valid_headers() {
		logger.info("Hiiting service");
	}

	
	// SC-10 Invalid URL
	@When("LCS - Rewards Spend Tracker Service is hit with invalid endpoint")
	public void lcs_Rewards_Spend_Tracker_Service_is_hit_with_invalid_endpoint() throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();

		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
		this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
		this_Object.addProperty("system_Cd", "1231");
		this_Object.addProperty("corrln_Id", "lpfqe");
		this_Object.addProperty("API_KEY", "MASH");
		this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");
		this_Object.addProperty("503_example", "503_example");

		this_Object.addProperty("Invalid_URL", "Invalid_URL");
		String payload = consolidated_Data.get("1363_Sc1_Ex1_Service_Payload").getAsString();
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

		System.out.println("payload of service is $$$ :" + payload);
		this_Object.addProperty("body_Payload", payload);
		service_body_negative = get_Spend_Tracker_Details_Negative(this_Object);

		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("messages should be displayed as {string}")
	public void messages_should_be_displayed_as(String string) {
		logger.info(string);
	}
	//SC-11
	@Given("rule config should be up and running")
	public void rule_config_should_be_up_and_running() throws Exception {
		String raw_Payload = parse_And_Generate_Data("1363_Rule_Payload", this_Object);
		System.out.println("raw_Payload is $$$ :" + raw_Payload);
		post_Rule_Config(raw_Payload);
	}

	@Given("Bring audit POD,audit DB down")
	public void bring_audit_POD_audit_DB_down() {
		logger.info("Audit Pod down");
	}
	
	@Then("LCS - Rewards Spend Tracker Service should respond with {string} status code")
	public void lcss_Rewards_Spend_Tracker_Service_should_respond_with_status_code(String Status_Code) {
		assertTrue("500".equals(Status_Code));
		}
	
	//SC-12
	@When("LCS Cart & Checkout Sprnd Tracker Service is hit with {string} for Headers with header values null {string} {string} {string} {string} {string} {string}")
	public void lcs_Cart_Checkout_Sprnd_Tracker_Service_is_hit_with_for_Headers_with_header_values_null(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
		randomLoyaltyID = generateLoyaltyIdRandom();
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "null";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);
        if (MessageID.contains("null"))
            negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");


        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        String     payload           = parse_And_Generate_Data("1363_Sc1_Ex1_Service_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", randomLoyaltyID);

        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Spend_Tracker_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS Cart & Checkout Sprnd Tracker Service should provide {string} for null headers")
	public void lcs_Cart_Checkout_Sprnd_Tracker_Service_should_provide_for_null_headers(String string) {
		System.out.println("assertions are complete in utility for negative cases...");
		if(string.equals("200"))
			Assert.assertEquals("200",service_body_negative.get("Response_Code").getAsString());
	}
	
}
