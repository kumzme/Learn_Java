package Step_Defs.V2_Steps.Sprint3;

import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Event;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.scenario_Name;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static io.qameta.allure.Allure.addAttachment;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class LPF_1373_Audit_To_consume_Event_Messages_For_Pilot_Customer {

    protected static final Logger logger = get_Logger();
    JsonObject current_Scenario                  = new JsonObject();
    JsonObject actvty_DbRow                      = new JsonObject();
    JsonObject send_Object                       = new JsonObject();
    JsonObject posted_Object                     = new JsonObject();
    JsonObject result_Object                     = new JsonObject();
    JsonObject sale_Result_Object                = new JsonObject();
    String     dup_ActivityDateTime              = null;
    String     loyalty_Id                        = null;
    Double     curr_Earning                      = 0.000;
    String     raw_Payload                       = null;
    String     preserve_Dup_Payload              = null;
    String     Dup_Message_Processed             = "Dup_Message_Processed";
    String     Reference_Scenario_Sale_And_Event = "Reference_Scenario_Sale_And_Event";
    JsonObject raw_Payload_Object                = null;



    @Given("Audit POD,Audit DB should be up and running for {string}")
    public void audit_POD_Audit_DB_should_be_up_and_running_for(String string) throws Exception { // /*Todo Remove */ clear_Activity_And_Balance(Mongo_Delete_Condition_All);
        current_Scenario = new JsonObject();
        loyalty_Id = null;
        send_Object = new JsonObject();
        current_Scenario.addProperty(Reference_Scenario, string);
    }


    @And("Same Event message has been dropped into MKTG_EVENT topic for {string}")
    public void dupl_Msg_Drop(String string) throws Exception {
        send_Object.addProperty(Reference_Payload_Updated, preserve_Dup_Payload);
        posted_Object = Post_Event(send_Object);
        Thread.sleep(2000);
    }


    @When("Event message is dropped into MKTG_EVENT topic")
    public void event_message_is_dropped_into_MKTG_EVENT_topic() throws Exception {
        send_Object = new JsonObject();
        if (current_Scenario.has(Reference_Scenario_Sale_And_Event))
            send_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyalty_Id);

        raw_Payload = parse_And_Generate_Data(current_Scenario.get(Reference_Scenario).getAsString() + Event_Payload, send_Object);
        raw_Payload_Object = convert_String_To_JsonObject(raw_Payload);

        if (scenario_Name.contains("duplicate")) preserve_Dup_Payload = raw_Payload;

        if (raw_Payload_Object.get("messageBody").getAsJsonObject().has("loyaltyId")) {
            if (!current_Scenario.has(Reference_Scenario_Sale_And_Event)) {
                loyalty_Id = raw_Payload_Object.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
                clear_Activity_And_Balance(loyalty_Id);
            }
        } else {
            loyalty_Id = null;
            clear_Activity_And_Balance(Mongo_Delete_Condition_All);
        }
        send_Object.addProperty(Reference_Payload_Updated, raw_Payload);
        posted_Object = Post_Event(send_Object);

        Thread.sleep(2000);

        result_Object = convert_String_To_JsonObject(posted_Object.get(Kafka_Message_Body).getAsString());
        addAttachment("My attachment", posted_Object.get(Kafka_Message_Body).getAsString());

    }

    @Then("Activity table is updated")
    public void activity_table_is_updated() throws Exception {

        if (loyalty_Id == null)
            loyalty_Id = result_Object.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();

        if (current_Scenario.has(Reference_Scenario_Sale_And_Event))
            actvty_DbRow = get_Rewards_Activity_Rows(loyalty_Id).get("2").getAsJsonObject();
        else actvty_DbRow = get_Rewards_Activity_First_Row(loyalty_Id);

        JsonObject amount           = actvty_DbRow.get("amount").getAsJsonObject();
        String     activityDateTime = actvty_DbRow.get("activityDateTime").getAsJsonObject().get("$date").getAsString();
        String     createdOn        = actvty_DbRow.get("createdOn").getAsJsonObject().get("$date").getAsString();

        if (current_Scenario.has(Dup_Message_Processed)) assertEquals(dup_ActivityDateTime, activityDateTime);
        if (scenario_Name.contains("duplicate")) dup_ActivityDateTime = activityDateTime;

        assertTrue(actvty_DbRow.get("_id").getAsJsonObject().get("$oid").getAsString().length() > 3);
        assertTrue(activityDateTime != null);
        assertTrue(createdOn != null);
        assertEquals("activityTypeCode Assertion:", actvty_DbRow.get("activityTypeCode").getAsInt(), 00);
        assertTrue(actvty_DbRow.get("activityDesc").getAsString().equalsIgnoreCase("EVENT"));
        assertTrue(actvty_DbRow.get("loyaltyId").getAsString().equalsIgnoreCase(loyalty_Id));
        assertTrue(actvty_DbRow.get("alternateId").getAsString().equalsIgnoreCase(result_Object.get("messageBody").getAsJsonObject().get("correspondingId").getAsString()));
        assertTrue(amount.get("everydayKcc").getAsInt() == 00);
        assertTrue(amount.get("everydayNonkcc").getAsDouble() == result_Object.get("messageBody").getAsJsonObject().get("earningAmt").getAsDouble());
        assertTrue(amount.get("everydayImpactAmt").getAsDouble() == result_Object.get("messageBody").getAsJsonObject().get("earningAmt").getAsDouble());

    }

    @Then("Balance table is updated with updated balance")
    public void balance_table_is_updated_with_updated_balance() throws Exception {
        JsonObject balance_DbRow = get_Rewards_Balance_First_row(loyalty_Id);
        assertEquals("Final Updated balance:", balance_DbRow.get("updatedBalance").getAsDouble(), result_Object.get("messageBody").getAsJsonObject().get("earningAmt").getAsDouble() + curr_Earning);
    }


    @Step
    @Attachment
    @Then("message is filtered by audit listener")
    public void message_is_filtered_by_audit_listener() throws Exception {
        if (loyalty_Id == null) {
            JsonObject tot_Counts = count_Of_All_Audit_Collections();
            assertEquals("Assert there is no Rows in Audit Activity:", tot_Counts.get(Mongo_Db_Coll_Rewards_Audit_Balance).getAsDouble(), 00);
            assertEquals("Assert there is no Rows in Audit Balance:", tot_Counts.get(Mongo_Db_Coll_Rewards_Audit_Activity).getAsDouble(), 00);
        } else {
            if (scenario_Name.contains("duplicate")) {
                current_Scenario.addProperty(Dup_Message_Processed, "");
                activity_table_is_updated();
                balance_table_is_updated_with_updated_balance();
            } else {
                assertEquals("No Rows in Balance:", get_Rewards_Balance_First_row(loyalty_Id), null);
            }
        }
        addAttachment("My attachment", "My attachment content");

    }

    @Given("Loyalty ID with existing earntracker updated balance as {string}")
    public void loyalty_ID_with_existing_earntracker_updated_balance_as(String string) throws Exception {
        curr_Earning = 0.000;
        String sc_Name = current_Scenario.get(Reference_Scenario).getAsString() + Sale_Payload;
        if (consolidated_Data.has(sc_Name)) {
            current_Scenario.addProperty(Reference_Scenario_Sale_And_Event, string);
            raw_Payload = parse_And_Generate_Data(sc_Name, new JsonObject());
            raw_Payload_Object = convert_String_To_JsonObject(raw_Payload);
            loyalty_Id = raw_Payload_Object.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
            String curr_Earning_01 = raw_Payload_Object.get("messageBody").getAsJsonObject().get("earnDetail").getAsJsonObject().get("everydayKccEarned").getAsString();
            if (curr_Earning_01.equalsIgnoreCase("0.00"))
                curr_Earning_01 = raw_Payload_Object.get("messageBody").getAsJsonObject().get("earnDetail").getAsJsonObject().get("everydayNonKccEarned").getAsString();
            curr_Earning = Double.parseDouble(curr_Earning_01);
            send_Object.addProperty(Reference_Payload_Updated, raw_Payload);
            posted_Object = Post_Sales(send_Object);
            Thread.sleep(2000);
            sale_Result_Object = convert_String_To_JsonObject(posted_Object.get(Kafka_Message_Body).getAsString());
        } else {
            loyalty_Id = null;
        }
    }

    @Then("Balance table is updated with updated balance as {string}")
    public void balance_table_is_updated_with_updated_balance_as(String string) throws Exception                {}

    @Then("Activity table is updated with updated attributes")
    public void activity_table_is_updated_Second() throws Exception                                             {}

    @Given("Event message with {string} having invalid value as {string}")
    public void event_message_with_having_invalid_value_as(String string, String string2) throws Exception      {}

    @When("Audit Listener app processes the dropped message")
    public void audit_Listener_app_processes_the_dropped_message() throws Exception                             {}

    @Then("Balance table is updated with updated balance.")
    public void kaalkjalna() throws Exception                                                                   {}

    @Given("Event message with all valid fields")
    public void event_message_with_all_valid_fields() throws Exception                                          {}

    @Given("Event message with removed field {string}")
    public void event_message_with_removed_field(String string) throws Exception                                {}

    @Given("Event message with {string} as null")
    public void event_message_with_as_null(String string) throws Exception                                      {}

    @Given("Event message with valid values is dropped into MKTG_EVENT topic")
    public void event_message_with_valid_values_is_dropped_into_MKTG_EVENT_topic() throws Exception             {}

    @Given("Activity,Balance table is updated")
    public void activity_Balance_table_is_updated() throws Exception                                            {}

    @When("Processed event message is redropped into MKTG_EVENT topic")
    public void processed_event_message_is_redropped_into_MKTG_EVENT_topic() throws Exception                   {}

    @Given("Event message with valid values,earning amount as {string}")
    public void event_message_with_valid_values_earning_amount_as(String string) throws Exception               {}

    @Given("Event message with valid values,event id as {string},event description as {string}")
    public void event_message_with_valid_values_event_id_as_event_description_as(String string, String string2) {}

}
