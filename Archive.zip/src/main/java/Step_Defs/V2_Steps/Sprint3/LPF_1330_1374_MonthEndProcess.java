package Step_Defs.V2_Steps.Sprint3;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Activity_Rows;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Balance_First_row;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.update_Rewards_Activity;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.update_Rewards_Balance;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Adjustment;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Return;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Void;
import static Service_Functions.V2.V2_Audit_Rewards.validateBalance;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants.Response_Body;
import static Utilities.UtilConstants.Response_Code;
import static Utilities.UtilConstants_Data_Rules_Reference.Refer_Rule_Replace_Loyalty_Id;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static Utilities.UtilConstants_Data_Rules_Reference.Rule_Replace_Transaction_Date;
import static Utilities.UtilConstants_Data_Rules_Reference.Rule_Replace_Transaction_Nbr;
import static Utilities.UtilConstants_Data_Rules_Reference.Rule_Replace_Transaction_Time;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.time.LocalDate;

import org.apache.log4j.Logger;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import Functional_Utilities.V2_Functional_Utilities;
import Service_Functions.V2.V2_Month_End_Functions;
import Service_Functions.V2.V2_Audit_Rewards;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LPF_1330_1374_MonthEndProcess {
	protected static final Logger logger = get_Logger();
	JsonObject sale_message_Posted = new JsonObject();
	JsonObject return_message_Posted = new JsonObject();
	JsonObject adj_message_Posted = new JsonObject();

	String loyaltyId = null;
	
	
	@Given("Audit DB has single POC Sale transaction details with {string} for the valid loyaltyID with {string}")
	public void audit_DB_has_single_POC_Sale_transaction_details_with_for_the_valid_loyaltyID(String Updated_balance, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef, loyaltyId);
		logger.info("Sale Message Payload Posted");
		
	}
	
	@Given("Audit DB has POC Sale {int} transaction details with {string} for the valid loyaltyID with {string}")
	public void audit_DB_has_POC_Sale_transaction_details_with_for_the_valid_loyaltyID_with(Integer saleNbr, String Updated_balance, String saleRef) throws Exception {
		if(saleNbr.equals(1))
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef+"_"+saleNbr, loyaltyId);
		logger.info("Sale Message Payload Posted");
	}
	
	@Given("Audit DB has {string} with {string} for the valid loyaltyID with {string}")
	public void audit_DB_has_with_for_the_valid_loyaltyID_with(String transaction_type, String updated_balance, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		if (transaction_type.equals("OMS_Sale")) {
			updateValuesAndPostMessage(saleRef+"_Order_create", loyaltyId);
			updateValuesAndPostMessage(saleRef+"_Fulfillment", loyaltyId);
		}else {
			updateValuesAndPostMessage(saleRef, loyaltyId);
		}
	}
	
	@Given("Audit DB has single POC Sale transaction details with{string},{string} for the valid loyaltyID with {string}")
	public void audit_DB_has_single_POC_Sale_transaction_details_with_for_the_valid_loyaltyID_with(String tender_type, String updated_balance, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef, loyaltyId);
	}
	@Given("Audit DB has single POC Sale transaction details with Updated_balance as ${double} for the valid loyaltyID with {string}")
	public void audit_DB_has_single_POC_Sale_transaction_details_with_Updated_balance_as_$_for_the_valid_loyaltyID_with(Double updated_balance, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef+"_Sale_1", loyaltyId);
	}

	@When("Audit DB has another POC Sale transaction details with activity time as {string} for ${double} kohls cash earned,Updated_balance as ${double} for the same loyaltyID with {string}")
	public void audit_DB_has_another_POC_Sale_transaction_details_with_activity_time_as_for_$_kohls_cash_earned_Updated_balance_as_$_for_the_same_loyaltyID_with(String activity_time, Double kohls_cash, Double updated_balance, String saleRef) throws Exception {
		
		updateValuesAndPostMessage(saleRef+"_Sale_2", loyaltyId);
	}
	
	@Given("Audit DB has single POC Sale transaction details with Updated_balance as ${double},activity date time as {int}:{int}:{int}PM CST,{string} created time for the valid loyaltyID with {string}")
	public void audit_DB_has_single_POC_Sale_transaction_details_with_Updated_balance_as_$_activity_date_time_as_PM_CST_created_time_for_the_valid_loyaltyID_with(Double double1, Integer int1, Integer int2, Integer int3, String time, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef, loyaltyId);
		update_Rewards_Activity(loyaltyId, LocalDate.now().minusDays(25).toString()+" "+time+".000");
		update_Rewards_Balance(loyaltyId, LocalDate.now().minusDays(25).toString()+" "+time+".000");
	}

	@Given("Audit DB has {string} as part of a previous Month End for the valid loyaltyID with {string}")
	public void audit_DB_has_as_part_of_a_previous_Month_End_for_the_valid_loyaltyID_with(String string, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef, loyaltyId);
		post_MontEnd("Prev_Month_End_Post");
		getKohlsCash(loyaltyId);
	}

	@Given("Audit DB has POC Sale transaction details with {string} for the same loyaltyID with {string}")
	public void audit_DB_has_POC_Sale_transaction_details_with_for_the_same_loyaltyID_with(String kohlscashEarned, String saleRef) throws Exception {
		
		sale_message_Posted = updateValuesAndPostMessage(saleRef, loyaltyId);
	}
	
	@Given("Audit DB has return transaction details for that Sale with {string} and {string}")
	public void return_transaction_for_Sale(String string, String retutnRef) throws Exception {
		JsonObject valuesToUpdate = getOriginalTrnsKey(sale_message_Posted);
		valuesToUpdate.addProperty(Reference_Payload, retutnRef);
		valuesToUpdate.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
		 return_message_Posted = convert_String_To_JsonObject(
				 Post_Return(valuesToUpdate).get(Kafka_Message_Body).getAsString());
	}
	
	@Given("Audit DB has Adjustment transaction details for that Sale with {string} and {string}")
	public void adjustment_transaction_for_Sale(String string, String retutnRef) throws Exception {
		JsonObject valuesToUpdate = getOriginalTrnsKey(sale_message_Posted);
		valuesToUpdate.addProperty(Reference_Payload, retutnRef);
		valuesToUpdate.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
		adj_message_Posted = convert_String_To_JsonObject(
				Post_Adjustment(valuesToUpdate).get(Kafka_Message_Body).getAsString());
	}
	
	@Given("Audit DB has {string} transaction details for that Sale with {string} and {string}")
	public void audit_DB_has_transaction_details_for_that_Sale_with_and(String transType, String kohlscashUnEarned, String transRef) throws Exception {
	    if (transType.equals("return")) {
			return_transaction_for_Sale(kohlscashUnEarned, transRef);
		}else if (transType.equals("Adjustment")) {
			adjustment_transaction_for_Sale(kohlscashUnEarned, transRef);
		}
	}
	
	@Given("Audit DB has Void transaction details for the {string} with {string}")
	public void audit_DB_has_Void_transaction_details_for_the_with(String transType, String voidRef) throws Exception {
		JsonObject valuesToUpdate = null;
		if(transType.equals("return")) {
		valuesToUpdate = getOriginalTrnsKey(return_message_Posted);
		valuesToUpdate.addProperty("Replace_OriginalTransactionType", "11");
		}
		
		if(transType.equals("Adjustment")) {
		valuesToUpdate = getOriginalTrnsKey(adj_message_Posted);
		valuesToUpdate.addProperty("Replace_OriginalTransactionType", "24");
		}
		
		valuesToUpdate.addProperty(Reference_Payload, voidRef);
		valuesToUpdate.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
		 Post_Void(valuesToUpdate);
	}
	
	@Given("Audit DB has OMS Sale transaction details with {string} for the same loyaltyID with {string}")
	public void audit_DB_has_OMS_Sale_transaction_details_with_for_the_same_loyaltyID_with(String string, String saleRef) throws Exception {
		sale_message_Posted = updateValuesAndPostMessage(saleRef+"_Order_create", loyaltyId);
		updateValuesAndPostMessage(saleRef+"_Fulfillment", loyaltyId);

	}
	
	@When("Month-End Process begins")
	public void month_End_Process_begins() throws Exception {
	    post_MontEnd("Month_End_Post");
	}
	@Given("Month-End Process begins at 12:00:00AM")
	public void month_End_Process_begins_at_AM() throws Exception {
	    post_MontEnd("Month_End_Post12AM");
	}
	
	@Then("Rewards Barcode will {string} based on the issuance threshold with {string} and {string}")
	public void rewards_Barcode_will_based_on_the_issuance_threshold(String process, String balance, String validationKey) throws Exception {

		if(process.equals("Generate")) {
			JsonObject actual = getKohlsCash(loyaltyId);
			JsonArray expected = consolidated_Data.get(validationKey).getAsJsonObject().getAsJsonArray("kohlsCash");
			V2_Audit_Rewards.validatekohlsCash(expected, actual.getAsJsonObject("1").getAsJsonArray("kohlsCash"));
		}else {
			JsonObject actual = getKohlsCash(loyaltyId);
			assertThat(actual).as("KohlsCash for this transaction:").isEqualTo(null);
		}
	}
	
	@Then("Rewards Barcode will {string} based on the issuance threshold and with {string}")
	public void rewards_Barcode_will_based_on_the_issuance_threshold_and_with(String process, String validationKey) throws Exception {
		if(process.equals("Generate")) {
			JsonObject actual = getKohlsCashforSecondSale(loyaltyId);
			if(actual != null) {
				JsonArray expected2 = consolidated_Data.get(validationKey).getAsJsonObject().getAsJsonArray("kohlsCash");
				V2_Audit_Rewards.validatekohlsCash(expected2, actual.getAsJsonObject("3").getAsJsonArray("kohlsCash"));
			}else {
				fail("Month-End not processed for the expected transaction");
			}

		}else {
			JsonObject actual = getKohlsCash(loyaltyId);
			assertThat(actual.getAsJsonObject("3").getAsJsonArray("kohlsCash")).as("KohlsCash for this transaction:").isEqualTo(null);
		}
	}
	
	@Then("Rewards Barcode will {string} based on the issuance threshold with {string} and {string} for both sales")
	public void rewards_Barcode_will_based_on_the_issuance_threshold_for_both_sales(String process, String balance, String validationKey) throws Exception {

		if(process.equals("Generate")) {
			JsonObject actual = getKohlsCash(loyaltyId);
			JsonArray expected1 = consolidated_Data.get(validationKey+"_sale1").getAsJsonObject().getAsJsonArray("kohlsCash");
			JsonArray expected2 = consolidated_Data.get(validationKey+"_sale2").getAsJsonObject().getAsJsonArray("kohlsCash");
			V2_Audit_Rewards.validatekohlsCash(expected1, actual.getAsJsonObject("1").getAsJsonArray("kohlsCash"));
			if (expected2 != null)
			V2_Audit_Rewards.validatekohlsCash(expected2, actual.getAsJsonObject("2").getAsJsonArray("kohlsCash"));
		}else {
			JsonObject actual = getKohlsCash(loyaltyId);
			assertThat(actual).as("KohlsCash for this transaction:").isEqualTo(null);
		}
	}
	
	@Given("Reward Tracker will have {string}")
	public void reward_Tracker_will_have(String trackerBalance) throws Exception {
        JsonObject actual   = get_Rewards_Balance_First_row(loyaltyId);
		JsonObject expected = new JsonObject();
		expected.addProperty("updatedBalance", trackerBalance);
        validateBalance(expected, actual);	    
	}
	
	@Given("Audit DB has sale transaction with unallocated balance as ${double} with {string}")
	public void audit_DB_has_sale_transaction_with_unallocated_balance_as_$_with(Double double1, String saleRef) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		updateValuesAndPostMessage(saleRef, loyaltyId);
	}

	@Given("was not eligible for previous month end due to {string} date time")
	public void was_not_eligible_for_previous_month_end_due_to_date_time(String time) throws Exception {
		update_Rewards_Activity(loyaltyId, LocalDate.now().minusDays(25).toString()+" "+time+".000");
		update_Rewards_Balance(loyaltyId, LocalDate.now().minusDays(25).toString()+" "+time+".000");

	}
	
	public void post_MontEnd(String monthEnd) throws Exception {
		JsonObject got_Data = new JsonObject();
		String payload = parse_And_Generate_Data(monthEnd, got_Data);
		 logger.info("Month-End Request $$::"+payload);
	    JsonObject result = V2_Month_End_Functions.post_Month_End_Execute(payload);
	    assertThat(result.get(Response_Code).getAsString()).as("Month-End Response Code:").isEqualTo("200");
	    logger.info("Month-End Response $$::"+result.get(Response_Body));
	}
	
	public JsonObject getKohlsCash(String loyaltyId) throws Exception {		
		for (int i = 0; i < 10; i++) {
			JsonObject actual = get_Rewards_Activity_Rows(loyaltyId);
			if(actual.getAsJsonObject("1").getAsJsonArray("kohlsCash") != null) return actual;		
		}
		return null;
	}
	
	public JsonObject getKohlsCashforSecondSale(String loyaltyId) throws Exception {		
		for (int i = 0; i < 10; i++) {
			JsonObject actual = get_Rewards_Activity_Rows(loyaltyId);
			if(actual.getAsJsonObject("3").getAsJsonArray("kohlsCash") != null) return actual;		
		}
		return null;
	}
	
	public JsonObject updateValuesAndPostMessage(String saleRef, String loyalty) throws Exception {		
		JsonObject saleValues = new JsonObject();
		saleValues.addProperty(Reference_Payload, saleRef);
		saleValues.addProperty(Refer_Rule_Replace_Loyalty_Id, loyalty);
		return convert_String_To_JsonObject(
				Post_Sales(saleValues).get(Kafka_Message_Body).getAsString());
	}
	
	public JsonObject getOriginalTrnsKey(JsonObject saleMessage) throws Exception {		
        JsonObject transKey = saleMessage.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");
        JsonObject originaTransKey = new JsonObject();
        originaTransKey.addProperty(Rule_Replace_Transaction_Nbr, transKey.get("transactionNbr").getAsString());
        originaTransKey.addProperty(Rule_Replace_Transaction_Date, transKey.get("transactionDate").getAsString());
        originaTransKey.addProperty(Rule_Replace_Transaction_Time, transKey.get("transactionTime").getAsString());
        return originaTransKey;
	}

}
