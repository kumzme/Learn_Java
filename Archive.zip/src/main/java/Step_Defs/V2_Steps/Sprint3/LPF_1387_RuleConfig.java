package Step_Defs.V2_Steps.Sprint3;

import Utilities.General_Purpose_Utilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jcraft.jsch.Logger;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.qameta.allure.Allure;

import java.sql.SQLOutput;
import java.text.NumberFormat;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_RuleConfig_Mongo_Functions.get_Rewards_RuleConfig_latest_rule_from_DB;
import static Service_Functions.V2.V2_Rule_Config_Functions.*;
import static Service_Functions.V2.V2_Spend_Tracker_Service.get_Spend_Tracker_Details_Negative;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;


import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static Service_Functions.V2.V2_Rule_Config_Functions.validateRuleConfigResponse;
//import static Service_Functions.V2.V2_Rule_Config_Functions.get_Rewards_Rule;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;

public class LPF_1387_RuleConfig {

    JsonObject negative_this_Object = new JsonObject();
    JsonObject result_Json                = new JsonObject();
    JsonObject result_everyday = new JsonObject();
    JsonObject latestRule = new JsonObject();
    JsonObject getRulebyId = new JsonObject();

    JsonObject this_Object                = new JsonObject();
    String payload_str;
    String ruleId;
    JsonObject service_body_negative = new JsonObject();
    JsonObject response_GET = new JsonObject();

    @Given("Rule config DB should be up and running")
    public void rule_config_DB_should_be_up_and_running() throws Exception{

    }

    @Given("all valid values are set in Request for {string}")
    public void all_valid_values_are_set_in_Request(String payload_reference) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        Allure.addAttachment("Payload::", payload);
        //  this_Object.addProperty(Reference_Payload, payload);
        result_Json = post_Rule_Config(payload);
        Allure.addAttachment("Response::", result_Json.get(Response_Body).getAsString());
        System.out.println("The response is::: " + result_Json);
        ruleId = result_Json.get("Response_Body").getAsJsonObject().get("id").getAsString();
        System.out.println("The is  from the POST service is **** " + ruleId);

    }

    @When("Rule config POST Service is hit with set data,Valid headers")
    public void rule_config_POST_Service_is_hit_with_set_data_Valid_headers() throws Exception {
        System.out.println("***** Inside When method *******");
    }

    @Then("Rule config POST Service should respond successfully with {string}")
    public void rule_config_POST_Service_should_respond_successfully(String statusCode) throws Exception {
        assertTrue("The response code is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));

    }

    @Given("{string} field is given invalid value {string} for {string} for {string}")
    public void field_is_given_invalid_value(String fieldName, String fieldValue, String payload_reference, String Testcase ) throws Exception{
        payload_str = consolidated_Data.get(payload_reference).getAsString();
        JsonObject payload = General_Purpose_Utilities.convert_String_To_JsonObject(payload_str).getAsJsonObject();
        System.out.println("The payload for "+Testcase +" before used is::: "+payload);
        JsonArray jsonArray = new JsonArray();
        JsonArray jsonArray2 = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        JsonObject event1 = new JsonObject();
        JsonObject earnRule = new JsonObject();
        JsonArray earnRule2 = new JsonArray();
        Number num;
        switch (fieldName) {
            case "earnTrackerThreshold":

                payload.addProperty("earnTrackerThreshold",fieldValue);
                break;

            case "departmentId":
                jsonArray = payload.get("excludedDepts").getAsJsonArray();
                JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject();
                temp.addProperty("departmentId", fieldValue);
                jsonArray.set(0,temp);
                payload.add("excludedDepts",jsonArray);
                break;

            case "eventId":
                //  payload = payload.replace("Replace_earnTrackerThreshold", fieldValue);
                //JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject().get("depatmentId").getAsJsonObject();
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("eventId", fieldValue);
                //     jsonObject.addProperty("eventId", fieldValue);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventName":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                num = NumberFormat.getInstance().parse(fieldValue);
                event1.addProperty("eventName",num);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                if(!fieldValue.equals("2356"))
                    event1.addProperty("startDate",fieldValue);
                else
                {
                    num = NumberFormat.getInstance().parse(fieldValue);
                    event1.addProperty("startDate",num);

                }
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                if(!fieldValue.equals("12335"))
                    event1.addProperty("endDate",fieldValue);
                else
                {
                    num = NumberFormat.getInstance().parse(fieldValue);
                    event1.addProperty("endDate",num);

                }
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "defaultNonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("defaultNonKccPercent",fieldValue);
//                jsonObject.addProperty("eventName", fieldValue);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "defaultKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("defaultKccPercent",fieldValue);
//                jsonObject.addProperty("eventName", fieldValue);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "nonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.addProperty("nonKccPercent",fieldValue);
                event1.add("earnRules", earnRule);
//                jsonObject.addProperty("eventName", fieldValue);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;
            case "kccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.addProperty("kccPercent",fieldValue);
                event1.add("earnRules", earnRule);
//              jsonObject.addProperty("eventName", fieldValue);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.addProperty("startDate",fieldValue);
                ((JsonArray) earnRule2).set(0,earnRule);

                event1.add("earnRules", earnRule2);
//              jsonObject.addProperty("eventName", fieldValue);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.addProperty("endDate",fieldValue);
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;

        }
        String final_payload = payload+"";
        System.out.println("The payload for "+Testcase+ " after formatting being used is::: "+ final_payload);
        result_Json = post_Rule_Config(final_payload);
    }

    @Given("{string} field should be removed from request for {string} for {string}")
    public void field_should_be_removed_from_request(String fieldName, String payload_reference, String Testcase ) throws Exception{

        payload_str = consolidated_Data.get(payload_reference).getAsString();
        JsonObject payload = General_Purpose_Utilities.convert_String_To_JsonObject(payload_str).getAsJsonObject();
        //  this_Object.addProperty(Reference_Payload, payload);
//
        System.out.println("The payload for "+Testcase +" before used is::: "+payload);
        JsonArray jsonArray = new JsonArray();
        JsonArray jsonArray2 = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        JsonObject event1 = new JsonObject();
        JsonObject earnRule = new JsonObject();
        JsonArray earnRule2 = new JsonArray();
        JsonArray empty_array = new JsonArray();
        Number num;
        switch (fieldName) {
            case "earnTrackerThreshold":

                payload.remove("earnTrackerThreshold");
                break;

            case "departmentId":
                jsonArray = payload.get("excludedDepts").getAsJsonArray();
                JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject();
                temp.remove("departmentId");
                jsonArray.set(0,temp);
                payload.add("excludedDepts",jsonArray);
                break;

            case "eventId":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("eventId");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventName":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("eventName");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("startDate");

                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("endDate");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "defaultNonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("defaultNonKccPercent");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "defaultKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.remove("defaultKccPercent");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "nonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.remove("nonKccPercent");
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;
            case "kccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.remove("kccPercent");
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.remove("startDate");
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.remove("endDate");
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventRule_array":
                payload.remove("eventRule");
                break;
            case "excludedDepts_array":
                payload.remove("excludedDepts");
                break;
            case "createdBy":
                payload.remove("createdBy");
                break;

        }
        String final_payload = payload+"";
        System.out.println("The payload for "+Testcase+ " after formatting being used is::: "+ final_payload);
        result_Json = post_Rule_Config(final_payload);
        System.out.println("The response is ********** "+result_Json.get("Response_Body"));
    }

    @Given("{string} field should be given as empty value in request for {string} for {string}")
    public void field_should_be_given_empty_in_request(String fieldName, String payload_reference, String Testcase ) throws Exception{

        payload_str = consolidated_Data.get(payload_reference).getAsString();
        JsonObject payload = General_Purpose_Utilities.convert_String_To_JsonObject(payload_str).getAsJsonObject();
        System.out.println("The payload for "+Testcase +" before used is::: "+payload);
        JsonArray jsonArray = new JsonArray();
        JsonArray jsonArray2 = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        JsonObject event1 = new JsonObject();
        JsonObject earnRule = new JsonObject();
        JsonArray earnRule2 = new JsonArray();
        JsonArray empty_array = new JsonArray();
        Number num;
        switch (fieldName) {
            case "earnTrackerThreshold":

                payload.addProperty("earnTrackerThreshold","");
                break;

            case "departmentId":
                jsonArray = payload.get("excludedDepts").getAsJsonArray();
                JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject();
                temp.addProperty("departmentId","");
                jsonArray.set(0,temp);
                payload.add("excludedDepts",jsonArray);
                break;

            case "eventId":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("eventId","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventName":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("eventName","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("startDate","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("endDate","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "defaultNonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("defaultNonKccPercent","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "defaultKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.addProperty("defaultKccPercent","");
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "nonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.addProperty("nonKccPercent","");
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;
            case "kccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.addProperty("kccPercent","");
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.addProperty("startDate","");
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.addProperty("endDate","");
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventRule_array":
                payload.add("eventRule",empty_array);
                break;
            case "excludedDepts_array":
                payload.add("excludedDepts",empty_array);
                break;
            case "createdBy":
                payload.addProperty("createdBy","");
                break;

        }
        String final_payload = payload+"";
        System.out.println("The payload for "+Testcase+ " after formatting being used is::: "+ final_payload);
        result_Json = post_Rule_Config(final_payload);
        System.out.println("The response is ********** "+result_Json.get("Response_Body"));

    }

    @Given("{string} field should be given as null value in request for {string} for {string}")
    public void field_should_be_given_null_in_request(String fieldName, String payload_reference, String Testcase ) throws Exception{

        payload_str = consolidated_Data.get(payload_reference).getAsString();
        JsonObject payload = General_Purpose_Utilities.convert_String_To_JsonObject(payload_str).getAsJsonObject();
        System.out.println("The payload for "+Testcase +" before used is::: "+payload);
        JsonArray jsonArray = new JsonArray();
        JsonArray jsonArray2 = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        JsonObject event1 = new JsonObject();
        JsonObject earnRule = new JsonObject();
        JsonArray earnRule2 = new JsonArray();
        JsonArray empty_array = new JsonArray();
        Number num;
        switch (fieldName) {
            case "earnTrackerThreshold":

                payload.add("earnTrackerThreshold",null);
                //JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject().get("depatmentId").getAsJsonObject();
                break;

            case "departmentId":
                jsonArray = payload.get("excludedDepts").getAsJsonArray();
                JsonObject temp = payload.get("excludedDepts").getAsJsonArray().get(0).getAsJsonObject();
                temp.add("departmentId",null);
                jsonArray.set(0,temp);
                payload.add("excludedDepts",jsonArray);
                break;

            case "eventId":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("eventId",null);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventName":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("eventName",null);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("startDate",null);

                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("endDate",null);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "defaultNonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("defaultNonKccPercent",null);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "defaultKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1 = payload.get("eventRule").getAsJsonArray().get(0).getAsJsonObject();
                event1.add("defaultKccPercent",null);
                jsonArray.set(0,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "nonKccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.add("nonKccPercent",null);
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;
            case "kccPercent":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule.add("kccPercent",null);
                event1.add("earnRules", earnRule);
                jsonArray.set(1,event1);

                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_startDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.add("startDate",null);
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;

            case "earnrules_endDate":
                jsonArray = payload.get("eventRule").getAsJsonArray();
                event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
                earnRule = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject();
                earnRule2 = payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject().get("earnRules").getAsJsonArray();
                earnRule.add("endDate",null);
                ((JsonArray) earnRule2).set(0,earnRule);
                event1.add("earnRules", earnRule2);
                jsonArray.set(1,event1);
                payload.add("eventRule",jsonArray);
                break;
            case "eventRule_array":
                payload.add("eventRule",null);
                break;
            case "excludedDepts_array":
                payload.add("excludedDepts",null);
                break;
            case "createdBy":
                payload.add("createdBy",null);
                break;

        }
        String final_payload = payload+"";
        System.out.println("The payload for "+Testcase+ " after formatting being used is::: "+ final_payload);
        result_Json = post_Rule_Config(final_payload);
        System.out.println("The response is ********** "+result_Json.get("Response_Body"));

    }

    @Given("Request without earn rules array for {string} for {string}")
    public void Request_without_earn_rules_array(String payload_reference, String Testcase) throws Exception
    {
        payload_str = consolidated_Data.get(payload_reference).getAsString();
        JsonObject payload = General_Purpose_Utilities.convert_String_To_JsonObject(payload_str).getAsJsonObject();
        System.out.println("The payload for "+Testcase +" before used is::: "+payload);
        JsonArray jsonArray = new JsonArray();

        JsonObject event1 = new JsonObject();

        jsonArray = payload.get("eventRule").getAsJsonArray();
        event1=payload.get("eventRule").getAsJsonArray().get(1).getAsJsonObject();
        event1.remove("earnRules");
        jsonArray.set(1,event1);
        payload.add("eventRule",jsonArray);
        String final_payload = payload+"";
        System.out.println("The payload for "+Testcase+ " after formatting being used is::: "+ final_payload);
        result_Json = post_Rule_Config(final_payload);
        System.out.println("The response is ********** "+result_Json.get("Response_Body"));

    }

    @Then("Rule config POST Service should respond with {string} status code for {string}")
    public void rule_config_POST_Service_should_respond_with_400(String statusCode, String Testcase) throws Exception {
        assertTrue("The Actual response code for "+Testcase+ " is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));

    }
    //scenario 7
    @Given("Request with earn value array field as {string} for {string} and {string}")
    public void Request_with_earn_value_array_field_as(String scenarioRef, String payload_reference, String Testcase) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }
    //Scenario 8
    @Given("Request with all valid fields is hit with set data,valid headers for {string} for {string}")
    public void request_with_all_valid_fields_is_hit_with_set_data_valid_headers(String payload_reference, String Testcase) throws Exception
    {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);

    }



    //Scenario 8
    @Then("Rule config POST Service should respond with staus code as {string} for {string}")
    public void rule_config_POST_Service_should_respond_with_statu_code(String statusCode, String Testcase) throws Exception {
        assertTrue("The Actual response code for "+Testcase+ " is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));

    }
    //Scenario 8
    @Given("Rule should be present in Rule config DB")
    public void rule_should_be_present_in_Rule_config_DB() throws Exception{
        JsonObject actual = get_Rewards_RuleConfig_latest_rule_from_DB();
        System.out.println("The response from DB is ***** "+(actual + ""));
    }

    //Scenario 8
    @When("Rule config POST Service is hit again with set data,Valid headers for {string} for {string}")
    public void rule_config_POST_Service_is_hit_again_with_set_data_Valid_headers(String payload_reference, String Testcase ) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);

    }

    //Scenario 8
    @Given("Success response {string} should be recieved for {string} for {string}")
    public void success_response_should_be_recieved(String statusCode, String scenario, String testcase) {
        // Write code here that turns the phrase above into concrete actions
        //assertEquals("The Actual response code ::  ", result_Json.get("Response_Code").getAsString(), statusCode);

        assertTrue("The Actual response code for  "+scenario +" " +testcase +" is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));

    }

    //Scenario 8
    @Then("Rule config POST Service should respond successfully with {string} for {string} for {string}")
    public void rule_config_POST_Service_should_respond_successfully(String statusCode, String scenario, String testcase) throws Exception {
        assertTrue("The Actual response code for "+testcase+ " is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));
        JsonObject actual = get_Rewards_RuleConfig_latest_rule_from_DB();
        System.out.println("The response from DB is ***** "+(actual + ""));

        System.out.println("The version is ***** "+actual.get("_id").getAsJsonObject().get("$oid"));
    }

    //Scenario 8
    @When("Rule config POST Service is hit again with different dates,set data,Valid headers for {string} for {string}")
    public void rule_config_POST_Service_is_hit_again_with_different_dates_set_data_Valid_headers(String payload_reference, String Testcase ) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    //scenario 11
    @Given("Eventrule array should be set with {string} for {string} and {string}")
    public void Eventrule_array_should_be_set_with(String scenarioRef, String payload_reference, String Testcase) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }
    //Scenario 12
    @Given("Request with all valid fields,same event name for {string} for {string}")
    public void Request_with_all_valid_fields_same_event_name(String payload_reference, String Testcase) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    //Scenario 12
    @When("Rule config POST Service is hit with different dates,set data,Valid headers for {string} for {string}")
    public void rule_config_POST_Service_is_hit_with_different_dates_set_data_Valid_headers(String payload_reference, String Testcase ) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    //Scenario 13
    @Given("Request with more than one value in {string} array for {string} for {string}")
    public void Request_with_more_than_one_value_in_array(String arrayName, String payload_reference, String Testcase) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    //Scenario 14
    @When("Rule config POST Service is hit with {string} for {string} for {string} and {string}")
    public void Rule_config_POST_Service_is_hit_with_invalid_value_for_header(String negativeType, String header_name, String payload_reference, String testcase) throws Exception
    {
        //     JsonObject send_This = new JsonObject();
        String payload = consolidated_Data.get(payload_reference).getAsString();

        negative_this_Object.addProperty(Reference_Payload, payload);
        if(negativeType.equals("invalid_value")) {
            switch (header_name) {    //do this
                case "Authorization":
                    negative_this_Object.addProperty(Api_Pass_Authorization,"78434ddfdfdf");
                    System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Authorization).getAsString());
                    break;

                case "X-KOHLS-CreateDateTime":
                    negative_this_Object.addProperty(Api_Pass_Time_Stamp,"&^&^");
                    System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Time_Stamp).getAsString());
                    break;

                case  "X-KOHLS-From-SystemCode":
                    negative_this_Object.addProperty(Api_Pass_System_Cd,"*&*&*");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_System_Cd).getAsString());
                    break;
                case  "X-KOHLS-MessageID":
                    negative_this_Object.addProperty(Api_Pass_Message_Id,"&^&^%^^^");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Message_Id).getAsString());
                    break;
                case  "X-KOHLS-CorrelationID":
                    negative_this_Object.addProperty(Api_Pass_Corrln_Id ,"*&*&");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Corrln_Id).getAsString());
                    break;
            }
        }
        else if (negativeType.equals("empty_value")) {

            switch(header_name)
            {
                case "Authorization":
                    negative_this_Object.addProperty(Api_Pass_Authorization,"");
                    System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Authorization).getAsString());
                    break;

                case "X-KOHLS-CreateDateTime":
                    negative_this_Object.addProperty(Api_Pass_Time_Stamp,"");
                    System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Time_Stamp).getAsString());
                    break;

                case  "X-KOHLS-From-SystemCode":
                    negative_this_Object.addProperty(Api_Pass_System_Cd,"");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_System_Cd).getAsString());
                    break;
                case  "X-KOHLS-MessageID":
                    negative_this_Object.addProperty(Api_Pass_Message_Id,"");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Message_Id).getAsString());
                    break;
                case  "X-KOHLS-CorrelationID":
                    negative_this_Object.addProperty(Api_Pass_Corrln_Id ,"");
                    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Corrln_Id).getAsString());
                    break;
            }
        }
        else if (negativeType.equals("missing_header")) {

            switch(header_name)
            {
                case "Authorization":
                    negative_this_Object.addProperty(Missing_Header,"Authorization");
                    //  System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Authorization).getAsString());
                    break;

                case "X-KOHLS-CreateDateTime":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-CreateDateTime");
                    //     System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Time_Stamp).getAsString());
                    break;

                case  "X-KOHLS-From-SystemCode":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-From-SystemCode");
                    //   System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_System_Cd).getAsString());
                    break;
                case  "X-KOHLS-MessageID":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-MessageID");
                    //    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Message_Id).getAsString());
                    break;
                case  "X-KOHLS-CorrelationID":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-CorrelationID");
                    //   System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Corrln_Id).getAsString());
                    break;
            }
        }


        result_Json = post_Rule_Config_Neg(negative_this_Object);
        System.out.println("The response is::: "+result_Json);


    }


    //Scenario 14
    @Given("Rule config POST Service should provide {string} for {string} and {string}")
    public void rule_config_service_should_provide_status(String statusCode, String scenario, String testcase) {
        assertTrue("The Actual response code for  "+scenario +" " +testcase +" is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));
    }

    //Scenario 20
    @When("Rule config GET Service is hit with the same version,Valid headers")
    public void rule_config_GET_Service_is_hit_with_the_same_version_Valid_headers() throws Exception {

        getRulebyId = get_RuleConfig_by_id(ruleId);
        System.out.println("The response from GET Rule by ID is::: " + getRulebyId);
        //   System.out.println("The response from GET Rule by ID is::: " + getRulebyId);

    }

    //Scenario 20
    @Then("Rule config GET Service by id should respond successfully")
    public void rule_config_GET_Service_by_id_should_respond_successfully() {

        validateRuleConfigResponse(getRulebyId,result_Json);
        assertTrue(ruleId.equals(getRulebyId.get("Response_Body").getAsJsonObject().get("id").getAsString()));
        //    assertTrue(getRulebyId.get("id").getAsJsonObject().getAsString().equals(ruleId));



    }

    //Scenario 33
    @Given("Request with event name as {string} for {string} and {string}")
    public void Request_with_event_name_as_(String scenarioRef, String payload_reference, String Testcase) throws Exception {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    @And("Request without excluded department array for {string}")
    public void requestWithoutExcludedDepartmentArrayFor(String payload_reference) throws Throwable {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    @When("Rule config POST Service is hit with invalid endpoint for {string}")
    public void ruleConfigPOSTServiceIsHitWithInvalidEndpointFor(String payload_reference) throws Throwable {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Invalid_Rule_Config(payload);
        System.out.println("The post_Invalid_Rule_Config response is::: "+result_Json);
    }
    //Scenario 23
    @Given("version of rule is existing in rule config DB")
    public void version_of_rule_is_existing_in_rule_config_DB() throws Exception{
        // Write code here that turns the phrase above into concrete actions
        JsonObject actual = get_Rewards_RuleConfig_latest_rule_from_DB();
        System.out.println("The response from DB is ***** " + (actual + ""));
        System.out.println("The version is ***** " + actual.get("_id").getAsJsonObject().get("$oid"));
    }
    //Scenario 23
    @When("Rule config GET Service is hit set data,Valid headers")
    public void rule_config_GET_Service_is_hit_set_data_Valid_headers() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        ruleId = result_Json.get("Response_Body").getAsJsonObject().get("id").getAsString();
        System.out.println("RuleId from the response of RuleConfig POST service is **** " + ruleId);
        latestRule = get_latest_Rule_Config();
    }

    //Scenario 23
    @Then("Rule config GET latest Service should respond successfully")
    public void rule_config_GET_Service_should_respond_successfully() throws Exception{
        // Write code here that turns the phrase above into concrete actions

        String rId = latestRule.get("Response_Body").getAsString();
        System.out.println("The ruleId from GET latest Rule is *****" + rId);
        assertTrue("The actual latest rule retrieved is *** " + rId, ruleId.equals(rId));
    }


    //Scenario 24
    @When("Rule config GET Service is hit set data,Valid headers for {string}")
    public void rule_config_GET_Service_is_hit_set_data_Valid_headers(String payload_reference) throws Exception {
        payload_str = consolidated_Data.get(payload_reference).getAsString();
        //   this_Object.addProperty(Reference_Payload, payload_str);
        result_Json = post_Rule_Config(payload_str);
        //   payload_str = payload_str.toString();
        result_everyday = get_everydayRule();

        System.out.println("The response from rule post is ******" + result_Json);
        System.out.println("The response from everyday is ******" + result_everyday);
    }

    //Scenario 24
    @Then("Rule config GET Service should respond successfully with {string}")
    public void rule_config_GET_Service_should_respond_successfully(String statusCode) {

        System.out.println("The response code is ******" + result_everyday.get("Response_Code").getAsString());
        String actual_KccPer = result_everyday.get(Response_Body).getAsJsonObject().get("everydayKccPercentage").getAsString();
        String expected_KccPer = result_Json.get(Response_Body).getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("kccPercent").getAsString();
        assertTrue("The expected everydayKccPercentage value: " + expected_KccPer + " is not matching with actual kccPercent value: " + actual_KccPer, expected_KccPer.equals(actual_KccPer));

        String actual_NonKccPer = result_everyday.get(Response_Body).getAsJsonObject().get("everydayNonKccPercentage").getAsString();
        String expected_NonKccPer = result_Json.get(Response_Body).getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("nonKccPercent").getAsString();
        assertTrue("The expected everydayNonKccPercentage value: " + expected_KccPer + " is not matching with actual nonKccPercent value: " + actual_KccPer, expected_NonKccPer.equals(actual_NonKccPer));


    }


    // Scenario - 27
    @When("Rule config POST Service is hit with invalid value for {string} {string} {string} {string} {string} {string}")
    public void rule_config_POST_Service_is_hit_with_invalid_value_for(String header, String url_value, String SystemCode, String MessageID, String CorrelationID, String status_code) throws Exception {

        String CreateDateTime = null;

        /*sending invalid header values from feature*/
        if(header.equals("X-KOHLS-CreateDateTime"))
            CreateDateTime = "9999-01-27T20:00:23+0530";
        else
            CreateDateTime = generate_Header_Date_TS();

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", "reallybadsecret");
        negative_this_Object.addProperty("Invalid_API_KEY", "Invalid_API_KEY");

        if (status_code.equals("401"))
            negative_this_Object.addProperty("401_example", "401_example");
        if (status_code.equals("200"))
            negative_this_Object.addProperty("200_example", "200_example");

        String payload = consolidated_Data.get("LPF-1387_Sc01_Tc01").getAsString();

        negative_this_Object.addProperty("body_Payload", payload);
        String rule_Id = "1234";

        service_body_negative = post_Rule_Config(payload);
        JsonObject rule_Id_json = convert_String_To_JsonObject(service_body_negative.get("Response_Body")+""); //.getAsJsonObject().get("id").getAsString();
        rule_Id = rule_Id_json.get("id").getAsString();

        negative_this_Object.addProperty("rule_Id", rule_Id);

    }

    @Then("Rule config POST Service service should provide {string}")
    public void rule_config_POST_Service_service_should_provide(String statusCode) {
        assertTrue("The actual response is: "+service_body_negative.get(Response_Code).getAsString() + " but the expected response is " +statusCode, service_body_negative.get(Response_Code).getAsString().equals(statusCode));
    }

    //Sc-28
    @When("Rule config Service is hit with {string} for Authorization header with Authorization values as {string} {string}")
    public void rule_config_Service_is_hit_with_for_Authorization_header_with_Authorization_values_as(String string, String header_key, String header_secret) throws Exception {
        negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", header_key);
        negative_this_Object.addProperty("SecretKey", header_secret);

        negative_this_Object.addProperty("401_example", "401_example");
        if (header_secret.equals("empty_secret")) {
            negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
        }

        String payload = consolidated_Data.get("LPF-1387_Sc01_Tc01").getAsString();


        negative_this_Object.addProperty("Invalid_API_KEY", "Invalid_API_KEY");
        negative_this_Object.addProperty("body_Payload", payload);

        negative_this_Object.addProperty("rule_Id","12345");

//		service_body_negative = get_Rule_Config_Details_Negative(negative_this_Object);
//
//		System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
    }

    @When("Resource url as {string}")
    public void resource_url_as(String endpoint) throws Exception {

        service_body_negative = get_Rule_Config_Details_Negative(negative_this_Object,endpoint);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
    }

    @Then("Rule config GET Service should provide {int} status code")
    public void rule_config_GET_Service_should_provide_status_code(Integer int1) {
      //  System.out.println("Assertions are done in utilities");
        assertTrue("The actual response is: "+service_body_negative.get(Response_Code).getAsString() + " but the expected response is " +int1.toString(),service_body_negative.get(Response_Code).getAsString().equals(int1.toString()));

    }

    //Sc-29
    @When("Rule config Service is hit with no value for {string} with header values {string} {string} {string} {string} {string} {string}")
    public void rule_config_Service_is_hit_with_no_value_for_with_header_values(String header,
                                                                                String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key,
                                                                                String Status_Code) {
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);

        // Based on this property, we will remove message id in utility
        if (header.equals("X-KOHLS-MessageID"))
            negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

        if (header.equals("X-KOHLS-CreateDateTime"))
            negative_this_Object.addProperty("Remove_date", "Remove_date");

        if (Status_Code.equals("401"))
            negative_this_Object.addProperty("401_example", "401_example");
        String payload = consolidated_Data.get("LPF-1387_Sc01_Tc01").getAsString();
        negative_this_Object.addProperty("Invalid_API_KEY", "Invalid_API_KEY");
        negative_this_Object.addProperty("body_Payload", payload);
        negative_this_Object.addProperty("rule_Id","12345");
    }

    @And("Resource url as {string} with {string}")
    public void resourceUrlAsWith(String resourceURL, String ruleNum) throws Throwable {
        if(resourceURL.contains("latest"))
        {
            result_Json = get_latest_Rule_Config_Invalid();
        }else if(resourceURL.contains("rulenumber"))
        {
            result_Json = get_RuleConfig_by_id_Invalid(ruleNum);
        }else if(resourceURL.contains("geteverdayrule"))
        {
            result_Json=get_everydayRule_Invalid();
        }
        System.out.println("The post_Invalid_Rule_Config response is::: "+result_Json);
    }

    @Then("Rule config GET Service should provide {string} status code")
    public void ruleConfigGETServiceShouldProvideStatusCode(String statusCode) throws Throwable {
        assertTrue("The response code is : "+result_Json.get("Response_Code").getAsString(), result_Json.get("Response_Code").getAsString().equals(statusCode));
    }

    @When("Rule config GET Service is hit with invalid value,set data,Valid headers {string}")
    public void ruleConfigGETServiceIsHitWithInvalidValueSetDataValidHeaders(String serviceType) throws Throwable {
        result_Json = get_latest_Invaid_Rule_Config(serviceType);
        System.out.println("The post_Invalid_Rule_Config response is::: "+result_Json);
    }

    @And("Request with all valid fields with multiple sets is hit with set data,valid headers for {string}")
    public void requestWithAllValidFieldsWithMultipleSetsIsHitWithSetDataValidHeadersFor(String payload_reference) throws Throwable {
        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);
    }

    //Scenario 21
    @When("Rule config GET Service is hit with version not existing in DB,set data,Valid headers")
    public void rule_config_GET_Service_is_hit_with_version_not_existing_in_DB_set_data_Valid_headers() throws Exception {
        getRulebyId = get_RuleConfig_by_id("5abcdefghijkl111111");

    }
    //Scenario 21
    @Then("Rule config GET Service should respond with {int} status code")
    public void rule_config_GET_Service_should_respond_with_status_code(Integer int1) {
        assertTrue(getRulebyId.get(Response_Code).getAsString().equals("404"));
    }
    //Scenario 22
    @When("Rule config GET Service of all rules is hit set data,Valid headers")
    public void rule_config_GET_Service_of_all_rules_is_hit_set_data_Valid_headers() throws Exception{
        result_Json =  get_Rule_Config_all_rules();
        System.out.println("The response of GET all rules"+ result_Json);

    }
    // Scenario 22
    @Then("Rule config GET Service of all rules should respond successfully")
    public void rule_config_GET_Service_of_all_rules_should_respond_successfully() {
        assertTrue(result_Json.get(Response_Code).getAsString().equals("200"));
        assertTrue(result_Json.get(Response_Body).getAsJsonObject().get("_embedded").getAsJsonObject().get("rules").getAsJsonArray().size()>=1);
    }

    //Scenario 30
    @When("Rule config GET Service is hit with {string} for {string} for {string} and {string} for {string}")
    public void Rule_config_GET_Service_is_hit_with_invalid_value_for_header(String negativeType, String header_name, String payload_reference, String testcase, String url_value) throws Exception
    {
        //     JsonObject send_This = new JsonObject();
        String payload = consolidated_Data.get(payload_reference).getAsString();

        negative_this_Object.addProperty(Reference_Payload, payload);

        if (negativeType.equals("missing_header")) {
            negative_this_Object.addProperty("resource_url", url_value);
            if(url_value.contains("rulenumber") || url_value.contains("everyday")) {
                result_Json = post_Rule_Config(payload);
                ruleId = result_Json.get("Response_Body").getAsJsonObject().get("id").getAsString();
                negative_this_Object.addProperty("rulenumber", ruleId);
            }
            System.out.println("The response is::: " + result_Json);

            switch(header_name)
            {
                case "Authorization":
                    negative_this_Object.addProperty(Missing_Header,"Authorization");
                    //  System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Authorization).getAsString());
                    break;

                case "X-KOHLS-CreateDateTime":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-CreateDateTime");
                    //     System.out.println("The value of timestamp property is : "+negative_this_Object.get(Api_Pass_Time_Stamp).getAsString());
                    break;

                case  "X-KOHLS-From-SystemCode":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-From-SystemCode");
                    //   System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_System_Cd).getAsString());
                    break;
                case  "X-KOHLS-MessageID":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-MessageID");
                    //    System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Message_Id).getAsString());
                    break;
                case  "X-KOHLS-CorrelationID":
                    negative_this_Object.addProperty(Missing_Header,"X-KOHLS-CorrelationID");
                    //   System.out.println("The value of systemcode property is : "+negative_this_Object.get(Api_Pass_Corrln_Id).getAsString());
                    break;
            }
        }
        response_GET = get_Rule_Config_missing_header(negative_this_Object);
        System.out.println("The response is::: "+response_GET);
    }

    @Then("Rule config GET Service should provide {string} status code for {string} and {string}")
    public void rule_config_GET_Service_should_respond_with_401(String statusCode, String scenario, String Testcase) throws Exception {
        assertTrue("The Actual response code for " +scenario +" " +Testcase+ " is : "+response_GET.get("Response_Code").getAsString(), response_GET.get("Response_Code").getAsString().equals(statusCode));

    }

    @Given("Request with Eventrule array as Two_event_with_two_days_interval_between_event1_and_event2 for {string}")
    public void Request_with_Eventrule_array_as_Two_event_with_two_days_interval_between_event1_and_event2_for (String payload_reference) throws Throwable {

        String payload = consolidated_Data.get(payload_reference).getAsString();
        result_Json = post_Rule_Config(payload);
        System.out.println("The response is::: "+result_Json);

    }

}
