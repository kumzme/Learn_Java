package Step_Defs.V2_Steps.Sprint3;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_Functional_Utilities.create_New_Loyalty_ID;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Service_Functions.V2.V2_Digital_Cart_Service.get_Digital_Cart_Details_Negative;
import static Service_Functions.V2.V2_Posttender_Cart_Service.get_Posttender_Cart_Details;
import static Service_Functions.V2.V2_Posttender_Cart_Service.get_Posttender_Cart_Details_Negative;
import static Service_Functions.V2.V2_Rule_Config_Functions.post_Rule_Config;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;

import java.math.BigDecimal;

import org.junit.Assert;

import com.google.gson.JsonObject;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static Service_Functions.V2.V2_Posttender_Cart_Service.validatePosttender;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;

public class LPF_1365_Posttender_Cart {

	
String loyaltyId = null;
String rule_Payload = null;
	
	JsonObject result_Object 			  = new JsonObject();
    JsonObject this_Object                = new JsonObject();
    JsonObject message_Posted             = new JsonObject();
    JsonObject Exp_Yaml             = new JsonObject();
    JsonObject Act             = new JsonObject();
    
    JsonObject negative_this_Object  = new JsonObject();
    JsonObject service_body_negative = new JsonObject();
	
	@Given("Audit DB,audit services,rule config,audit POD should be up and running for Post tender execution")
	public void audit_DB_audit_services_rule_config_audit_POD_should_be_up_and_running_for_Post_tender_execution() throws Exception {
	    
		loyaltyId = create_New_Loyalty_ID();
	}

	@When("LCS PoC Post tender cart service is hit with set data,Valid headers")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_set_data_Valid_headers() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS PoC Post tender cart service sc should respond successfully")
	public void lcs_PoC_Post_tender_cart_service_sc_should_respond_successfully() {

		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1365_Sc1_Ex_Validations").getAsString());
		validatePosttender(Exp_Yaml, result_Object);
	}
	
	
	
	//Scenario - 2
	
	@When("LCS PoC Post tender cart service is hit without {string} in request ,Valid headers {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_without_in_request_Valid_headers(String string, String Service_Payload) throws Exception {
	   
		/*System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());*/
	    
	    negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

        negative_this_Object.addProperty("400_example", "400_example");
        
        String payload = consolidated_Data.get(Service_Payload).getAsString();
		payload = payload.replace("Loyalty_Id", loyaltyId);
        
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS PoC Post tender cart service should provide {int} status code")
	public void lcs_PoC_Post_tender_cart_service_should_provide_status_code(Integer int1) {
	    
		
	}

	
	
	
	//Scenario - 3
	//Scenario - 4
	
	@When("LCS PoC Post tender cart service is hit with all valid values along with two tender,typecode value as {string}, {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_all_valid_values_along_with_two_tender_typecode_value_as(String string, String string2, String Service_Payload) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		String     payload           = parse_And_Generate_Data(Service_Payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("LCS PoC Post tender cart service should respond successfully {string}")
	public void lcs_PoC_Post_tender_cart_service_should_respond_successfully(String validations) {

		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get(validations).getAsString());
		validatePosttender(Exp_Yaml, result_Object);
	}
	
	
	
	// Scenario - 5
	
	@When("LCS PoC Post tender cart service is hit tender typecode value as KCC")
	public void lcs_PoC_Post_tender_cart_service_is_hit_tender_typecode_value_as_KCC() throws Exception {
	   
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		String     payload           = parse_And_Generate_Data("1365_Sc5_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("LCS PoC Post tender cart service sc_five should respond successfully")
	public void lcs_PoC_Post_tender_cart_service_sc_five_should_respond_successfully() {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1365_Sc5_Ex_Validations").getAsString());
		validatePosttender(Exp_Yaml, result_Object);
		
	}
	
	
	
	// Scenario - 6
	
	@Given("Audit DB,audit services,rule config,audit POD for sc_six should be up and running for Post tender execution {string}")
	public void audit_DB_audit_services_rule_config_audit_POD_for_sc_six_should_be_up_and_running_for_Post_tender_execution(String sale_Payload) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		post_Rule_Config(raw_Payload);
		
		this_Object.addProperty(Reference_Payload, sale_Payload);
		result_Object = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
	}

	@When("LCS PoC Post tender cart service is hit with existing earn tracker balance field as {string},set data,Valid headers {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_existing_earn_tracker_balance_field_as_set_data_Valid_headers(String string, String service_Payload) throws Exception {
	    
		
		String     payload           = parse_And_Generate_Data(service_Payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	
	
	
	// Scenario - 7
	
	@Given("Everyday rule set with current date between start date and end date in rule config for post tender")
	public void everyday_rule_set_with_current_date_between_start_date_and_end_date_in_rule_config_for_post_tender() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}

	@When("LCS PoC Post tender cart service is hit with transactionDate value as {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_transactionDate_value_as(String string, String service_Payload) throws Exception {
	    
		String     payload           = parse_And_Generate_Data(service_Payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS PoC Post tender cart service should respond successfully based on the set rules {string}")
	public void lcs_PoC_Post_tender_cart_service_should_respond_successfully_based_on_the_set_rules(String validation) {
	    
		if(!result_Object.get("Response_Code").getAsString().equals("500")) {
			Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get(validation).getAsString());
			validatePosttender(Exp_Yaml, result_Object);
		}
		else
			Assert.assertEquals("500", result_Object.get("Response_Code").getAsString());
	}
	
	
	
	
	// Scenario - 8
	@Given("Everyday rule set with current date is equal to  everyday rule start date and current date is less than everyday rule end date in rule config for post tender")
	public void everyday_rule_set_with_current_date_is_equal_to_everyday_rule_start_date_and_current_date_is_less_than_everyday_rule_end_date_in_rule_config_for_post_tender() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc8_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}
	
	
	
	
	// Scenario - 9
	
	@Given("Everyday rule set with current date is equal to  everyday rule start date and current date is equal to everyday rule end date in rule config for post tender")
	public void everyday_rule_set_with_current_date_is_equal_to_everyday_rule_start_date_and_current_date_is_equal_to_everyday_rule_end_date_in_rule_config_for_post_tender() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc9_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}



	// Scenario - 10
	
	@Given("Everyday rule set with current date is greater than  everyday rule start date and current date is equal to everyday rule end date in rule config for post tender")
	public void everyday_rule_set_with_current_date_is_greater_than_everyday_rule_start_date_and_current_date_is_equal_to_everyday_rule_end_date_in_rule_config_for_post_tender() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc10_Ex_Rule", this_Object);
		System.out.println("raw_Payload for rule is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}




	// Scenario - 11

	@When("LCS PoC Post tender cart service is hit with invalid value for {string} with header values {string} {string} {string} {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_invalid_value_for(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String status_code) throws Exception {
	   
		/*sending invalid header values from feature*/
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "9999-01-27T20:00:23+0530";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

        if (status_code.equals("400") || status_code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");
      
        //passing invalid msg id
        if (MessageID.contains("wrong"))
            negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");

        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS PoC Post tender cart service service should provide {string}")
	public void lcs_PoC_Post_tender_cart_service_service_should_provide(String string) {
	    
		if(string.equals("200")) {
			Assert.assertEquals("200", result_Object.get("Response_Code").getAsString());
		}
	}

	
	
	// Scenario - 12
	@When("LCS PoC Post tender cart service is hit with {string}> for Authorization header with Authorization values as {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_for_Authorization_header_with_Authorization_values_as(String string, String header_key, String header_secret) throws Exception {
	    
		negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", header_key);
        negative_this_Object.addProperty("SecretKey", header_secret);

        negative_this_Object.addProperty("400_example", "400_example");
        if (header_secret.equals("empty_secret")) {
            negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
        }
        
        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	
	
	//Scenario - 13
	
	@When("LCS PoC Post tender cart service is hit with {string} for Headers with header values {string} {string} {string} {string} {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_for_Headers_with_header_values(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
	   
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);

        //Based on this property, we will remove message id in utility
        if (header.equals("X-KOHLS-MessageID"))
            negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

        if (header.equals("X-KOHLS-CreateDateTime"))
            negative_this_Object.addProperty("Remove_date", "Remove_date");

        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");
        
        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS PoC Post tender cart service should provide {string} status code")
	public void lcs_PoC_Post_tender_cart_service_should_provide_status_code(String string) {
	    
		
	}
	
	
	//Scenario - 14
	
	@When("LCS PoC Post tender cart service is hit with {string} for Headers")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_for_Headers(String string) throws Exception {
	    
		 	negative_this_Object.addProperty("message_Id", "");
	        negative_this_Object.addProperty("time_Stamp", "");
	        negative_this_Object.addProperty("system_Cd", "");
	        negative_this_Object.addProperty("corrln_Id", "");
	        negative_this_Object.addProperty("API_KEY", "MASH");
	        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

	        //Remove headers in utility based on this property
	        negative_this_Object.addProperty("No_Header", "No_Header");
	        negative_this_Object.addProperty("400_example", "400_example");
	        
	        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
			payload = payload.replace("Loyalty_Id", loyaltyId);
			
			System.out.println("payload is $$$ :"+payload);
			negative_this_Object.addProperty("body_Payload", payload);
			
			result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
			
		    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	
	
	
	// Scenario - 17
	
	@When("LCS PoC Post tender cart service is hit with invalid endpoint")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_invalid_endpoint() throws Exception {
	    
		System.out.println("Test case for Invalid URL...");
		
		negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
		negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
		negative_this_Object.addProperty("system_Cd", "1231");
		negative_this_Object.addProperty("corrln_Id", "lpfqe");
		negative_this_Object.addProperty("API_KEY", "MASH");
		negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");
		negative_this_Object.addProperty("503_example", "503_example");

		negative_this_Object.addProperty("Invalid_URL", "Invalid_URL");
        
        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", negative_this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
		
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Posttender_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("message should be displayed as {string} for post tender")
	public void message_should_be_displayed_as_for_post_tender(String string) {
	    
		System.out.println("Assertions are completed in utility for negative cases..");
	}
	
	
	
	// Scenario - 18
	
	@Given("updated balance in balance table is {string} {string}")
	public void updated_balance_in_balance_table_is(String string, String sale_Payload) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc18_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		this_Object.addProperty(Reference_Payload, sale_Payload);
		result_Object = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
	}

	@When("LCS PoC Post tender cart service is hit with set data,Valid headers for no existing balance {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_set_data_Valid_headers_for_no_existing_balance(String service_Payload) throws Exception {
	    
		String     payload           = parse_And_Generate_Data(service_Payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
		result_Object = get_Posttender_Cart_Details(payload);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	
	//Scenario - 19
	
	@When("LCS PoC Post tender cart service is hit with {string} for Headers with header values null {string} {string} {string} {string} {string} {string}")
	public void lcs_PoC_Post_tender_cart_service_is_hit_with_for_Headers_with_header_values_null(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc18_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "null";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);
        if (MessageID.contains("null"))
            negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");


        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        String     payload           = parse_And_Generate_Data("1365_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Posttender_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS PoC Post tender cart service should provide {string} for null headers")
	public void lcs_PoC_Post_tender_cart_service_should_provide_for_null_headers(String string) {
	    
		if(string.equals("200")) {
			Assert.assertEquals("200", service_body_negative.get("Response_Code").getAsString());
		}
			
	}

}
