package Step_Defs.V2_Steps.Sprint3;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_Functional_Utilities.create_New_Loyalty_ID;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Service_Functions.Rule_Config_Functionalities.post_New_Rule_Config;
import static Service_Functions.V2.V2_Digital_Cart_Service.get_Digital_Cart_Details;
import static Service_Functions.V2.V2_Digital_Cart_Service.get_Digital_Cart_Details_Negative;
import static Service_Functions.V2.V2_Posttender_Cart_Service.get_Posttender_Cart_Details_Negative;
import static Service_Functions.V2.V2_Posttender_Cart_Service.validatePosttender;
import static Service_Functions.V2.V2_Rule_Config_Functions.post_Rule_Config;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;

import org.junit.Assert;

import static Service_Functions.V2.V2_Digital_Cart_Service.validateDigitalCart;


public class LPF_1362_Digital_Cart {

	String loyaltyId = null;
	
	JsonObject result_Object 			  = new JsonObject();
    JsonObject this_Object                = new JsonObject();
    JsonObject message_Posted             = new JsonObject();
    JsonObject result_Object_Kafka_Sale   = new JsonObject();
    
    JsonObject negative_this_Object  = new JsonObject();
    JsonObject service_body_negative = new JsonObject();
    JsonObject Exp_Yaml             = new JsonObject();
    
	//Scenario - 1
	@Given("Audit DB,audit services,rule config,audit POD should be up and running")
	public void audit_DB_audit_services_rule_config_audit_POD_should_be_up_and_running() throws Exception {

		loyaltyId = create_New_Loyalty_ID();
		
	}

	@When("LCS Cart & Checkout Service is hit with set data,Valid headers")
	public void lcs_Cart_Checkout_Service_is_hit_with_set_data_Valid_headers() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
		
	}

	@Then("LCS Cart & Checkout Service should respond successfully")
	public void lcs_Cart_Checkout_Service_should_respond_successfully() {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1362_Sc1_Ex_Validations").getAsString());
		validateDigitalCart(Exp_Yaml, result_Object);
	}
	
	
	//Scenario - 2
	@When("LCS Cart & Checkout Service is hit without {string} in request ,Valid headers with {string}")
	public void lcs_Cart_Checkout_Service_is_hit_without_in_request_Valid_headers(String string, String service_payload) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

        if(!service_payload.equals("1362_Sc2_Ex5_Payload"))
        	negative_this_Object.addProperty("400_example", "400_example");
        
        String payload = parse_And_Generate_Data(service_payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);
        
		System.out.println("payload is $$$ :"+payload);
		negative_this_Object.addProperty("body_Payload", payload);
		
		result_Object = get_Digital_Cart_Details_Negative(negative_this_Object);
		
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS Cart & Checkout Service should provide {string}")
	public void lcs_Cart_Checkout_Service_should_provide(String string) {
	    
		System.out.println("assertions are complete in utility for negative cases...");
		if(string.equals("200"))
			Assert.assertEquals("200",result_Object.get("Response_Code").getAsString());
	}
	
	
	//Scenario - 3
	
	@When("LCS Cart & Checkout Service is hit with two tender typecode value as {string}, {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_two_tender_typecode_value_as(String string, String string2) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		String     payload           = parse_And_Generate_Data("1362_Sc3_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("LCS Cart & Checkout Service sc_three should respond successfully")
	public void lcs_Cart_Checkout_Service_sc_3_should_respond_successfully() {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1362_Sc3_Ex_Validations").getAsString());
		validateDigitalCart(Exp_Yaml, result_Object);
	}
	
	
	//Scenario - 4
	
	@When("LCS Cart & Checkout Service is hit with two tender typecode values as {string}, {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_two_tender_typecode_values_as(String string, String string2, String service_payload) throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		String     payload           = parse_And_Generate_Data(service_payload, this_Object);
		
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("LCS Cart & Checkout Service should respond successfully {string}")
	public void lcs_Cart_Checkout_Service__should_respond_successfully(String validations) {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get(validations).getAsString());
		validateDigitalCart(Exp_Yaml, result_Object);
	}
	
	
	//Scenario - 5
	
	@When("LCS Cart & Checkout Service is hit without tender")
	public void lcs_Cart_Checkout_Service_is_hit_without_tender() throws Exception {

		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		String     payload           = parse_And_Generate_Data("1362_Sc5_Ex_Payload", this_Object);
		
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	} 

	@Then("LCS Cart & Checkout Service sc_five should respond successfully")
	public void lcs_Cart_Checkout_Service_sc5_should_respond_successfully() {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1362_Sc5_Ex_Validations").getAsString());
		validateDigitalCart(Exp_Yaml, result_Object);
	}
	
	@Then("updatedEarnTrackerBal field in response should calculate updated earn tracker balance considering tender type as KCC")
	public void updatedearntrackerbal_field_in_response_should_calculate_updated_earn_tracker_balance_considering_tender_type_as_KCC() {
	    
	}

	@Then("updatedEarnTrackerBalNonKcc field in response should calculate updated earn tracker balance considering tender type as Non KCC.")
	public void updatedearntrackerbalnonkcc_field_in_response_should_calculate_updated_earn_tracker_balance_considering_tender_type_as_Non_KCC() {
	    
		
	}
	
	
	
	//Scenario - 6
	
	@When("LCS Cart & Checkout Service is hit with tender typecode value as KCC")
	public void lcs_Cart_Checkout_Service_is_hit_with_tender_typecode_value_as_KCC() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		String     payload           = parse_And_Generate_Data("1362_Sc6_Ex_Payload", this_Object);
		
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("LCS Cart & Checkout Service sc_six should respond successfully")
	public void lcs_Cart_Checkout_Service_sc6_should_respond_successfully() {
	    
		Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get("1362_Sc6_Ex_Validations").getAsString());
		validateDigitalCart(Exp_Yaml, result_Object);
	}
	
	
	//Scenario - 7
	
	@Given("Everyday rule set with current date between start date and end date in rule config")
	public void everyday_rule_set_with_current_date_between_start_date_and_end_date_in_rule_config() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1362_Sc7_Ex_Rule_Config", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}

	@When("LCS Cart & Checkout Service is hit with transactionDate value as {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_transactionDate_value_as(String string, String Service_payload) throws Exception {
	    
		String payload = parse_And_Generate_Data(Service_payload, this_Object);
		
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}

	@Then("LCS Cart & Checkout Service should respond successfully based on the set rules {string}")
	public void lcs_Cart_Checkout_Service_should_respond_successfully_based_on_the_set_rules(String validations) {
	    
		if(!result_Object.get("Response_Code").getAsString().equals("500")) {
			Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get(validations).getAsString());
			validateDigitalCart(Exp_Yaml, result_Object);
		}
		else
			Assert.assertEquals("500", result_Object.get("Response_Code").getAsString());
	}

	
	
	// Scenario - 8
	
	@Given("Everyday rule set with current date is equal to  everyday rule start date and current date is less than everyday rule end date in rule config")
	public void everyday_rule_set_with_current_date_is_equal_to_everyday_rule_start_date_and_current_date_is_less_than_everyday_rule_end_date_in_rule_config() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1362_Sc8_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}

	@Then("LCS Cart & Checkout Service should respond successfully based on the rules set {string}")
	public void lcs_Cart_Checkout_Service_should_respond_successfully_based_on_the_rules_set(String validations) {
	    
		if(!result_Object.get("Response_Code").getAsString().equals("500")) {
			Exp_Yaml = convert_String_To_JsonObject(consolidated_Data.get(validations).getAsString());
			validateDigitalCart(Exp_Yaml, result_Object);
		}
		else
			Assert.assertEquals("500", result_Object.get("Response_Code").getAsString());

	}

	@Then("kohls cash calculation in the response will be based on the {string}")
	public void kohls_cash_calculation_in_the_response_will_be_based_on_the(String string) {
	    
		
	}
	
	
	//Scenario - 9
	
	@Given("Everyday rule set with current date is equal to  everyday rule start date and current date is equal to everyday rule end date in rule config")
	public void everyday_rule_set_with_current_date_is_equal_to_everyday_rule_start_date_and_current_date_is_equal_to_everyday_rule_end_date_in_rule_config() throws Exception {
	   
		String     raw_Payload           = parse_And_Generate_Data("1362_Sc9_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}
	
	
	
	//Scenario - 10
	
	@Given("Everyday rule set with current date is greater than  everyday rule start date and current date is equal to everyday rule end date in rule config")
	public void everyday_rule_set_with_current_date_is_greater_than_everyday_rule_start_date_and_current_date_is_equal_to_everyday_rule_end_date_in_rule_config() throws Exception {
	    
		String     raw_Payload           = parse_And_Generate_Data("1362_Sc10_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
	}
	
	
	
	// Scenario - 11
	
	@Given("Audit DB,audit services,rule config,audit POD should be up and running with {string}")
	public void audit_DB_audit_services_rule_config_audit_POD_should_be_up_and_running_with(String Service_Payload) throws Exception {
	    
		//loyaltyId = create_New_Loyalty_ID();
		String     raw_Payload           = parse_And_Generate_Data("1365_Sc1_Ex_Rule", this_Object);
		
		System.out.println("raw_Payload is $$$ :"+raw_Payload);
		post_Rule_Config(raw_Payload);
		
		System.out.println("Rule is posted...");
		
		this_Object.addProperty(Reference_Payload, Service_Payload);
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
	}
	
	@Given("loyaltyID has existing updated balance as{string}")
	public void loyaltyid_has_existing_updated_balance_as(String string) {
	    
		
	}

	@When("LCS Cart & Checkout Service is hit with set data,Valid headers {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_set_data_Valid_headers(String Service_payload) throws Exception {
	    
		String     payload           = parse_And_Generate_Data(Service_payload, this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload is $$$ :"+payload);
	    result_Object = get_Digital_Cart_Details(payload);
	    System.out.println("Service result is $$$ :"+result_Object.toString());
	}
	
	@Then("existingEarnTrackerBal,updatedEarnTrackerBal,updatedEarnTrackerBalNonKcc should calculate accordingly")
	public void existingearntrackerbal_updatedEarnTrackerBal_updatedEarnTrackerBalNonKcc_should_calculate_accordingly() {
	    
		
	}
	
	
	//Scenario - 12
	
	@When("LCS Cart & Checkout Service is hit with invalid value for {string} with header values {string} {string} {string} {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_invalid_value_for(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String status_code) throws Exception {
	    
		/*sending invalid header values from feature*/
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "9999-01-27T20:00:23+0530";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

        if (status_code.equals("400") || status_code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        //passing invalid msg id
        if (MessageID.contains("wrong"))
            negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");
        
        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS Cart & Checkout Service service should provide {string}")
	public void lcs_Cart_Checkout_Service_service_should_provide(String string) {
	    
		System.out.println("Assertions are completed in utility for negative test cases...");
		if(string.equals("200")) {
			Assert.assertEquals("200", service_body_negative.get("Response_Code").getAsString());
		}
	}
	
	
	//Scenario - 13
	
	@When("LCS Cart & Checkout Service is hit with {string} for Authorization header with Authorization values as {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_for_Authorization_header_with_Authorization_values_as(String string, String header_key, String header_secret) throws Exception {
	    
        negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", header_key);
        negative_this_Object.addProperty("SecretKey", header_secret);

        negative_this_Object.addProperty("400_example", "400_example");
        if (header_secret.equals("empty_secret")) {
            negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
        }
        
        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS Cart & Checkout Service should provide {int} status code")
	public void lcs_Cart_Checkout_Service_should_provide_status_code(Integer int1) {
	    
		System.out.println("Assertions are completed in utility for negative test cases...");
	}
	
	
	//Scenario - 14
	
	@When("LCS Cart & Checkout Service is hit with no value for {string} with header values {string} {string} {string} {string} {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_no_value_for_with_header_values(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
	    
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);

        //Based on this property, we will remove message id in utility
        if (header.equals("X-KOHLS-MessageID"))
            negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

        if (header.equals("X-KOHLS-CreateDateTime"))
            negative_this_Object.addProperty("Remove_date", "Remove_date");

        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}

	@Then("LCS Cart & Checkout Service should provide {string} status code")
	public void lcs_Cart_Checkout_Service_should_provide_status_code(String string) {
	    
		System.out.println("Assertions are completed in utility for negative test cases...");
	}
	
	
	// Scenario - 15
	
	@When("LCS Cart & Checkout Service is hit with {string} for Headers")
	public void lcs_Cart_Checkout_Service_is_hit_with_for_Headers(String string) throws Exception {
	    
        negative_this_Object.addProperty("message_Id", "");
        negative_this_Object.addProperty("time_Stamp", "");
        negative_this_Object.addProperty("system_Cd", "");
        negative_this_Object.addProperty("corrln_Id", "");
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");

        //Remove headers in utility based on this property
        negative_this_Object.addProperty("No_Header", "No_Header");
        negative_this_Object.addProperty("400_example", "400_example");
        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload of service is $$$ :"+payload);
        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
        
	}
	
	
	// Scenario - 16
	
	@When("LCS Cart & Checkout Service is hit with invalid endpoint")
	public void lcs_Cart_Checkout_Service_is_hit_with_invalid_endpoint() throws Exception {
	    
		System.out.println("Test case for Invalid URL...");
		
		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "MASH");
        this_Object.addProperty("SecretKey", "V3AwP7LiX3C4V1W4kPqa534SRPa4u6WPgCiXyy2x");
        this_Object.addProperty("503_example", "503_example");

        this_Object.addProperty("Invalid_URL", "Invalid_URL");
        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

		System.out.println("payload of service is $$$ :"+payload);
		this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());

	}

	@Then("LCS Cart & Checkout Service should provide {int} status code for invalid URL")
	public void lcs_Cart_Checkout_Service_should_provide_status_code_for_invalid_URL(Integer int1) {
	    
		System.out.println("Assertions are completed in utility for negative test cases...");
	}
	
	@Then("message should be displayed as {string} for Digital Cart")
	public void message_should_be_displayed_as_for_Digital_Cart(String string) {

		
	}

	
	// Scenario - 19
	
	@When("LCS Cart & Checkout Service is hit with {string} for Headers with header values null {string} {string} {string} {string} {string} {string}")
	public void lcs_Cart_Checkout_Service_is_hit_with_for_Headers_with_header_values_null(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
	    
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "null";

        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "MASH");
        negative_this_Object.addProperty("SecretKey", Secret_Key);
        if (MessageID.contains("null"))
            negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");


        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        String     payload           = parse_And_Generate_Data("1362_Sc1_Ex_Payload", this_Object);
		payload = payload.replace("Loyalty_Id", loyaltyId);

        negative_this_Object.addProperty("body_Payload", payload);
        service_body_negative = get_Digital_Cart_Details_Negative(negative_this_Object);

        System.out.println("service_body_negative is $$$ :" + service_body_negative.toString());
	}
	
	@Then("LCS Cart & Checkout Service should provide {string} for null headers")
	public void lcs_Cart_Checkout_Service_should_provide_for_null_headers(String string) {
	   
		System.out.println("assertions are complete in utility for negative cases...");
		if(string.equals("200"))
			Assert.assertEquals("200",service_body_negative.get("Response_Code").getAsString());
	}
}
