package Step_Defs.V2_Steps.Smoke_Tests;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.bson.conversions.Bson;

import java.util.HashMap;
import java.util.Map;

import static Service_Functions.V2.V2_Audit_Balance_Functions.get_Audit_Balance;
import static Service_Functions.V2.V2_Month_End_Functions.get_Month_End_Health_Check;
import static Service_Functions.V2.V2_Rule_Config_Functions.get_Rule_Config_Health_Check;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Lpf_Assert_Utilities.assert_200_Or_201;
import static Utilities.UtilConstants.*;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.ascending;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class Smoke_Tests {

    protected static final Logger logger = get_Logger();
    public                 String loyaltyId;

    @Given("I do smoke test For Balance_Service")
    public void i_do_smoke_test() throws Exception {

        JsonObject result_For_Balance = get_Audit_Balance("99999999AAAAA");
        assertTrue(result_For_Balance.entrySet().isEmpty());

        JsonObject aa = new JsonObject();
        aa.addProperty(Mongo_DataBase_Name, "kohlsrewardsaudit");
        aa.addProperty(Mongo_Coll_Name, "activity");
        Map<String, Bson> a2 = new HashMap<String, Bson>();
        a2.put(Mongo_Filter_Condition, eq("loyaltyId", "99999999AAAAA"));
        a2.put(Mongo_Sort_Condition, ascending("createdOn"));

        /*Todo check Mongo connection*/
        /*
            String     someValue_Demo       = aa.get(Mongo_DataBase_Name).getAsString();
            JsonObject result_Cursor_Object = mongo_Select_Query_Cursor(aa, a2);
            logger.info(result_Cursor_Object.toString());
            assertTrue(result_Cursor_Object.entrySet().isEmpty());
        */
        logger.info("Smoke Test Done");

    }

    @Given("I do smoke test For Month_End_Health_Check")
    public void i_do_smoke_test_Month_end() throws Exception {
        JsonObject result = get_Month_End_Health_Check(new JsonObject());
        assert_200_Or_201(result.get(Response_Code).getAsInt());
        assertTrue(result.get(Response_Body).getAsJsonObject().get("status").getAsString().contains("UP"));

    }

    @Given("I do smoke test For Rule_Config_Health_Check")
    public void i_do_smoke_test_Rule_Config() throws Exception {
        JsonObject result = get_Rule_Config_Health_Check(new JsonObject());
        assert_200_Or_201(result.get(Response_Code).getAsInt());
        assertTrue(result.get(Response_Body).getAsJsonObject().get("status").getAsString().contains("UP"));

    }

    @Then("It should pass")
    public void it_should_pass() {
        logger.info("___ Step 02");
        assertEquals(0, 0);
    }

    @Then("I just gave some dummy paramaters like {string} and this one {string} for later use")
    public void i_just_gave_some_dummy_paramaters_like_and_this_one(String string, String string2) {
        logger.info("___ Step 03");
        assertEquals(0, 0);
    }

}
