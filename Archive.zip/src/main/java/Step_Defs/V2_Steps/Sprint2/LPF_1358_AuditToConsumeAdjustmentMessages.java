
package Step_Defs.V2_Steps.Sprint2;


import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.V2.V2_Audit_Rewards.*;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Kafka_Utilities.send_Kafka_Message;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static org.junit.Assert.assertTrue;



public class LPF_1358_AuditToConsumeAdjustmentMessages {
    protected static final Logger logger = get_Logger();
    JsonObject sale_message_Posted = new JsonObject();
    JsonObject sale2_message_Posted = new JsonObject();
    JsonObject adjustment_message_Posted = new JsonObject();
    JsonObject adjustment_message2_Posted = new JsonObject();
    String loyaltyId = generateLoyaltyIdRandom();

/*    @Given("Audit DB should be up and running2")alternateid_orderNbr_associatedId_fulfillment_fulfillmentType_everydayKcc_earning_id_should_be_updated_as_null_in_Activity_table_of_Audit_database()
    public void audit_DB_should_be_up_and_running() {
        //TODO
    }*/

    @Given("For {string} sale message with {string},{string} as tender,with {string} event kohlscash earned, valid Loyalty ID should be there in MKTG_SALE topic for {string} and {string}")
    public void for_OMS_or_POC_sale_message_with_as_tender_with_event_kohlscash_earned_valid_Loyalty_ID_should_be_there_in_MKTG_SALE_topic(String fromApp, String qualifyingAmount, String tenderType, String kohlscash, String saleMessage, String transType) throws Exception {
        JsonObject saleValues = new JsonObject();
        saleValues.addProperty(Qualifying_Amount, qualifyingAmount.replace("$", ""));
        saleValues.addProperty(TenderType, tenderType);
        saleValues.addProperty(Event_kohlscash, kohlscash);
        saleValues.addProperty(Reference_Payload, saleMessage);
        saleValues.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);

        saleValues.addProperty(Trans_Type, transType);

        System.out.println("saleValues is :" + saleValues.toString());
        saleValues = calculateEarnDetail(saleValues);
        sale_message_Posted = convert_String_To_JsonObject(Post_Sales(saleValues).get(Kafka_Message_Body).getAsString());

        logger.info("Sale Message Payload$$:" + sale_message_Posted);
    }

    @Given("adjustment message with {string},{string},{string} for {string} sale should be there in MKTG_ADJUSTMENT topic for {string} with {string}")
    public void adjustment_message_with_for_OMS_sale_should_be_there_in_MKTG_ADJUSTMENT_topic(String adjustment_type, String adjustment_amount, String Event_kohlscash_unearned, String oms_poc, String adjustmentMessage, String transType) throws Exception {
        JsonObject adjustmentValues = new JsonObject();

        sale_message_Posted.addProperty(Trans_Type, transType);
        sale_message_Posted.addProperty(Adjustment_Amount, adjustment_amount.replace("$", ""));
        sale_message_Posted.addProperty(Adjustment_Type, adjustment_type);

        adjustmentValues = createAdjustmentPayload(sale_message_Posted);
        adjustmentValues.addProperty(Reference_Payload, adjustmentMessage);
        adjustmentValues.addProperty("Adjustment_Amount", adjustment_amount.replace("$", ""));
        adjustment_message_Posted = convert_String_To_JsonObject(Post_Adjustment(adjustmentValues).get(Kafka_Message_Body).getAsString());

        logger.info("Adjustment Message Payload $$:" + adjustment_message_Posted);
    }

    @Given("Sale2 {string} message with same loyaltyId {string},{string} as tender,with {string} event kohlscash earned, valid Loyalty ID should be there in MKTG_SALE topic for {string} and {string}")
    public void sale2_message_with_same_loyaltyId_as_tender_with_event_kohlscash_earned_valid_Loyalty_ID_should_be_there_in_MKTG_SALE_topic_for_and(String oms_poc, String qualifyingAmount, String tenderType, String kohlscash, String saleMessage, String transType) throws Exception {
        JsonObject saleValues = new JsonObject();
        saleValues.addProperty(Qualifying_Amount, qualifyingAmount.replace("$", ""));
        saleValues.addProperty(TenderType, tenderType);
        saleValues.addProperty(Event_kohlscash, kohlscash);
        saleValues.addProperty(Reference_Payload, saleMessage);
        saleValues.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);

//        saleValues.addProperty(Return_Amount, return_amount.replace("$", ""));
        saleValues.addProperty(Trans_Type, transType);
        saleValues = calculateEarnDetail(saleValues);
        sale2_message_Posted = convert_String_To_JsonObject(Post_Sales(saleValues).get(Kafka_Message_Body).getAsString());

        logger.info("Second Sale Message Payload$$:" + sale2_message_Posted);
    }

    @Given("adjustment message2 with {string},{string},{string} for {string} sale should be there in MKTG_ADJUSTMENT topic for {string} with {string}")
    public void adjustment_message2_for_Sale_with_for_OMS_sale_should_be_there_in_MKTG_RETURN_topic_with(String adjustment_type, String adjustment_amount, String Event_kohlscash_unearned, String oms_poc, String adjustmentMessage, String transType) throws Exception {
        JsonObject adjustmentValues = new JsonObject();

        sale2_message_Posted.addProperty(Trans_Type, transType);
        sale2_message_Posted.addProperty(Adjustment_Amount, adjustment_amount.replace("$", ""));
        sale2_message_Posted.addProperty(Adjustment_Type, adjustment_type);

        adjustmentValues = createAdjustmentPayload(sale2_message_Posted);
        adjustmentValues.addProperty(Reference_Payload, adjustmentMessage);
        adjustmentValues.addProperty("Adjustment_Amount", adjustment_amount.replace("$", ""));
        adjustment_message2_Posted = convert_String_To_JsonObject(Post_Adjustment(adjustmentValues).get(Kafka_Message_Body).getAsString());

        logger.info("Second Adjustment Message Payload $$:" + adjustment_message2_Posted);
    }

    @Given("An {string} sale message should be there in MKTG_SALE topic for {string}")
    public void OMS_sale_message_should_be_there_in_MKTG_SALE_topic_with(String fromApp, String saleReference) throws Exception {
        JsonObject pass_Data = new JsonObject();
        pass_Data.addProperty(Reference_Payload, saleReference);

        pass_Data.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_message_Posted = convert_String_To_JsonObject(Post_Sales(pass_Data).get(Kafka_Message_Body).getAsString());
        logger.info("Sale Message Payload ----$$:" + sale_message_Posted);
    }

    @Given("Adjustment message {string} for that sale should be there in MKTG_ADJUSTMENT topic")
    public void adjustment_message_for_that_sale_should_be_there_in_MKTG_ADJUSTMENT_topic(String adjustmentReference) throws Exception {

        JsonObject pass_Data             = new JsonObject();

        pass_Data.addProperty(Reference_Payload, adjustmentReference);
        pass_Data.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        if(sale_message_Posted.getAsJsonObject("messageBody") != null) {
            JsonObject transkey = sale_message_Posted.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");
            pass_Data.addProperty(Rule_Replace_Transaction_Nbr, transkey.get("transactionNbr").getAsString());
            pass_Data.addProperty(Rule_Replace_Transaction_Date, transkey.get("transactionDate").getAsString());
            pass_Data.addProperty(Rule_Replace_Transaction_Time, transkey.get("transactionTime").getAsString());
        }

        JsonObject adjustmentMsg = convert_String_To_JsonObject(Post_Return(pass_Data).get(Kafka_Message_Body).getAsString());
        logger.info("Return Message Payload $$:"+adjustmentMsg);

    }


    @When("Audit listener process the adjustment message")
    public void audit_listener_process_the_adjustment_message() {

    }

    @When("adjustment transactions will not be loaded in audit database")
    public void adjustment_transactions_will_not_be_loaded_in_audit_database() throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
        assertTrue("Audit should not contain Rows for the given loyalty", actual.get("deductions") == null);
        logger.info("Audit Activity deductions $$:"+actual.get("deductions"));
    }

    @Then("audit listener app should filter the Adjustment message as {string}")
    public void the_audit_listener_app_should_filter_the_adjustment_message_as(String string) throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
        assertTrue("Audit should not contian Rows for the given loyalty", actual == null);
        logger.info("Audit Activity should be NULL $$:"+actual);
    }


    @When("message will be filtered by audit listener app")
    public void message_will_be_filtered_by_audit_listener_app() throws Exception {

    }


    @When("Audit listener process the adjustment messages for sale 1 and sale 2")
    public void audit_listener_process_the_adjustment_messages_for_both_sales() {

    }

    @And("same message is redropped in MKTG_ADJUSTMENT topic")
    public void same_message_is_re_dropped_in_MKTG_ADJUSTMENT_topic() throws Exception {
        JsonObject pass_Data = new JsonObject();
        pass_Data.addProperty(Kafka_Topic_name, "MKTG_ADJUSTMENT");
        pass_Data.addProperty(Kafka_Message_Body, adjustment_message_Posted.toString());
        pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom());
        JsonObject adjustmentMsg = send_Kafka_Message(pass_Data);
        logger.info("Second Adjustment Message Payload $$:" + adjustmentMsg);
    }

    @Then("the adjustment message will be filtered by audit listener app")
    public void the_adjustment_message_will_be_filtered_by_audit_listener_app() throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
        assertTrue("Audit not filtering Dupicate Return message", actual.getAsJsonArray("deductions").size() == 1);

    }

    @Then("After adjustment validate activity Table of Audit database with {string}")
    public void validate_activity_Table_of_Audit_database_with(String validationKey) throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
        if(consolidated_Data.get(validationKey + "_Activity").isJsonObject()) {
            JsonObject expected = consolidated_Data.get(validationKey + "_Activity").getAsJsonObject();
            validateActivity(expected, actual, sale_message_Posted);
        }
    }

    @Then("After adjustment validate activity Table of Audit database with {string} for Sale2")
    public void validate_activity_Table_of_Audit_database_with_for_sale2(String validationKey) throws Exception {
        JsonObject actual = get_Rewards_Activity_Rows(loyaltyId).get("2").getAsJsonObject();
        if (actual != null) {
            if(consolidated_Data.get(validationKey + "_Activity").isJsonObject()) {
                JsonObject expected = consolidated_Data.get(validationKey + "_Activity").getAsJsonObject();
                validateActivity(expected, actual, sale_message_Posted);
            }
        } else {
            assertTrue("Audit activity Rows", actual != null);
        }

    }


    @Then("After adjustment validate balanceId,activityId,loyaltyId,updatedBalance,createdOn should be updated in balance Table of Audit database with {string}")
    public void balanceid_activityId_loyaltyId_updatedBalance_createdOn_should_be_updated_in_balance_Table_of_Audit_database_with(String validationKey) throws Exception {
        JsonObject actual = get_Rewards_Balance_First_row(loyaltyId);
        if(consolidated_Data.get(validationKey + "_Balance").isJsonObject()) {
            JsonObject expected = consolidated_Data.get(validationKey + "_Balance").getAsJsonObject();
            validateBalance(expected, actual);
        }

    }

    //TODO
    @Given("kohlscash should be generated after the month end process with {string},{string} for {string}")
    public void kohlscash_should_be_generated_after_the_month_end_process_with_for_sale(String string, String string2, String Sale_msg) {

    }

    //TODO
    @Then("kohlscash should unearn from {string} for {string}")
    public void kohlscash_should_unearn_from(String string, String adjMsg) {

    }

    @Then("balanceId,activityId,loyaltyId,updatedBalance,createdOn should be updated in balance Table of Audit database2")
    public void balanceid_activityId_loyaltyId_updatedBalance_createdOn_should_be_updated_in_balance_Table_of_Audit_database() {
    }

    @Then("activityId,loyaltyId,originalActivityId,tranKey.storeNbr,tranKey.registerId,tranKey.transactionNbr,tranKey.transactionDate,tranKey.transactionTime,activityTypeCode,activityDesc,activitydate,activitytime,receiptId,sourceSystemCode,transactionAmt,everydayNonkcc,qualifyingAmt,refundDeduction,items,tenders,messageDetail.messageId,messageDetail.fromApp,messageDetail.topic,messageDetail.partition,messageDetail.offset,createdBy,createdOn should be updated in Activity table of Audit database2")
    public void activityid_loyaltyId_originalActivityId_tranKey_storeNbr_tranKey_registerId_tranKey_transactionNbr_tranKey_transactionDate_tranKey_transactionTime_activityTypeCode_activityDesc_activitydate_activitytime_receiptId_sourceSystemCode_transactionAmt_everydayNonkcc_qualifyingAmt_refundDeduction_items_tenders_messageDetail_messageId_messageDetail_fromApp_messageDetail_topic_messageDetail_partition_messageDetail_offset_createdBy_createdOn_should_be_updated_in_Activity_table_of_Audit_database() {
    }

    @Then("alternateId,orderNbr,associatedId,fulfillment,fulfillmentType,everydayKcc,earning_id should be updated as null in Activity table of Audit database2")
    public void alternateid_orderNbr_associatedId_fulfillment_fulfillmentType_everydayKcc_earning_id_should_be_updated_as_null_in_Activity_table_of_Audit_database() {
    }



}
