package Step_Defs.V2_Steps.Sprint2;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.ArrayList;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Activity_First_Row;
import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.V2.V2_Audit_Return_Service.*;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class LPF_1394_Audit_Return_Service {
	

	String loyaltyId = null;
	JsonObject data = new JsonObject();
	JsonObject service_Result = new JsonObject();
	
	JsonObject result_Object_Kafka_Return = new JsonObject();
    JsonObject result_Object_Kafka_Sale   = new JsonObject();
    JsonObject this_Object                = new JsonObject();
    JsonObject message_Posted             = new JsonObject();
    JsonObject message_Posted2            = new JsonObject();
    JsonObject mongo_Result               = new JsonObject();
    JsonObject negative_this_Object       = new JsonObject();
    JsonObject result_Adjust_Object_Kafka = new JsonObject();
    
	
    
	//Scenario - 1
    
	@Given("Audit DB has sale transaction with {string},{string} for valid loyalty ID {string} {string}")
	public void audit_DB_has_sale_transaction_with_for_valid_loyalty_ID(String string, String string2, String payload_reference, String payload_Return) throws Exception {
	    
		
		this_Object.addProperty(Reference_Payload, payload_reference);
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();

        ArrayList<String> sale_Values = get_TransactionValues_From_SaleMessage(result_Object_Kafka_Sale);

        this_Object.addProperty(Reference_Payload, payload_Return);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale_Values.get(0));
        this_Object.addProperty(Rule_Replace_Transaction_Date, sale_Values.get(3));
        this_Object.addProperty(Rule_Replace_Transaction_Time, sale_Values.get(4));
        
        if (result_Object_Kafka_Sale.has("barcode"))
            this_Object.addProperty(Rule_Replace_Bar_Code, sale_Values.get(6));
        
        result_Object_Kafka_Return = Post_Return(this_Object);
        
        mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
	}

	@When("Audit Returns Service is hit with set data,Valid headers")
	public void audit_Returns_Service_is_hit_with_set_data_Valid_headers() throws Exception {
		
		//JsonObject result_Return = mongo_Result.get("deductions").getAsJsonArray().get(0).getAsJsonObject().get("tranKey").getAsJsonObject();
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		
		String aaa = result_Return2.toString();
		service_Result = return_Service_Details(aaa);
		
		service_Result = service_Result.get("Response_Body").getAsJsonObject();
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}

	@Then("Audit Returns Service should respond successfully with details {string}")
	public void audit_Returns_Service_should_respond_successfully_with_details( String validations_data) {
	    
		JsonObject exp_Info = convert_String_To_JsonObject(consolidated_Data.get(validations_data).getAsString());
    	//validateActivityDetails(activity_Id, result_Json, exp_Info);
    	
    	validate_Audit_Return_Service(exp_Info, service_Result, message_Posted);
	}


	
	
	//Scenario - 2
	
	@Given("Audit DB has {string} transaction with valid LoyaltyId,${int} as Qualifying amount,NKCC as tender")
	public void audit_DB_has_transaction_with_valid_LoyaltyId_$_as_Qualifying_amount_NKCC_as_tender(String string, Integer int1) throws Exception {
	    
		this_Object.addProperty(Reference_Payload, "1394_Sc2_Ex1_Sale1");
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
	}

	@Given("Audit DB has {string} transaction for same loyaltyID,${int} as Qualifying amount,KCC as tender")
	public void audit_DB_has_transaction_for_same_loyaltyID_$_as_Qualifying_amount_KCC_as_tender(String string, Integer int1) throws Exception {
	    
		this_Object.addProperty(Reference_Payload, "1394_Sc2_Ex1_Sale2");
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted2 = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted2.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
        
        mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
	}


	
	@When("Audit Returns Service is hit with set data of {string} in request")
	public void audit_Returns_Service_is_hit_with_set_data_of_in_request(String string) throws Exception {
	    
		//JsonObject result_Return = mongo_Result.get("deductions").getAsJsonArray().get(0).getAsJsonObject().get("tranKey").getAsJsonObject();
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		
		String aaa = result_Return2.toString();
		service_Result = return_Service_Details(aaa);
		
		service_Result = service_Result.get("Response_Body").getAsJsonObject();
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}


	
	//Scenario - 3
	
	@Given("transaction is not present in Audit DB")
	public void transaction_is_not_present_in_Audit_DB() {
	    
		//No need to store any details
	}

	@When("Audit Returns Service is hit with set data in request")
	public void audit_Returns_Service_is_hit_with_set_data_in_request() throws Exception {
	    
		String aaa = consolidated_Data.get("1394_Sc3_Ex_Sale_Validations").getAsString();
		
		this_Object.addProperty("body_Payload", aaa);
		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        this_Object.addProperty("404_example", "404_example");
        
		service_Result = return_Service_Details_Negative(this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}

	@Then("Audit Returns Service should respond with {int} status code")
	public void audit_Returns_Service_should_respond_with_status_code(Integer int1) {
	    
		System.out.println("Assertions are complete in Utility for negative cases...");
	}

	
	//Scenario - 4
	
	@Given("Audit DB has {string} with valid loyalty ID {string} {string}")
	public void audit_DB_has_with_valid_loyalty_ID(String trans_type, String payload_reference, String payload_Return) throws Exception {
	    
		this_Object.addProperty(Reference_Payload, payload_reference);
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();


        /*this_Object.addProperty(Reference_Payload, payload_Return);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale_Values.get(0));
        this_Object.addProperty(Rule_Replace_Transaction_Date, sale_Values.get(3));
        this_Object.addProperty(Rule_Replace_Transaction_Time, sale_Values.get(4));
        
        if (result_Object_Kafka_Sale.has("barcode"))
            this_Object.addProperty(Rule_Replace_Bar_Code, sale_Values.get(6));*/
        
        //result_Object_Kafka_Return = Post_Return(this_Object);
        
        //This condition is only for adjust sale 
        if(trans_type.equals("Associate_Adjustment")) {
        	
        	ArrayList<String> sale_Values = get_TransactionValues_From_SaleMessage(result_Object_Kafka_Sale);
        	
            this_Object.addProperty(Reference_Payload, payload_Return);
            this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
            this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale_Values.get(0));
            this_Object.addProperty(Rule_Replace_Transaction_Date, sale_Values.get(3));
            this_Object.addProperty(Rule_Replace_Transaction_Time, sale_Values.get(4));
            
            if (result_Object_Kafka_Sale.has("barcode"))
                this_Object.addProperty(Rule_Replace_Bar_Code, sale_Values.get(6));

            //For Associate adjustment
                result_Adjust_Object_Kafka = Post_Adjustment(this_Object);
        }
        
        mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
	}

	
	
	//Scenario - 5
	
	@Given("Audit DB has Transaction details for valid loyalty ID")
	public void audit_DB_has_Transaction_details_for_valid_loyalty_ID() throws Exception {
	    
		this_Object.addProperty(Reference_Payload, "1394_Sc_Common_Ex_Sale");
        result_Object_Kafka_Sale = Post_Sales(this_Object);
        message_Posted = convert_String_To_JsonObject(result_Object_Kafka_Sale.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();
	}

	@When("Audit Returns Service is hit with {string},{string} in request fields {string}")
	public void audit_Returns_Service_is_hit_with_in_request_fields(String request_field, String string2, String body_Payload) throws Exception {
	    
		String aaa = consolidated_Data.get(body_Payload).getAsString();
		
		this_Object.addProperty("body_Payload", aaa);
		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        if(request_field.equals("transactionDate") || request_field.equals("transactionTime"))
        	this_Object.addProperty("400_example", "400_example");
        else
        	this_Object.addProperty("404_example", "404_example");
        
		service_Result = return_Service_Details_Negative(this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}
	
	
	
	// Scenario - 6
	
	@When("Audit Returns Service is hit with missing value in request {string} fields {string}")
	public void audit_Returns_Service_is_hit_with_missing_value_in_request_fields(String string, String body_Payload) throws Exception {
	    
		String aaa = consolidated_Data.get(body_Payload).getAsString();
		
		this_Object.addProperty("body_Payload", aaa);
		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        this_Object.addProperty("400_example", "400_example");
        
		service_Result = return_Service_Details_Negative(this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}
	
	
	//Scenario - 7
	
	@When("Audit Returns Service is hit with missing {string} fields {string}")
	public void audit_Returns_Service_is_hit_with_missing_fields(String string, String body_Payload) throws Exception {
	    
		audit_Returns_Service_is_hit_with_missing_value_in_request_fields(string, body_Payload);
	}
	
	
	//Scenario - 8
	
	@When("Audit Returns Service is hit with set data, invalid value for {string} with header values {string} {string} {string} {string} {string}")
	public void audit_Returns_Service_is_hit_with_set_data_invalid_value_for_with_header_values(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String status_code) throws Exception {
	    
		
		mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		
		String aaa = result_Return2.toString();
		
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "9999-01-27T20:00:23+0530";

		
        negative_this_Object.addProperty("body_Payload", aaa);
        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", "localtestingsecretkey");

        if (status_code.equals("400") || status_code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        //passing invalid msg id
        if(MessageID.contains("wrong"))
        	negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");

        service_Result = return_Service_Details_Negative(negative_this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());

	}

	@Then("Audit Returns Service should respond with {string}")
	public void audit_Returns_Service_should_respond_with(String string) {
	    
		System.out.println("Assertions are complete in Utility for negative cases...");
	}
	
	
	// Scenario - 9
	
	@When("Audit Returns Service is hit with set data,{string} for Authorization header with Authorization values as {string} {string}")
	public void audit_Returns_Service_is_hit_with_set_data_for_Authorization_header_with_Authorization_values_as(String string, String header_key, String header_secret) throws Exception {
	    
		mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		String aaa = result_Return2.toString();
		
		negative_this_Object.addProperty("body_Payload", aaa);
		
        negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", header_key);
        negative_this_Object.addProperty("SecretKey", header_secret);

        negative_this_Object.addProperty("400_example", "400_example");
        if (header_secret.equals("")) {
            negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
        }
        
        service_Result = return_Service_Details_Negative(negative_this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());

	}

	
	//Scenario - 10
	
	@When("Audit Returns Service is hit with set data, no value for {string} with header values {string} {string} {string} {string} {string} {string}")
	public void audit_Returns_Service_is_hit_with_set_data_no_value_for_with_header_values(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {
	    
		mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		String aaa = result_Return2.toString();
		
		//sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "";

        negative_this_Object.addProperty("body_Payload", aaa);
        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", Secret_Key);

        //Based on this property, we will remove message id in utility
        if (header.equals("X-KOHLS-MessageID"))
            negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

        if (header.equals("X-KOHLS-CreateDateTime"))
            negative_this_Object.addProperty("Remove_date", "Remove_date");

        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        service_Result = return_Service_Details_Negative(negative_this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}

	@Then("Audit Returns Service should respond with {string} status code")
	public void audit_Returns_Service_should_respond_with_status_code(String string) {
	    
		
	}

	
	// Scenario - 11
	
	@When("Audit Returns Service is hit with set data,no Headers")
	public void audit_Returns_Service_is_hit_with_set_data_no_Headers() throws Exception {
	    
		mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		String aaa = result_Return2.toString();
		
		negative_this_Object.addProperty("body_Payload", aaa);
        negative_this_Object.addProperty("message_Id", "");
        negative_this_Object.addProperty("time_Stamp", "");
        negative_this_Object.addProperty("system_Cd", "");
        negative_this_Object.addProperty("corrln_Id", "");
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", "localtestingsecretkey");
        
        //Remove headers in utility based on this property
        negative_this_Object.addProperty("No_Header", "No_Header");
        negative_this_Object.addProperty("400_example", "400_example");
        
        service_Result = return_Service_Details_Negative(negative_this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}
	
	
	
	// Scenario - 12
	
	@When("Audit Returns Service is hit with invalid resource URL")
	public void audit_Returns_Service_is_hit_with_invalid_resource_URL() throws Exception {
	   
		mongo_Result = get_Rewards_Activity_First_Row(loyaltyId);
        System.out.println("mongo_Result is $$$ :"+mongo_Result.toString());
		
		JsonObject result_Return2 = mongo_Result.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
		String aaa = result_Return2.toString();
		
		this_Object.addProperty("body_Payload", aaa);
		
		this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        this_Object.addProperty("404_example", "404_example");
        this_Object.addProperty("Invalid_URL", "Invalid_URL");
        
        service_Result = return_Service_Details_Negative(this_Object);
		
		System.out.println("service_Result is $$$ :"+service_Result.toString());
	}
	
}
