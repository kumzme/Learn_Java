package Step_Defs.V2_Steps.Sprint2;

import Functional_Utilities.V2_Functional_Utilities;
import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Return;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Service_Functions.V2.V2_Audit_Rewards.*;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Kafka_Utilities.send_Kafka_Message;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static org.junit.Assert.assertTrue;

public class LPF_1341_AuditToConsumeOMSReturnMessages {
	protected static final Logger logger = get_Logger();
	JsonObject sale_message_Posted = new JsonObject();
	JsonObject return_message_Posted = new JsonObject();
	JsonObject sale2_message_Posted = new JsonObject();
	JsonObject return2_message_Posted = new JsonObject();
	String loyaltyId = generateLoyaltyIdRandom();

	@Given("Audit DB should be up and running")
	public void audit_DB_should_be_up_and_running() {
		// TODO
	}

	@Given("An {string} sale message with {string},{string} as tender,with {string} event kohlscash earned, valid Loyalty ID should be there in MKTG_SALE topic with {string} for {string} and {string}")
	public void an_OMS_sale_message_with_as_tender_with_event_kohlscash_earned_valid_Loyalty_ID_should_be_there_in_MKTG_SALE_topic(
			String fromApp, String qualifyingAmount, String tenderType, String kohlscash, String saleMessage,
			String return_type, String return_amount) throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		JsonObject saleValues = new JsonObject();
		saleValues.addProperty(Qualifying_Amount, qualifyingAmount.replace("$", ""));
		saleValues.addProperty(TenderType, tenderType);
		saleValues.addProperty(Event_kohlscash, kohlscash);
		saleValues.addProperty(Reference_Payload, saleMessage);
		saleValues.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);

		saleValues.addProperty(Return_Amount, return_amount.replace("$", ""));
		saleValues.addProperty(Return_Type, return_type);
        saleValues = calculateEarnDetail(saleValues);
		sale_message_Posted = convert_String_To_JsonObject(
				Post_Sales(saleValues).get(Kafka_Message_Body).getAsString());

		logger.info("Sale1 Message Payload Posted");
	}

	@Given("return message with {string},{string},{string} for {string} sale should be there in MKTG_RETURN topic with {string}")
	public void return_message_with_for_OMS_sale_should_be_there_in_MKTG_RETURN_topic(String return_type,
			String return_amount, String Event_kohlscash_unearned, String fromApp, String returnMessage)
			throws Exception {
		JsonObject retunValues = new JsonObject();

		sale_message_Posted.addProperty(Return_Amount, return_amount.replace("$", ""));
		sale_message_Posted.addProperty(Return_Type, return_type);

        retunValues = createReturnPayload(sale_message_Posted);
		retunValues.addProperty(Reference_Payload, returnMessage);
		return_message_Posted = convert_String_To_JsonObject(
				Post_Return(retunValues).get(Kafka_Message_Body).getAsString());

		logger.info("Return1 Message Posted");
	}

	@Given("return2 message for Sale2 with {string},{string},{string} for {string} sale should be there in MKTG_RETURN topic with {string} as Multirecipt return")
	public void return_message_for_Sale_with_for_OMS_sale_should_be_there_in_MKTG_RETURN_topic_with_MRR(
			String return_type, String return_amount, String Event_kohlscash_unearned, String fromApp,
			String returnMessage) throws Exception {
		JsonObject retunValues = new JsonObject();

		sale2_message_Posted.addProperty(Return_Amount, return_amount.replace("$", ""));
		sale2_message_Posted.addProperty(Return_Type, return_type);

		JsonObject transKey = return_message_Posted.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");

        retunValues = createReturnPayload(sale2_message_Posted);
		retunValues.addProperty(Reference_Payload, returnMessage);
		retunValues.addProperty("MRR_transactionNbr", transKey.get("transactionNbr").getAsString());
		retunValues.addProperty("MRR_transactionDate", transKey.get("transactionDate").getAsString());
		retunValues.addProperty("MRR_transactionTime", transKey.get("transactionTime").getAsString());

		return2_message_Posted = convert_String_To_JsonObject(
				Post_Return(retunValues).get(Kafka_Message_Body).getAsString());

		logger.info("MRR Return2 Message Posted");
	}

	@And("same message is redropped in MKTG_RETURN topic")
	public void and_same_message_is_redropped_in_MKTG_RETURN_topic() throws Exception {
		JsonObject pass_Data = new JsonObject();
		pass_Data.addProperty(Kafka_Topic_name, "MKTG_RETURN");
		pass_Data.addProperty(Kafka_Message_Body, return_message_Posted.toString());
		pass_Data.addProperty(Kafka_Message_Key, generateLoyaltyIdRandom());
		send_Kafka_Message(pass_Data);
		logger.info("Second Return Message posted");
	}

	@Then("the return message will be filtered by audit listener app")
	public void the_return_message_will_be_filtered_by_audit_listener_app() throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
		assertTrue("Audit not filtering Dupicate Return message", actual.getAsJsonArray("deductions").size() == 1);

	}

	@When("Audit listener process the return message")
	public void audit_listener_process_the_return_message() {

	}

	@Then("Validate activity Table of Audit database with {string}")
	public void validate_activity_Table_of_Audit_database_with(String validationKey) throws Exception {

		if (consolidated_Data.get(validationKey + "_Sale").isJsonObject()) {
            JsonObject actual   = get_Rewards_Activity_First_Row(loyaltyId);
			JsonObject expected = consolidated_Data.get(validationKey + "_Sale").getAsJsonObject();
            validateActivity(expected, actual, sale_message_Posted);
		}

	}

	@Then("Validate activity Table of Audit database with {string} for Sale2")
	public void validate_activity_Table_of_Audit_database_with_sale2(String validationKey) throws Exception {

		if (consolidated_Data.get(validationKey + "_Sale").isJsonObject()) {
            JsonObject actual = get_Rewards_Activity_Rows(loyaltyId).get("2").getAsJsonObject();
			if (actual != null) {
				JsonObject expected = consolidated_Data.get(validationKey + "_Sale").getAsJsonObject();
                validateActivity(expected, actual, sale2_message_Posted);

			} else {
				assertTrue("Audit activity Rows", actual != null);
			}

		}

	}

	@Then("balanceId,activityId,loyaltyId,updatedBalance,createdOn should be updated in balance Table of Audit database  with {string}")
	public void balanceid_activityId_loyaltyId_updatedBalance_createdOn_should_be_updated_in_balance_Table_of_Audit_database_with(
			String validationKey) throws Exception {

		if (consolidated_Data.get(validationKey + "_Return").isJsonObject()) {
            JsonObject actual   = get_Rewards_Balance_First_row(loyaltyId);
			JsonObject expected = consolidated_Data.get(validationKey + "_Return").getAsJsonObject();
            validateBalance(expected, actual);
		}

	}

	@Given("Sale2 message with same loyaltyId {string},{string} as tender,with {string} event kohlscash earned, valid Loyalty ID should be there in MKTG_SALE topic with {string} for {string} and {string}")
	public void sale_message_with_same_loyaltyId_as_tender_with_event_kohlscash_earned_valid_Loyalty_ID_should_be_there_in_MKTG_SALE_topic_with_for_and(
			String qualifyingAmount, String tenderType, String kohlscash, String saleMessage, String return_type,
			String return_amount) throws Exception {

		JsonObject saleValues = new JsonObject();
		saleValues.addProperty(Qualifying_Amount, qualifyingAmount.replace("$", ""));
		saleValues.addProperty(TenderType, tenderType);
		saleValues.addProperty(Event_kohlscash, kohlscash);
		saleValues.addProperty(Reference_Payload, saleMessage);
		saleValues.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);

		saleValues.addProperty(Return_Amount, return_amount.replace("$", ""));
		saleValues.addProperty(Return_Type, return_type);
        saleValues = calculateEarnDetail(saleValues);
		sale2_message_Posted = convert_String_To_JsonObject(
				Post_Sales(saleValues).get(Kafka_Message_Body).getAsString());

		logger.info("Second Sale Message Posted");
	}

	@Given("return2 message for Sale2 with {string},{string},{string} for {string} sale should be there in MKTG_RETURN topic with {string}")
	public void return_message_for_Sale_with_for_OMS_sale_should_be_there_in_MKTG_RETURN_topic_with(String return_type,
			String return_amount, String Event_kohlscash_unearned, String fromApp, String returnMessage)
			throws Exception {
		JsonObject retunValues = new JsonObject();

		sale2_message_Posted.addProperty(Return_Amount, return_amount.replace("$", ""));
		sale2_message_Posted.addProperty(Return_Type, return_type);

        retunValues = createReturnPayload(sale2_message_Posted);
		retunValues.addProperty(Reference_Payload, returnMessage);
		return2_message_Posted = convert_String_To_JsonObject(
				Post_Return(retunValues).get(Kafka_Message_Body).getAsString());

		logger.info("Second Return Message Posted");
	}

	@When("Audit listener process the return messages for sale {int} and sale {int}")
	public void audit_listener_process_the_return_messages_for_sale_and_sale(Integer int1, Integer int2) {

	}

	@Given("{string} Sale transaction should not be there in Audit database")
	public void oms_Sale_transaction_should_not_be_there_in_Audit_database(String fromApp) {
		logger.info("OMS Sale transaction not there in Audit database");
	}

	@Given("Return message {string} for that sale should be there in MKTG_RETURN topic")
	public void return_message_for_that_sale_should_be_there_in_MKTG_RETURN_topic(String returnReference)
			throws Exception {

		JsonObject pass_Data = new JsonObject();

		pass_Data.addProperty(Reference_Payload, returnReference);
		pass_Data.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
		if (sale_message_Posted.getAsJsonObject("messageBody") != null) {
			JsonObject transkey = sale_message_Posted.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");
			pass_Data.addProperty(Rule_Replace_Transaction_Nbr, transkey.get("transactionNbr").getAsString());
			pass_Data.addProperty(Rule_Replace_Transaction_Date, transkey.get("transactionDate").getAsString());
			pass_Data.addProperty(Rule_Replace_Transaction_Time, transkey.get("transactionTime").getAsString());
		}

		convert_String_To_JsonObject(Post_Return(pass_Data).get(Kafka_Message_Body).getAsString());
		logger.info("Return Message Posted");

	}

	@Then("the audit listener app should filter the return message as {string}")
	public void the_audit_listener_app_should_filter_the_return_message_as(String string) throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
		assertTrue("Audit should not contian Rows for the given loyalty", actual == null);
		logger.info("Audit Activity should be NULL $$:" + actual);
	}

	@Given("An {string} sale message should be there in MKTG_SALE topic with {string}")
	public void an_OMS_sale_message_should_be_there_in_MKTG_SALE_topic_with(String fromApp, String saleReference)
			throws Exception {
		loyaltyId = V2_Functional_Utilities.create_New_Loyalty_ID();
		JsonObject pass_Data = new JsonObject();
		pass_Data.addProperty(Reference_Payload, saleReference);

		pass_Data.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
		sale_message_Posted = convert_String_To_JsonObject(Post_Sales(pass_Data).get(Kafka_Message_Body).getAsString());
		logger.info("Sale Message Posted");
	}

	@When("return transactions will not be loaded in audit database")
	public void return_transactions_will_not_be_loaded_in_audit_database() throws Exception {
        JsonObject actual = get_Rewards_Activity_First_Row(loyaltyId);
		assertTrue("Audit should not contian Rows for the given loyalty", actual.get("deductions") == null);

	}

	// TODO
	@Given("kohlscash should be generated after the month end process with {string},{string}")
	public void kohlscash_should_be_generated_after_the_month_end_process_with(String string, String string2) {

	}

	// TODO
	@Then("kohlscash should unearn from {string}")
	public void kohlscash_should_unearn_from(String string) {

	}

	// TODO
	@Then("kohlscash should unearn from both {string},{string}")
	public void kohlscash_should_unearn_from_both(String string, String string2) {

	}

	// TODO
	@Given("kohlscash is redeemed with {string},{string}")
	public void kohlscash_is_redeemed_with(String string, String string2) {

	}

	// TODO
	@Then("{string} will be deducted from customer")
	public void will_be_deducted_from_customer(String string) {

	}

}
