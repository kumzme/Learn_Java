

package Step_Defs.V2_Steps.Sprint2;


import Utilities.TRANSACTION;
import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.bson.Document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Number;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Activity_First_Row;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Balance_First_row;
import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.V2.V2_Audit_Rewards.validateActivity;
import static Service_Functions.V2.V2_Audit_Rewards.validateBalance;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static org.junit.Assert.assertNull;

public class LPF_1359_AuditToConsumeVoidMessages {
	protected static final Logger logger = get_Logger();

	JsonObject pass_This            = new JsonObject();
	JsonObject this_Object          = new JsonObject();
	JsonObject sale_message_Posted1 = new JsonObject();
	JsonObject sale_message_Posted2 = new JsonObject();
	JsonObject sale_message_Posted3 = new JsonObject();
	JsonObject sale_message_Posted4 = new JsonObject();
	JsonObject sale_message_Posted5 = new JsonObject();

	JsonObject return_message_Posted1 = new JsonObject();

	JsonObject sale_OMS_message_Posted =new JsonObject();

	JsonObject kafka_Object_Res_For_Sale1;
	JsonObject kafka_Object_Res_For_Sale2;
	JsonObject kafka_Object_Res_For_Sale3;
	JsonObject kafka_Object_Res_For_Sale4;
	JsonObject kafka_Object_Res_For_Sale5;

	JsonObject kafka_Object_Sale1_For_Void1;
	JsonObject kafka_Object_Sale2_For_Void2;
	JsonObject kafka_Object_Sale3_For_Void3;
	JsonObject kafka_Object_Sale4_For_Void4;
	JsonObject kafka_Object_Sale5_For_Void5;

	JsonObject kafka_Object_Sale1_For_Return1;
	JsonObject kafka_Object_Sale2_For_Return2;
	JsonObject kafka_Object_Sale3_For_Return3;

	JsonObject kafka_Object_Sale1_For_Adjustment1;
	JsonObject kafka_Object_Sale2_For_Adjustment2;
	JsonObject kafka_Object_Sale3_For_Adjustment3;

	JsonObject kafka_Object_Return1_For_Adjustment1;
	JsonObject kafka_Object_Return2_For_Adjustment2;
	JsonObject kafka_Object_Return3_For_Adjustment3;

	JsonObject kafka_Object_Void1_For_Adjustment1;
	JsonObject kafka_Object_Void2_For_Adjustment2;
	JsonObject kafka_Object_Void3_For_Adjustment3;

	JsonObject kafka_Object_OrderMessage_For_Sale1;
	JsonObject kafka_Object_fullfulmentMessage_For_Sale1;
	JsonObject kafka_Object_OMS_ReturnMessage_For_Sale1;

	Map<TRANSACTION, String> transaction_ids = new HashMap<>();
	Document                 sale2BalanceTable;
	Document                 sale1BalanceTable;

	ArrayList<String> sale1_TransactionValues;
	ArrayList<String> sale2_TransactionValues;
	ArrayList<String> sale3_TransactionValues;
	ArrayList<String> sale4_TransactionValues;
	ArrayList<String> sale5_TransactionValues;

	ArrayList<String> oderSale_Value1;
	ArrayList<String> OMSreturn_Value1;
	ArrayList<String> FullfillmentSale_Value1;

	ArrayList<String> return_Value1;
	ArrayList<String> return_Value2;
	ArrayList<String> return_Value3;

	ArrayList<String> adjustment_Values1;
	ArrayList<String> adjustment_Values2;
	ArrayList<String> adjustment_Values3;

	String randomLoyaltyID;
	String Or_No;

	// Sale1
	@Given("^Audit DB has a sale1 \"([^\"]*)\" transaction for a Loyalty ID$")
	public void sale1MessageWithValidLoyaltyIDShouldBeThereInMKTG_SALETopic(String sale1_payload) throws Throwable {
		randomLoyaltyID = generateLoyaltyIdRandom();
		this_Object.addProperty(Reference_Payload, sale1_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		kafka_Object_Res_For_Sale1 = Post_Sales(this_Object);
		sale1_TransactionValues = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale1);
		sale_message_Posted1 = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_Res_For_Sale1);
	}

	// Sale2
	@And("^Audit DB has a sale2 \"([^\"]*)\" transaction for a Loyalty ID$")
	public void sale2MessageWithValidLoyaltyIDShouldBeThereInMKTG_SALETopic(String sale2_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, sale2_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		kafka_Object_Res_For_Sale2 = Post_Sales(this_Object);
		sale2_TransactionValues = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale2);
		sale_message_Posted2 = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale2  $$$$$$ " + kafka_Object_Res_For_Sale2);
	}

	// Sale3
	@And("^Audit DB has a sale3 \"([^\"]*)\" transaction for a Loyalty ID$")
	public void sale3MessageWithSameValidLoyaltyIDShouldBeThereInMKTG_SALETopic(String sale3_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, sale3_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		kafka_Object_Res_For_Sale3 = Post_Sales(this_Object);
		sale3_TransactionValues = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale3);
		sale_message_Posted3 = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale3  $$$$$$ " + kafka_Object_Res_For_Sale3);
	}

	// Sale4
	@And("^Audit DB has a sale4 \"([^\"]*)\" transaction for a Loyalty ID$")
	public void sale4MessageWithSameValidLoyaltyIDShouldBeThereInMKTG_SALETopic(String sale4_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, sale4_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		kafka_Object_Res_For_Sale4 = Post_Sales(this_Object);
		sale4_TransactionValues = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale4);
		sale_message_Posted4 = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale4  $$$$$$ " + kafka_Object_Res_For_Sale4);
	}

	// Sale5
	@And("^Audit DB has a sale5 \"([^\"]*)\" transaction for a Loyalty ID$")
	public void sale5MessageWithSameValidLoyaltyIDShouldBeThereInMKTG_SALETopic(String sale5_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, sale5_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		kafka_Object_Res_For_Sale5 = Post_Sales(this_Object);
		sale5_TransactionValues = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale5);
		sale_message_Posted5 = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale5  $$$$$$ " + kafka_Object_Res_For_Sale5);
	}

	// Return1 --> Sale1

	@Given("^Audit DB has Return1 for Sale1 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForSaleShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale1_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale1_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale1_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale1_TransactionValues.get(6));
		kafka_Object_Sale1_For_Return1 = Post_Return(this_Object);
		return_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale1_For_Return1);
		return_message_Posted1 = convert_String_To_JsonObject(
				Post_Return(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object Post_Return1  for Sale1" + kafka_Object_Sale1_For_Return1);
	}

	// Return2 -- >Sale2
	@And("^Audit DB has Return2 for Sale2 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForSale2ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale2_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale2_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale2_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale2_TransactionValues.get(6));
		kafka_Object_Sale2_For_Return2 = Post_Return(this_Object);
		return_Value2 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale2_For_Return2);
		logger.info("kafka_Object Post_Return2 For Sale2" + kafka_Object_Sale2_For_Return2);
	}

	// Return3 -- >Sale3
	@And("^Audit DB has Return3 for Sale3 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForSale3ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale3_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale3_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale3_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale3_TransactionValues.get(6));
		kafka_Object_Sale3_For_Return3 = Post_Return(this_Object);
		return_Value3 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale3_For_Return3);
		logger.info("kafka_Object Post_Return3 for Sale3" + kafka_Object_Sale3_For_Return3);
	}

	// Void1 -->Sale1
	@When("^Void1 message of this sale1 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(String void_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale1_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale1_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale1_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale1_TransactionValues.get(6));
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Sale1" + kafka_Object_Sale1_For_Void1);
	}

	// Void2 -->Sale2
	@And("^Void2 message of this sale2 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void sale2VoidMessageForShouldBeThereInMKTG_VOID1Topic(String void_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale2_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale2_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale2_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale2_TransactionValues.get(6));
		kafka_Object_Sale2_For_Void2 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void2 for Sale2" + kafka_Object_Sale2_For_Void2);
	}

	// Void3 -->Sale3
	@And("^Void3 message of this sale3 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void sale3VoidMessageForShouldBeThereInMKTG_VOID1Topic(String void_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale3_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale3_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale3_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale3_TransactionValues.get(6));
		kafka_Object_Sale3_For_Void3 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void3 for Sale3" + kafka_Object_Sale3_For_Void3);
	}

	// Void4 -->Sal4
	@And("^Void4 message of this sale4 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void sale4VoidMessageForShouldBeThereInMKTG_VOID1Topic(String void_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale4_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale4_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale4_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale4.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale4_TransactionValues.get(6));
		kafka_Object_Sale4_For_Void4 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void3 for Sale4" + kafka_Object_Sale4_For_Void4);
	}

	// Void5 -->Sale5
	@And("^Void5 message of this sale5 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void sale5VoidMessageForShouldBeThereInMKTG_VOID1Topic(String void_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale5_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale5_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale5_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale5.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale5_TransactionValues.get(6));
		kafka_Object_Sale5_For_Void5 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void3 for Sale5" + kafka_Object_Sale5_For_Void5);
	}

	@When("^Void message of this sale transaction is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void voidMessageOfThisSaleTransactionIsDroppedIntoMKTG_VOIDTopic(String voidType) throws Throwable {
		if (voidType.contains("Sale1_Void")) {
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(voidType);
		} else if (voidType.contains("Sale2_Void")) {
			sale2VoidMessageForShouldBeThereInMKTG_VOID1Topic(voidType);
		} else if (voidType.contains("Sale3_Void")) {
			sale3VoidMessageForShouldBeThereInMKTG_VOID1Topic(voidType);
		} else if (voidType.contains("Sale4_Void")) {
			sale4VoidMessageForShouldBeThereInMKTG_VOID1Topic(voidType);
		} else if (voidType.contains("Sale5_Void")) {
			sale5VoidMessageForShouldBeThereInMKTG_VOID1Topic(voidType);
		}
	}

	// Adjustment1 for -->Sale1
	@And("^Audit DB has Adjustment1 for Sale1 \"([^\"]*)\" for the same Loyalty ID$")
	public void sale1AdjustmentMessageForShouldBeThereInMKTG_VOID1Topic(String adjustment_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, adjustment_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale1_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale1_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale1_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale1_TransactionValues.get(6));
		kafka_Object_Sale1_For_Adjustment1 = Post_Adjustment(this_Object);
		adjustment_Values1 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale1_For_Adjustment1);
		logger.info("sale_Object_Kafka_Adjustment1  " + kafka_Object_Sale1_For_Adjustment1);
	}

	// Adjustment2 for -->Sale2
	@And("^Audit DB has Adjustment2 for Sale2 \"([^\"]*)\" for the same Loyalty ID$")
	public void sale2AdjustmentMessageForShouldBeThereInMKTG_VOID1Topic(String adjustment_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, adjustment_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale2_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale2_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale2_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale2_TransactionValues.get(6));
		kafka_Object_Sale2_For_Adjustment2 = Post_Adjustment(this_Object);
		adjustment_Values2 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale2_For_Adjustment2);
		logger.info("sale_Object_Kafka_Adjustment2  " + kafka_Object_Sale2_For_Adjustment2);
	}

	// Adjustment3 for -->Sale3
	@And("^Audit DB has Adjustment3 for Sale3 \"([^\"]*)\" for the same Loyalty ID$")
	public void sale3AdjustmentMessageForShouldBeThereInMKTG_VOID1Topic(String adjustment_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, adjustment_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale3_TransactionValues.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, sale3_TransactionValues.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, sale3_TransactionValues.get(4));
		if (kafka_Object_Res_For_Sale2.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, sale3_TransactionValues.get(6));
		kafka_Object_Sale3_For_Adjustment3 = Post_Adjustment(this_Object);
		adjustment_Values3 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale3_For_Adjustment3);
		logger.info("sale_Object_Kafka_Adjustment3  " + kafka_Object_Sale3_For_Adjustment3);
	}

	@When("^\"([^\"]*)\" message void for return transaction should be there in MKTG_VOID topic$")
	public void message_void_for_return_transaction_should_be_there_in_MKTG_VOID_topic(String returnType)
			throws Throwable {
		if (returnType.contains("Return1_Void")) {
			voidMessageForReturn1ShouldBeThereInMKTG_RETURNTopic(returnType);
		} else if (returnType.contains("Return2_Void")) {
			voidMessageForReturn2ShouldBeThereInMKTG_RETURNTopic(returnType);
		} else if (returnType.contains("Return3_Void")) {
			voidMessageForReturn3ShouldBeThereInMKTG_RETURNTopic(returnType);
		}
	}

	// Void1 --> For Return1
	@And("^\"([^\"]*)\" message void1 for return1 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForReturn1ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, return_Value1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, return_Value1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, return_Value1.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, return_Value1.get(6));
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Return1" + kafka_Object_Sale1_For_Void1);
	}

	// Voi2 --> For Return2
	@And("^\"([^\"]*)\" message void2 for return2 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForReturn2ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, return_Value2.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, return_Value2.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, return_Value2.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, return_Value2.get(6));
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Return2" + kafka_Object_Sale1_For_Void1);
	}

	// Void3 --> For Return3
	@And("^\"([^\"]*)\" message void3 for return3 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForReturn3ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, return_Value3.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, return_Value3.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, return_Value3.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, return_Value3.get(6));
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Return3" + kafka_Object_Sale1_For_Void1);
	}

	// Return1 --> Adjustment1
	@And("^Audit DB has Return1 for AdjustmentSale1 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForAdjustment1ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values1.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values1.get(6));
		kafka_Object_Return1_For_Adjustment1 = Post_Return(this_Object);
		return_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_Return1_For_Adjustment1);
		logger.info("kafka_Object Adjustment1 for Return1" + kafka_Object_Return1_For_Adjustment1);
	}

	// Return2 --> Adjustment2
	@And("^Audit DB has Return2 for AdjustmentSale2 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForAdjustment2ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values2.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values2.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values2.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values2.get(6));
		kafka_Object_Return2_For_Adjustment2 = Post_Return(this_Object);
		return_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_Return2_For_Adjustment2);
		logger.info("kafka_Object Adjustment1 for Return1" + kafka_Object_Return2_For_Adjustment2);
	}

	// Return3 --> Adjustment3
	@And("^Audit DB has Return3 for AdjustmentSale3 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForAdjustment3ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values3.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values3.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values3.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values3.get(6));
		kafka_Object_Return3_For_Adjustment3 = Post_Return(this_Object);
		return_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_Return3_For_Adjustment3);
		logger.info("kafka_Object Adjustment1 for Return1" + kafka_Object_Return3_For_Adjustment3);
	}


	@When("^\"([^\"]*)\" message void for Adjustment transaction should be there in MKTG_VOID topic$")
	public void message_void_for_Adjustment_transaction_should_be_there_in_MKTG_VOID_topic(String adjustmentType)
			throws Throwable {
		if (adjustmentType.contains("Adjustment1_Void")) {
			voidMessageForAdjustment1ShouldBeThereInMKTG_VOIDopic(adjustmentType);
		} else if (adjustmentType.contains("Adjustment2_Void")) {
			voidMessageForAdjustment2ShouldBeThereInMKTG_VOIDopic(adjustmentType);
		} else if (adjustmentType.contains("Adjustment3_Void")) {
			voidMessageForAdjustment3ShouldBeThereInMKTG_VOIDopic(adjustmentType);
		}
	}

	// Adjustment1 --> For Void1
	@And("^\"([^\"]*)\" message void1 for Adjustment1 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForAdjustment1ShouldBeThereInMKTG_VOIDopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values1.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values1.get(6));
		kafka_Object_Void1_For_Adjustment1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Adjustment1  For Return3" + kafka_Object_Void1_For_Adjustment1);
	}

	// Adjustment2 --> For Void2
	@And("^\"([^\"]*)\" message void2 for Adjustment2 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForAdjustment2ShouldBeThereInMKTG_VOIDopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values2.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values2.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values2.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values2.get(6));
		kafka_Object_Void2_For_Adjustment2 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Adjustment1  For Return3" + kafka_Object_Void2_For_Adjustment2);
	}

	// Adjustment3 --> For Void3
	@And("^\"([^\"]*)\" message void3 for Adjustment3 transaction should be there in MKTG_VOID topic$")
	public void voidMessageForAdjustment3ShouldBeThereInMKTG_VOIDopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, adjustment_Values3.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, adjustment_Values3.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, adjustment_Values3.get(4));
		if (kafka_Object_Res_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, adjustment_Values3.get(6));
		kafka_Object_Void3_For_Adjustment3 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Adjustment1  For Return3" + kafka_Object_Void3_For_Adjustment3);
	}

	@Given("^Order1 create message \"([^\"]*)\"should be loaded into Audit Database$")
	public void orderCreateMessageShouldBeLoadedIntoAuditDatabase(String OrderMessage_PayLoad) throws Throwable {
		Or_No = generate_Random_Number(10);
		randomLoyaltyID = generateLoyaltyIdRandom();

		this_Object.addProperty(Reference_Payload, OrderMessage_PayLoad);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Replace_Order_No, Or_No);
		kafka_Object_OrderMessage_For_Sale1 = Post_Sales(this_Object);
		oderSale_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_OrderMessage_For_Sale1);
		sale_OMS_message_Posted = convert_String_To_JsonObject(
				Post_Sales(this_Object).get(Kafka_Message_Body).getAsString());
		logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_OrderMessage_For_Sale1);
	}

	@And("^A fulfillment1 message sale1 for \"([^\"]*)\" should be there in MKTG_SALE topic$")
	public void aFulfillmentMessageSale1ForShouldBeThereInMKTG_SALETopic(String sale1_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, sale1_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Replace_Order_No, Or_No);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, oderSale_Value1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, oderSale_Value1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, oderSale_Value1.get(4));
		if (kafka_Object_OrderMessage_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, oderSale_Value1.get(6));
		kafka_Object_fullfulmentMessage_For_Sale1 = Post_Sales(this_Object);
	}

	@Given("^Audit DB has Return1 for OMS Sale1 \"([^\"]*)\" for the same Loyalty ID$")
	public void returnMessageForOMSSaleShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, oderSale_Value1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, oderSale_Value1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, oderSale_Value1.get(4));
		if (kafka_Object_OrderMessage_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, oderSale_Value1.get(6));
		kafka_Object_OMS_ReturnMessage_For_Sale1 = Post_Return(this_Object);
		OMSreturn_Value1 = get_TransactionValues_From_SaleMessage(kafka_Object_OMS_ReturnMessage_For_Sale1);
		logger.info("kafka_Object Post_Return1  for Sale1" + kafka_Object_OMS_ReturnMessage_For_Sale1);
	}

	// Void1 --> For Return1
	@And("^\"([^\"]*)\" OMS message void1 for return1 transaction should be there in MKTG_VOID topic$")
	public void OMSvoidMessageForReturn1ShouldBeThereInMKTG_RETURNTopic(String return_payload) throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, randomLoyaltyID);
		this_Object.addProperty(Rule_Replace_Transaction_Nbr, OMSreturn_Value1.get(0));
		this_Object.addProperty(Rule_Replace_Transaction_Date, OMSreturn_Value1.get(3));
		this_Object.addProperty(Rule_Replace_Transaction_Time, OMSreturn_Value1.get(4));
		if (kafka_Object_OrderMessage_For_Sale1.toString().contains(Rule_Bar_Code))
			this_Object.addProperty(Rule_Replace_Bar_Code, OMSreturn_Value1.get(6));
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Return1" + kafka_Object_Sale1_For_Void1);
	}

	@When("^Audit listener process the void \"([^\"]*)\" message$")
	public void auditListenerProcessTheVoidMessages(int arg0) throws Throwable {

		logger.info("Audit listener process the void " + arg0 + "messages::"
					+ kafka_Object_Sale1_For_Void1.get("Kafka_Message_Offset"));

	}

	@And("^Void message for adjustment transaction should be there in MKTG_VOID topic$")
	public void voidMessageForAdjustmentTransactionShouldBeThereInMKTG_VOIDTopic() throws Throwable {
		logger.info("Void message for adjustment transaction should be there in MKTG_VOID topic:"
					+ kafka_Object_Sale1_For_Void1.get("Kafka_Message_Offset"));
	}

	@And("^Void message is processed by Audit Listener application$")
	public void voidMessageIsProcessedByAuditListenerApplication() throws Throwable {
		logger.info("Void message is processed by Audit Listener application");
	}

	@Then("^Activity  table is updated \"([^\"]*)\"$")
	public void activityTableIsUpdated(String validationKey) throws Throwable {
		JsonObject actual   = get_Rewards_Activity_First_Row(randomLoyaltyID);
		JsonObject expected = consolidated_Data.get(validationKey + "_Sale").getAsJsonObject();
		if (validationKey.contains("Sale1"))
			validateActivity(expected, actual, sale_message_Posted1);
		else if (validationKey.contains("Sale2")) {
			validateActivity(expected, actual, sale_message_Posted2);
		} else if (validationKey.contains("Sale3")) {
			validateActivity(expected, actual, sale_message_Posted3);
		} else if (validationKey.contains("Sale4")) {
			validateActivity(expected, actual, sale_message_Posted4);
		} else if (validationKey.contains("Sale5")) {
			validateActivity(expected, actual, sale_message_Posted5);
		}
	}

	@And("^Balance  table is updated with updated balance \"([^\"]*)\"$")
	public void balanceTableIsUpdatedWithUpdatedBalance(String validationKey) throws Throwable {
		JsonObject actual   = get_Rewards_Balance_First_row(randomLoyaltyID);
		JsonObject expected = consolidated_Data.get(validationKey + "_Balance").getAsJsonObject();
		validateBalance(expected, actual);

	}

	@Then("^Activity  table for return is updated \"([^\"]*)\"$")
	public void activity_table_for_return_is_updated(String validationKey) throws Exception {
		JsonObject actual   = get_Rewards_Activity_First_Row(randomLoyaltyID);
		JsonObject expected = consolidated_Data.get(validationKey + "_Sale").getAsJsonObject();
		if (validationKey.contains("return1"))
			validateActivity(expected, actual, sale_message_Posted1);
		else if (validationKey.contains("return2")) {
			validateActivity(expected, actual, sale_message_Posted2);
		} else if (validationKey.contains("return3")) {
			validateActivity(expected, actual, sale_message_Posted3);
		} else if (validationKey.contains("AdjustmentSale1")) {
			validateActivity(expected, actual, sale_message_Posted1);
		} else if (validationKey.contains("AdjustmentSale2")) {
			validateActivity(expected, actual, sale_message_Posted2);
		} else if (validationKey.contains("AdjustmentSale3")) {
			validateActivity(expected, actual, sale_message_Posted3);
		} else if (validationKey.contains("OMSSale1")) {
			validateActivity(expected, actual, sale_OMS_message_Posted);
		}

	}

	@Then("^Activity  table should not be updated \"([^\"]*)\"$")
	public void activityTtableSshouldNotBeUpdated(String validationKey) throws Throwable {
		assertNull("Activity table is", get_Rewards_Activity_First_Row(randomLoyaltyID));

	}

	@And("^Balance  table should not be updated balance \"([^\"]*)\"$")
	public void balanceTableShouldNotBeUpdatedBalance(String validationKey) throws Throwable {
		assertNull("Activity table is", get_Rewards_Balance_First_row(randomLoyaltyID));

	}

	@Given("Audit listener process the void message for return,sale,adjustemt \"([^\"]*)\"$")
	public void audit_listener_process_the_void_message_for_return_sale_adjustemt(String type) throws Exception {
		JsonObject actual   = get_Rewards_Activity_First_Row(randomLoyaltyID);
		JsonObject expected = consolidated_Data.get(type).getAsJsonObject();
		if(type.contains("Sale")){
			validateActivity(expected, actual, sale_message_Posted1);
		} else if(type.contains("Return")) {
			validateActivity(expected, actual, sale_message_Posted1);
		} else if(type.contains("Adjustment")) {
			validateActivity(expected, actual, sale_message_Posted1);
		}
	}

	@Then("the Void message will be filtered by audit listener app")
	public void the_Void_message_will_be_filtered_by_audit_listener_app() {
		logger.info("Audit listener process the void  messages::"
					+ kafka_Object_Sale1_For_Void1.get("Kafka_Message_Offset"));
	}

	@When("^Void1 message of this sale1 transaction is dropped into \"([^\"]*)\" MKTG_VOID topic Negative$")
	public void voidMessageOfThisSaleTransactionIsDroppedIntoMKTG_VOIDTopicNegative(String void_payload)
			throws Throwable {
		this_Object.addProperty(Reference_Payload, void_payload);
		kafka_Object_Sale1_For_Void1 = Post_Void(this_Object);
		logger.info("sale_Object_Kafka_Void1  For Sale1" + kafka_Object_Sale1_For_Void1);
	}

	@Given("^Audit DB has a sale \"([^\"]*)\" transaction for a Loyalty ID$")
	public void audit_DB_has_a_sale_transaction_for_a_Loyalty_ID(String type) throws Throwable  {
		if(type.contains("Sale1")){
			sale1MessageWithValidLoyaltyIDShouldBeThereInMKTG_SALETopic(type);
		} else if(type.contains("Return1")){
			returnMessageForSaleShouldBeThereInMKTG_RETURNTopic(type);
		} else if(type.contains("Adjustment1")){
			sale1AdjustmentMessageForShouldBeThereInMKTG_VOID1Topic(type);
		}

	}

	@Given("^Void message of this sale transaction dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void void_message_of_this_sale_transaction_dropped_into_MKTG_VOID_topic(String type)throws Throwable {
		if(type.contains("Sale1_Void1")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		} else if(type.contains("Sale1_Return1_Void1")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		} else if(type.contains("Sale1_Adjustment1_Void1")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		}
	}

	@Given("^Void message of this sale transactions is dropped into \"([^\"]*)\" MKTG_VOID topic$")
	public void void_message_of_this_sale_transactions_is_dropped_into_MKTG_VOID_topic(String type)throws Throwable {
		if(type.contains("Sale1_Void2")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		} else if(type.contains("Sale1_Return1_Void2")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		} else if(type.contains("Sale1_Adjustment1_Void2")){
			void1MessageOfThisSale1TransactionIsDroppedIntoMKTG_VOIDTopic(type);
		}
	}

	@When("^\"([^\"]*)\" message void1 for return1 transaction should be there in MKTG_VOID topic Negative$")
	public void messageVoidForReturnTransactionShouldBeThereInMKTG_VOIDTopicNegative(String return_payload)
			throws Throwable {
		this_Object.addProperty(Reference_Payload, return_payload);
		kafka_Object_Sale2_For_Return2 = Post_Return(this_Object);
		return_Value2 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale2_For_Return2);
		logger.info("kafka_Object Post_Return2 For Sale2" + kafka_Object_Sale2_For_Return2);
	}

	@When("^\"([^\"]*)\" message void1 for Adjustment1 transaction should be there in MKTG_VOID topic Negative$")
	public void messageVoidForAdjustmentTransactionShouldBeThereInMKTG_VOIDTopicNegative(String adjustment_payload)
			throws Throwable {
		this_Object.addProperty(Reference_Payload, adjustment_payload);
		kafka_Object_Sale1_For_Adjustment1 = Post_Adjustment(this_Object);
		adjustment_Values1 = get_TransactionValues_From_SaleMessage(kafka_Object_Sale1_For_Adjustment1);
		logger.info("sale_Object_Kafka_Adjustment1  " + kafka_Object_Sale1_For_Adjustment1);
	}
}
