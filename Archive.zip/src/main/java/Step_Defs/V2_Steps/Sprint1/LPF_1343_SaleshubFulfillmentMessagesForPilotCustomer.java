package Step_Defs.V2_Steps.Sprint1;

import Utilities.TRANSACTION;
import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.bson.Document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Number;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.V2.V2_Audit_Rewards.validateActivityTable;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static Utilities.UtilConstants_Data_Rules_Reference.Total_Loyalty_Ids_Needed;
import static org.junit.Assert.*;


public class LPF_1343_SaleshubFulfillmentMessagesForPilotCustomer {

    protected static final Logger logger = get_Logger();
    JsonObject               pass_This         = new JsonObject();
    JsonObject               this_Object       = new JsonObject();
    JsonObject               dynamicValidation = new JsonObject();
    JsonObject               kafka_Object_Res_For_Sale1;
    JsonObject               kafka_Object_Res_For_Sale2;
    JsonObject               sale1BalanceTable;
    JsonObject               sale2BalanceTable;
    /*@Team:: Deprecated - Pls remove - Instead use a JsonObject with scenario naming*/
    Map<TRANSACTION, String> transaction_ids   = new HashMap<>();
    /*@Team:: Deprecated - Pls remove - Instead use a JsonObject with scenario naming*/
    private String Or_No           = generate_Random_Number(10);
    private String randomLoyaltyID = generateLoyaltyIdRandom();

    @Given("Audit listener Pod should be up and running")
    public void auditListenerPodShouldBeUpAndRunning() throws Throwable {
    }

    @And("Kafka server should be up and running")
    public void kafkaServerShouldBeUpAndRunning() throws Throwable {

    }

    @Given("Create a Loyalty of scenario for Sale of {string}")
    public void createALoyaltyOfScenarioForSaleOf(String total_Sales) throws Throwable {
        pass_This.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
        pass_This.addProperty(Total_Loyalty_Ids_Needed, total_Sales);
        this_Object.addProperty("Generic_Loyalty_Id_0", randomLoyaltyID);
    }

    @Given("Order create message {string}should be loaded into Audit Database")
    public void orderCreateMessageShouldBeLoadedIntoAuditDatabase(String OrderMessage_PayLoad) throws Throwable {
        this_Object.addProperty(Reference_Payload, OrderMessage_PayLoad + "_Order_01");
        this_Object.addProperty("Replace_Loyalty_Id", randomLoyaltyID);
        this_Object.addProperty("Replace_Order_No", Or_No);
        kafka_Object_Res_For_Sale1 = Post_Sales(this_Object);

        transaction_ids.put(TRANSACTION.SALE1, get_TransactionId_From_SaleMessage(kafka_Object_Res_For_Sale1));
        Thread.sleep(5000);
        logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_Res_For_Sale1);
    }

    @Given("Order create message2 {string}should be loaded into Audit Database")
    public void orderCreateMessage2ShouldBeLoadedIntoAuditDatabase(String OrderMessage_PayLoad) throws Throwable {
        this_Object.addProperty(Reference_Payload, OrderMessage_PayLoad + "_Order_02");
        this_Object.addProperty("Replace_Loyalty_Id", randomLoyaltyID);
        this_Object.addProperty("Replace_Order_No", Or_No);
        kafka_Object_Res_For_Sale2 = Post_Sales(this_Object);
        transaction_ids.put(TRANSACTION.SALE1, get_TransactionId_From_SaleMessage(kafka_Object_Res_For_Sale2));
        Thread.sleep(5000);
        logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_Res_For_Sale2);
    }

    @And("A fulfillment message sale1 for {string} should be there in MKTG_SALE topic")
    public void aFulfillmentMessageSale1ForShouldBeThereInMKTG_SALETopic(String sale1_payload) throws Throwable {
        this_Object.addProperty(Reference_Payload, sale1_payload + "_Sale_01");
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        this_Object.addProperty("Replace_Order_No", Or_No);
        kafka_Object_Res_For_Sale1 = Post_Sales(this_Object);
        transaction_ids.put(TRANSACTION.SALE1, get_TransactionId_From_SaleMessage(kafka_Object_Res_For_Sale1));
        Thread.sleep(5000);
        sale1BalanceTable = get_Rewards_Balance_First_row(this_Object.get("Generic_Loyalty_Id_0").getAsString());
    }

    @And("A fulfillment message sale2 for {string} should be there in MKTG_SALE topic")
    public void aFulfillmentMessageSale2ForShouldBeThereInMKTG_SALETopic(String sale2_payload) throws Throwable {
        this_Object.addProperty(Reference_Payload, sale2_payload + "_Sale_02");
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object_Res_For_Sale2 = Post_Sales(this_Object);
        Thread.sleep(5000);
        transaction_ids.put(TRANSACTION.SALE2, get_TransactionId_From_SaleMessage(kafka_Object_Res_For_Sale2));
        sale2BalanceTable = get_Rewards_Balance_First_row(this_Object.get("Generic_Loyalty_Id_0").getAsString());
        logger.info("kafka_Object_Res_For_Sale2  $$$$$$ " + kafka_Object_Res_For_Sale2);
    }

    @Given("Create a Loyalty of scenario for Sale of {string} for non pilot")
    public void createALoyaltyOfScenarioForSaleOfForNonPilot(String total_Sales) throws Throwable {

        pass_This.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
        pass_This.addProperty(Total_Loyalty_Ids_Needed, total_Sales);
        this_Object.addProperty("Generic_Loyalty_Id_0", generateLoyaltyIdRandom());
    }


    @When("Audit listener process the Saleshub fulfillment message")
    public void auditListenerProcessTheSaleshubFulfillmentMessage() throws Throwable {
        logger.info("Audit listener successfully process the Saleshub fulfillment message::" + kafka_Object_Res_For_Sale1.get("Kafka_Message_Offset"));
    }

    @Then("validate fulfillment sale1 fields in Activity table with {string}")
    public void validateFulfillmentSaleFieldsInActivityTableWith(String validationKeyName) throws Throwable {
        dynamicValidation.addProperty("loyaltyId", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        dynamicValidation.addProperty("trnsName", "Sale_01");

        Document actual = get_Rewards_Activity_Rows(dynamicValidation);
        this_Object.addProperty("Sale01_Activity_ID", actual.get("_id").toString());

        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_01_Acticity"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_01_Acticity").getAsJsonObject();
        Document expected = Document.parse(validationData.toString());

        validateActivityTable(expected, actual, dynamicValidation);
    }

    @Then("validate fulfillment sale2 fields in Activity table with {string}")
    public void validateFulfillmentSale2FieldsInActivityTableWith(String validationKeyName) throws Throwable {
        dynamicValidation.addProperty("loyaltyId", this_Object.get("Generic_Loyalty_Id_0").getAsString());

        dynamicValidation.addProperty("trnsName", "Sale_02");

        Document actual = get_Rewards_Activity_Rows(dynamicValidation);
        this_Object.addProperty("Sale02_Activity_ID", actual.get("_id").toString());
        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_02_Acticity"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_02_Acticity").getAsJsonObject();
        Document expected = Document.parse(validationData.toString());
        validateActivityTable(expected, actual, dynamicValidation);
    }


    @And("validate fulfillment sale1 fields in Balance table with {string}")
    public void validateFulfillmentSaleFieldsInBalanceTableWith(String validationKeyName) throws Throwable {
        JsonObject actual         = sale1BalanceTable.get("First_Row").getAsJsonObject();
        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_01_Balance"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_01_Balance").getAsJsonObject();
        assertNotNull("_ID Value is:", actual.get("_id"));
        assertEquals("Activity_ID Value is:", actual.get("activityId").getAsString(), this_Object.get("Sale01_Activity_ID").getAsString());
        assertEquals("loyaltyId value is:", actual.get("loyaltyId").getAsString(), this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertEquals("updatedBalance value is:", validationData.get("updatedBalance").getAsString(), actual.get("updatedBalance").toString());
    }

    @And("validate fulfillment sale2 fields in Balance table with {string}")
    public void validateFulfillmentSal2FieldsInBalanceTableWith(String validationKeyName) throws Throwable {
        JsonObject actual         = sale2BalanceTable.get("First_Row").getAsJsonObject();
        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_02_Balance"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_02_Balance").getAsJsonObject();
        assertNotNull("_ID Value is:", actual.get("_id"));
        assertEquals("Activity_ID Value is:", actual.get("activityId").getAsString(), this_Object.get("Sale02_Activity_ID").getAsString());
        assertEquals("loyaltyId value is:", actual.get("loyaltyId").getAsString(), this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertEquals("updatedBalance value is:", validationData.get("updatedBalance").getAsString(), actual.get("updatedBalance").toString());
    }

    @Then("transaction-details should not be loaded in Audit database")
    public void transactionDetailsShouldNotBeLoadedInAuditDatabase() throws Throwable {
        ArrayList<String> list   = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale1);
        JsonObject        actual = get_Rewards_Activity_With_MessageId_First(list.get(5));
        assertTrue("Activity table is", actual.entrySet().size() == 0);
    }

    @And("barcode-table should be updated as null in Audit database")
    public void barcodeTableShouldBeUpdatedAsNullInAuditDatabase() throws Throwable {
        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() == 0);
    }

    @Then("event kohls cash earned should not be loaded in Audit database")
    public void eventKohlsCashEarnedShouldNotBeLoadedInAuditDatabase() throws Throwable {
        ArrayList<String> list   = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale1);
        JsonObject        actual = get_Rewards_Activity_With_MessageId_First(list.get(5));
        assertNull("Activity table is", actual.entrySet().size() == 0);
    }
}
