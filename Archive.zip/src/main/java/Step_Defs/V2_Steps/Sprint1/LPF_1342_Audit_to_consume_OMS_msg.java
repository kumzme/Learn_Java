package Step_Defs.V2_Steps.Sprint1;

import com.google.gson.JsonObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.bson.Document;
import org.junit.Assert;

import java.util.ArrayList;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Random_Number;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Functional_Utilities.V2_Sale_Functionalities.get_TransactionValues_From_SaleMessage;
import static Service_Functions.V2.V2_Audit_Rewards.validateActivityTable;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static Utilities.UtilConstants_Data_Rules_Reference.Total_Loyalty_Ids_Needed;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LPF_1342_Audit_to_consume_OMS_msg {

    protected static final Logger logger = get_Logger();
    JsonObject this_Object       = new JsonObject();
    JsonObject passing_Object    = new JsonObject();
    JsonObject kafka_Object      = new JsonObject();
    JsonObject kafka_Object1     = new JsonObject();
    JsonObject kafka_Object2     = new JsonObject();
    JsonObject dynamicValidation = new JsonObject();
    private String loyaltyId;
    private String Or_No;

    //Scenario 1
    @Given("A sale message should be there in MKTG_SALE topic for {string} for {string}")
    public void a_sale_message_should_be_there_in_MKTG_SALE_topic(String Test_Name, String sale) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {sale};
        /*Todo .. check what is this*/
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }

    // Scenario 1,5,6,10
    @When("Audit listener process the OMS order message for {string}")
    public void audit_listener_process_the_OMS_order_message(String sale) throws Exception {

        if (sale.equals("Sale_01"))
            logger.info("Message successfully send with Offset::" + kafka_Object1.get("Kafka_Message_Offset"));
        else
            if (sale.equals("Sale_02"))
                logger.info("Message successfully send with Offset::" + kafka_Object1.get("Kafka_Message_Offset"));

    }

    @And("activity_id,loyalty_id,updated_balance,created_on should be updated in balance Table of Audit database with {string}")
    public void validate_the_balance_table(String balance_Expected_values) throws Exception {
        JsonObject actual_Balance_values = get_Rewards_Balance_First_row(loyaltyId).get("First_Row").getAsJsonObject();
        JsonObject balanceValidation     = null;
        balanceValidation = consolidated_Data.get(balance_Expected_values).getAsJsonObject();

        assertEquals("UpdatedBalance is not as expected", balanceValidation.get("updatedBalance").getAsString(), actual_Balance_values.get("updatedBalance").toString());

    }

    @Then("activity_id,barcode,type,amt_applied,fully_allocated,redeemed,created_on should be updated as null in barcode table of Audit database")
    public void activity_id_barcode_type_amt_applied_fully_allocated_redeemed_created_on_in_Audit_database() throws Exception {

        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString().replaceAll("\"", ""));

        assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() == 0);

    }


    @And("activity_id,loyalty_id,transaction_store_nbr,transaction_register_nbr,transaction_nbr,activity_date,activity_time,activity_description,associated_id,,transaction_receipt_id,transaction_order_nbr,source_system_code,fulfillment,fulfillment_type,transaction_amt,everyday_kcc,everyday_nonkcc,earning_id,qualifying_amt,items,tenders,created_by,created_on should be updated in Activity table of Audit database for {string} with expected values {string}")
    public void validate_the_activity_table(String sale, String activity_Expected_values) throws Exception {

        dynamicValidation.addProperty("loyaltyId", loyaltyId);
        dynamicValidation.addProperty("trnsName", sale);
        Document actual_Activity_values = null;
        Document actual_Balance_values  = null;
        Document expected               = null;

        JsonObject balance_expectedValues = null;

        actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        actual_Balance_values = get_Rewards_Balance_Rows(loyaltyId);
        this_Object.addProperty("Sale1_Activity_ID", actual_Activity_values.get("_id").toString());

        if (actual_Activity_values != null) {
            JsonObject activity_expectedValues = null;
            activity_expectedValues = consolidated_Data.get(activity_Expected_values).getAsJsonObject();

		/*	JsonObject balance_expectedValues = null;
			balance_expectedValues = consolidated_Data.get(BalanceSale2_Expected_values).getAsJsonObject();
		*/
            JsonObject validationData = null;
            if (consolidated_Data.has(activity_Expected_values))
                validationData = activity_expectedValues;
            expected = Document.parse(validationData.toString());
            //	validationData = activity_expectedValues;
            //validationData = consolidated_Data.get(activity_Expected_values).getAsJsonObject();


            validateActivityTable(expected, actual_Activity_values, dynamicValidation);
            if (actual_Balance_values != null) {
                assertEquals("ActivityId is not matching with Balance table activityId",
                             actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());
            } else {

            }
        } else
            Assert.fail("Actual response from Activity Table is getting Null");

    }

    //Scenario 2:
    @Given("A sale message with qualified amount greater than $50 should be there in MKTG_SALE topic for {string} for {string}")
    public void a_sale_message_with_qualified_amount_greater_than_50_dollar_should_be_there_in_MKTG_SALE_topic(String Test_Name, String sale) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {sale};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }

    @Then("Event kohls cash earned should not be loaded in the Audit database")
    public void then_event_kohls_cash_earned_should_not_be_loaded_in_Audit_database() throws Exception {
        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString());

        assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() == 0);

    }


    // Scenario 3 (Non Pilot)
    @Then("transaction details should not be loaded in Audit db")
    public void transaction_details_should_not_be_loaded_in_Audit_database() throws Exception {

        ArrayList<String> list   = get_TransactionValues_From_SaleMessage(kafka_Object1);
        JsonObject        actual = get_Rewards_Activity_With_MessageId_First(list.get(5));
        assertTrue("Even though customer is Non Pilot, Activity table is loaded with info: ", actual.entrySet().size() == 0);

    }

    //Scenario 4
    @Then("transaction details should not be loaded in Audit database for sale without loyaltyId")
    public void transaction_details_should_not_be_loaded_in_Audit_database_without_loyaltyId() throws Exception {

        ArrayList<String> list   = get_TransactionValues_From_SaleMessage(kafka_Object1);
        JsonObject        actual = get_Rewards_Activity_With_MessageId_First(list.get(5));
        assertTrue("Activity table is", actual.entrySet().size() == 0);

    }

    //Scenario 5
    @Given("A sale message with {string} items should be there in MKTG_SALE topic for {string} and {string}")
    public void a_sale_message_with_x_items_should_be_there_in_MKTG_SALE_topic(String skucount, String Test_Name, String Sale) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {Sale};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }

    // Scenario 6
    @Given("A sale message with {string} payment should be there in MKTG_SALE topic for {string} for {string}")
    public void a_sale_message_with_tenderType_payment_should_be_there_in_MKTG_SALE_topic(String tenderType, String Test_Name, String Sale) throws Exception {


        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);

        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {Sale};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }

    @And("barcode table should be updated as null in Audit database for {string}")
    public void barcode_table_should_be_updated_as_null_in_Audit_database(String sale1) throws Exception {

        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString().replaceAll("\"", ""));

        Assert.assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() == 0);

    }

    //Scenario 8
    @Given("{string} message with {string} should be there in MKTG_SALE topic for {string}")
    public void sale1_sale2_message_with_tender_type_should_be_there_in_MKTG_SALE_topic(String Sale, String tenderType, String Test_Name) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);

        if (Sale.equals("Sale_01")) {
            loyaltyId = generateLoyaltyIdRandom();

        }
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);

        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        //	String[] args = { Sale };

        String sale_Name = Test_Name + "_" + Sale;
        this_Object.addProperty(Reference_Payload, sale_Name);
        Or_No = generate_Random_Number(10);
        this_Object.addProperty("Replace_Order_No", Or_No);
        if (Sale.equals("Sale_01")) {
            kafka_Object1 = Post_Sales(this_Object);

            logger.info("sale1_Message is $$$ :" + kafka_Object1);
            logger.info(Sale + " is done...");

            //
        } else
            if (Sale.equals("Sale_02")) {
                kafka_Object2 = Post_Sales(this_Object);
                logger.info("sale2_Message is $$$ :" + kafka_Object2);
                logger.info(Sale + " is done...");

                //
            }

    }


    //Scenario 5
/*	@And("message_detail Table,balance Table,Activity table should be updated as expected in Audit database for {string} with {string} and {string}")
	public void validate_the_message_balance_activity_table(String sale, String balance_Expected_values, String activity_Expected_values) throws Exception
	{
		
		dynamicValidation.addProperty("loyaltyId", loyaltyId);				
		dynamicValidation.addProperty("trnsName", sale);

		Document actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        Document actual_Balance_values = get_Rewards_Balance_Rows(loyaltyId);
		

		JsonObject activityValidation = null;
		JsonObject balanceValidation = null;
		activityValidation = consolidated_Data.get(activity_Expected_values).getAsJsonObject();

		
		assertEquals("everydayNonkcc is not as expected",
				activityValidation.get("everydayNonkcc").getAsString(),
				actual_Activity_values.get("everydayNonkcc").toString());

		assertEquals("qualifiedAmt is not as expected",
				activityValidation.get("qualifyingAmt").getAsString(),
				actual_Activity_values.get("qualifyingAmt").toString());

		assertEquals("everydayKcc is not as expected",
				activityValidation.get("everydayKcc").getAsString(),
				actual_Activity_values.get("everydayKcc").toString());


		assertEquals("ActivityId is not matching with Balance table activityId",
				actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());
		
		balanceValidation = consolidated_Data.get(balance_Expected_values).getAsJsonObject();

		assertEquals("UpdatedBalance is not as expected",
				balanceValidation.get("updatedBalance").getAsString(),
				actual_Balance_values.get("updatedBalance").toString());


	}
*/
	

	
/*	//Scenario 8
	@And("Sale 2 message with {string} should be there in MKTG_SALE topic for {string} and {string}")
	public void sale2_message_with_tender_type_should_be_there_in_MKTG_SALE_topic(String tenderType, String Sale2, String Test_Name) throws Exception {

		passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
		//loyaltyId = generateLoyaltyIdRandom();
		this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
		this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
		
		String[] args = { Sale2 };
		for (int i = 0; i < 1; i++) {
			String sale_Name = Test_Name + "_" + args[i];
			this_Object.addProperty(Reference_Payload, sale_Name);
			Or_No = generate_Random_Number(10);
			this_Object.addProperty("Replace_Order_No", Or_No);
			if (i == 0) {
				kafka_Object1 = Post_Sales(this_Object);
			}
			if (i == 1) {
				kafka_Object2 = Post_Sales(this_Object);
			}

			logger.info("sale_Message is $$$ :" + kafka_Object);
			logger.info("Sale" + (i + 1) + "is done...");
		}

	}*/

    //scenario 8
    @When("Audit listener process the {string} and {string} messages")
    public void audit_listener_process_the_sale1_and_sale2_messages(String Sale1, String Sale2) throws Exception {

        if (Sale1.equals("Sale_01"))
            logger.info("For Sale_01 Message successfully send with Offset::" + kafka_Object1.get("Kafka_Message_Offset"));
        else
            if (Sale2.equals("Sale_02"))
                logger.info("For Sale_02 Message successfully send with Offset::" + kafka_Object1.get("Kafka_Message_Offset"));

    }


    @And("message_detail Table,balance Table,Activity table should be updated as expected in Audit database for {string} with {string}")
    public void message_detail_Table_balance_Table_Activity_table_should_be_updated_as_expected_in_Audit_database_for_sale1(String sale1, String ActivitySale1_Expected_values) throws Exception {


        dynamicValidation.addProperty("loyaltyId", loyaltyId);

        dynamicValidation.addProperty("trnsName", sale1);
        Document actual_Activity_values = null;
        Document actual_Balance_values  = null;
        Document expected               = null;

        JsonObject balance_expectedValues = null;


        actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        actual_Balance_values = get_Rewards_Balance_Rows(loyaltyId);
        this_Object.addProperty("Sale1_Activity_ID", actual_Activity_values.get("_id").toString());


        JsonObject validationData = null;
        if (consolidated_Data.has(ActivitySale1_Expected_values))
            validationData = consolidated_Data.get(ActivitySale1_Expected_values).getAsJsonObject();
        expected = Document.parse(validationData.toString());

        validateActivityTable(expected, actual_Activity_values, dynamicValidation);
						
		/*		NOT needed will error out		
			assertEquals("ActivityId is not matching with Balance table activityId",
					actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());
		*/
    }

    @And("message_detail Table,balance Table,Activity table should be updated as expected in Audit database for {string} with {string} and {string}")
    public void message_detail_Table_balance_Table_Activity_table_should_be_updated_as_expected_in_Audit_database_for_sale2(String sale2, String ActivitySale2_Expected_values, String Balance_ExpValues) throws Exception {

        dynamicValidation.addProperty("loyaltyId", loyaltyId);
        dynamicValidation.addProperty("trnsName", sale2);
        Document actual_Activity_values = null;
        Document actual_Balance_values  = null;
        Document expected               = null;

        JsonObject balance_expectedValues = null;


        actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        actual_Balance_values = get_Rewards_Balance_Rows(loyaltyId);
        this_Object.addProperty("Sale2_Activity_ID", actual_Activity_values.get("_id").toString());


        JsonObject validationData = null;
        if (consolidated_Data.has(ActivitySale2_Expected_values))
            validationData = consolidated_Data.get(ActivitySale2_Expected_values).getAsJsonObject();
        expected = Document.parse(validationData.toString());

        validateActivityTable(expected, actual_Activity_values, dynamicValidation);

        balance_expectedValues = consolidated_Data.get(Balance_ExpValues).getAsJsonObject();

        assertEquals("updatedBalance is not as expected",
                     balance_expectedValues.get("updatedBalance").getAsString(),
                     actual_Balance_values.get("updatedBalance").toString());

        assertEquals("ActivityId is not matching with Balance table activityId",
                     actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());

    }


    //Scenario 9
    @Given("Sale 1 message with {string} item should be there in MKTG_SALE topic for {string} for {string}")
    public void Sale1_message_with_sku_count1_item_should_be_there_in_MKTG_SALE_topic(String Skucount, String Test_Name, String Sale) throws Exception {
        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {Sale};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }

    @And("Sale 2 message with {string} item should be there in MKTG_SALE topic for {string} for {string}")
    public void Sale2_message_with_Sku_Count_2_item_should_be_there_in_MKTG_SALE_topic(String Skucount, String Test_Name, String Sale) throws Exception {
        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        //loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());

        String[] args = {Sale};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }


    // SCENARIO 10
    @Given("Sale 1 {string} message with {string} kohlscash should be there in MKTG_SALE topic for {string}")
    public void sale1_message_should_be_there_in_MKTG_SALE_topic(String Sale1, String kohlscash, String Test_Name) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        String[] args = {Sale1};
        //todo check this
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }


    @And("Sale 2 {string} message with {string} kohlscash should be there in MKTG_SALE topic for {string}")
    public void sale2_message_should_be_there_in_MKTG_SALE_topic(String Sale2, String kohlscash, String Test_Name) throws Exception {

        passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
        //loyaltyId = generateLoyaltyIdRandom();
        this_Object.addProperty("Generic_Loyalty_Id_0", loyaltyId);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());

        String[] args = {Sale2};
        for (int i = 0; i < 1; i++) {
            String sale_Name = Test_Name + "_" + args[i];
            this_Object.addProperty(Reference_Payload, sale_Name);
            Or_No = generate_Random_Number(10);
            this_Object.addProperty("Replace_Order_No", Or_No);
            if (i == 0) {
                kafka_Object1 = Post_Sales(this_Object);
            }
            if (i == 1) {
                kafka_Object2 = Post_Sales(this_Object);
            }

            logger.info("sale_Message is $$$ :" + kafka_Object);
            logger.info("Sale" + (i + 1) + "is done...");
        }

    }


    @Then("updated_balance column should be updated as {string} in Activity table of Audit database for {string} with {string}")
    public void updated_balance_column_should_be_updated_in_Activity_table_of_Audit_database_for_Sale1(String totalEverydayKC, String sale, String everyday_expected_values_after_sale1) throws Exception {
        JsonObject actual_Activity_values = null;
        JsonObject actual_Balance_values  = null;

        dynamicValidation.addProperty("loyaltyId", loyaltyId);
        dynamicValidation.addProperty("trnsName", sale);

        if (sale.equals("Sale_01")) {
            actual_Activity_values = get_Rewards_Activity_First_Row(loyaltyId);
            actual_Balance_values = get_Rewards_Balance_First_row(loyaltyId);
        } else
            if (sale.equals("Sale_02")) {
                /*Mahesh check this */
                /*actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);*/
                actual_Activity_values = get_Rewards_Activity_First_Row(loyaltyId);
                actual_Balance_values = get_Rewards_Balance_First_row(loyaltyId);
            }

        JsonObject expValues_after_sale1 = null;
        expValues_after_sale1 = consolidated_Data.get(everyday_expected_values_after_sale1).getAsJsonObject();


        assertEquals("everydayTotalAmt is not as expected", expValues_after_sale1.get("everydayTotalAmt").getAsString(), actual_Activity_values.get("everydayTotalAmt").toString());

        assertEquals("everydayKcc is not as expected", expValues_after_sale1.get("everydayKcc").getAsString(), actual_Activity_values.get("everydayKcc").toString());

        assertEquals("updatedBalance is not as expected", expValues_after_sale1.get("updatedBalance").getAsString(), actual_Balance_values.get("updatedBalance").toString());

        assertEquals("ActivityId is not matching with Balance table activityId", actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());

    }


    // used for Scenario 8,9 10
    @And("message_detail Table,balance Table,Activity table should be updated as expected in Audit database for both {string} and {string} with {string} and {string} and {string}")
    public void message_detail_Table_balance_Table_Activity_table_should_be_updated_as_expected_in_Audit_database_for_both_sales(String sale1, String sale2, String ActivitySale1_Expected_values, String ActivitySale2_Expected_values, String Balance_ExpValues) throws Exception {

        dynamicValidation.addProperty("loyaltyId", loyaltyId);
        dynamicValidation.addProperty("trnsName", sale1);
        Document   actual_Activity_values = null;
        JsonObject actual_Balance_values  = null;
        Document   expected               = null;

        JsonObject balance_expectedValues = null;


        actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        actual_Balance_values = get_Rewards_Balance_First_row(loyaltyId);
        this_Object.addProperty("Sale1_Activity_ID", actual_Activity_values.get("_id").toString());


        JsonObject activity_expectedValues = null;
        activity_expectedValues = consolidated_Data.get(ActivitySale1_Expected_values).getAsJsonObject();
			
		/*	JsonObject balance_expectedValues = null;
			balance_expectedValues = consolidated_Data.get(BalanceSale2_Expected_values).getAsJsonObject();
		*/
        JsonObject validationData = null;
        if (consolidated_Data.has(ActivitySale1_Expected_values))
            validationData = consolidated_Data.get(ActivitySale1_Expected_values).getAsJsonObject();
        expected = Document.parse(validationData.toString());

        validateActivityTable(expected, actual_Activity_values, dynamicValidation);


        // Sale 2 validation starts
        dynamicValidation.addProperty("loyaltyId", loyaltyId);
        dynamicValidation.addProperty("trnsName", sale2);

        actual_Activity_values = get_Rewards_Activity_Rows(dynamicValidation);
        //     actual_Balance_values = get_Rewards_Balance_Rows(loyaltyId);
        this_Object.addProperty("Sale2_Activity_ID", actual_Activity_values.get("_id").toString());


        activity_expectedValues = consolidated_Data.get(ActivitySale2_Expected_values).getAsJsonObject();
        balance_expectedValues = consolidated_Data.get(Balance_ExpValues).getAsJsonObject();


        if (consolidated_Data.has(ActivitySale2_Expected_values))
            validationData = consolidated_Data.get(ActivitySale2_Expected_values).getAsJsonObject();
        expected = Document.parse(validationData.toString());

        validateActivityTable(expected, actual_Activity_values, dynamicValidation);


        assertEquals("updatedBalance is not as expected", balance_expectedValues.get("updatedBalance").getAsString(), actual_Balance_values.get("updatedBalance").toString());

        assertEquals("ActivityId is not matching with Balance table activityId",
                     actual_Activity_values.get("_id").toString(), actual_Balance_values.get("activityId").toString());


    }

    // used for Scenario 8,9, 10
    @Then("barcode table should be updated as null in Audit database for both {string} and {string}")
    public void barcode_table_should_be_updated_as_null_in_Audit_database(String sale1, String sale2) throws Exception {

        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString());

        assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() == 0);

    }


}
