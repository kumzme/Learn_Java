package Step_Defs.V2_Steps.Sprint1;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.ArrayList;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Balance_First_row;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Loyalty_Balance_From_DB;
import static Functional_Utilities.V2_Functional_Utilities.create_New_Loyalty_ID;
import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.V2.V2_Audit_Balance_Functions.get_Audit_Balance;
import static Service_Functions.V2.V2_Audit_Balance_Functions.get_Balance_1348;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants.Kafka_Message_Body;
import static Utilities.UtilConstants.Response_Code;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class LPF_1348_Balance_Service {

    public String loyaltyId;
    JsonObject        this_Object          = new JsonObject();
    JsonObject        negative_this_Object = new JsonObject();
    JsonObject        sale_Object_Kafka    = new JsonObject();
    JsonObject        sale_Object_Kafka1   = new JsonObject();
    JsonObject        sale_Object_Kafka2   = new JsonObject();
    JsonObject        sale_Object_Kafka3   = new JsonObject();
    JsonObject        sale_Object_Kafka4   = new JsonObject();
    JsonObject        service_body         = new JsonObject();
    JsonObject        result_Object        = new JsonObject();
    ArrayList<String> sale_Values1;
    ArrayList<String> sale_Values2;
    ArrayList<String> return_Values1;
    ArrayList<String> adjustment_Values1;

    String db_Balance;
    String service_Balance;

    JsonObject service_body_negative, loyalty_Id_Data_For_What = new JsonObject();

    protected static final Logger logger = get_Logger();



    @Given("I load the loyalty Id's for later use")
    public void i_load_the_loyalty_Id_s_for_later_use() throws Exception {

    }


    /*Scenario - 1*/
    @Given("Transaction details should be loaded into Audit database for the valid loyalty Id with updated balance value as {string} and payload name as {string}")
    public void transaction_details_should_be_loaded_into_Audit_database_for_the_valid_loyalty_Id_with_updated_balance_value_as_and_input_value_as(String exp_Balance, String payload_reference) throws Exception {

        this_Object.addProperty(Reference_Payload, payload_reference);
        sale_Object_Kafka = Post_Sales(this_Object);
        JsonObject message_Posted = convert_String_To_JsonObject(sale_Object_Kafka.get(Kafka_Message_Body).getAsString());
        loyaltyId = message_Posted.get("messageBody").getAsJsonObject().get("loyaltyId").getAsString();

    }


    @When("Audit Reward Tracker Balance service is hit with valid loyalty ID,Valid headers")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_valid_loyalty_ID_Valid_headers() throws Exception {

        result_Object = get_Audit_Balance(loyaltyId);

        JsonObject service_body = result_Object.get("Response_Body").getAsJsonObject();
        service_Balance = service_body.get("totalEarnTracker").getAsString();

        db_Balance = get_Rewards_Loyalty_Balance_From_DB(loyaltyId).get("updatedBalance").getAsString();
        /* Todo*/
        // double db_Balance = get_Rewards_Loyalty_Balance_From_DB(loyaltyId).get("updatedBalance").getAsDouble();
        logger.info("totalEarnTracker from db is $$$ :" + db_Balance);


    }

    @Then("Audit Reward Tracker Balance service should provide totalEarnTracker value as {string} in the response")
    public void audit_Reward_Tracker_Balance_service_should_provide_totalEarnTracker_value_as_in_the_response(String exp_Balance) {


        assertEquals("Incorrect Balance", exp_Balance, db_Balance);
        assertEquals("Incorrect Balance", service_Balance, db_Balance);
    }

    @Then("the totalEarnTracker value should be in numeric")
    public void the_totalEarnTracker_value_should_be_in_numeric() {

        logger.info("___");
    }


    /*Scenario - 2*/
    /*Stored _ 01*/
    @Given("All {string} details should be loaded into Audit database for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeTransactionTypesinKafka(String transType, String payload1, String payload2, String payload3, String payload4) throws Exception {
        logger.info("running LPF1348");
        logger.info("payload1 " + payload1);
        logger.info("payload2 " + payload2);

        loyaltyId = create_New_Loyalty_ID();

        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);
        
        sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka1);


        if (sale_Object_Kafka1.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values1.get(6));

        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);


        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();
        logger.info("db_Balance " + db_Balance);

    }

    @Given("All {string} details should be loaded into Audit database for sale and void for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeSaleVoidTransactionTypesinKafka(String transType, String payload1, String payload2,
                                                     String payload3, String payload4) throws Exception {

        loyaltyId = create_New_Loyalty_ID();

        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);
        sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka1);

        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);
        sale_Values2 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka2);


        this_Object.addProperty(Reference_Payload, payload3);

        /*@Rmove*/
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty(Rule_Replace_Transaction_Nbr, sale_Values1.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values1.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (sale_Object_Kafka1.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values1.get(6));

        sale_Object_Kafka3 = Post_Void(this_Object);
        logger.info("sale_Object_Kafka 111  " + sale_Object_Kafka3);


        this_Object.addProperty(Reference_Payload, payload3);

        this_Object.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values2.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (sale_Object_Kafka2.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values2.get(6));
        logger.info("sale_Object_Kafka 222  " + sale_Object_Kafka4);
        sale_Object_Kafka4 = Post_Void(this_Object);
        logger.info("sale_Object_Kafka 222###  " + sale_Object_Kafka4);


        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();
        logger.info("db_Balance " + db_Balance);


    }

    @Given("All {string} details should be loaded into Audit database for sale and return for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeSaleReturnTransactionTypesinKafka(String transType, String payload1, String payload2,
                                                       String payload3, String payload4) throws Exception {

        logger.info("running LPF1348");
        logger.info("payload1 " + payload1);
        logger.info("payload2 " + payload2);

        loyaltyId = create_New_Loyalty_ID();


        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);
        sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka1);


        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);
        sale_Values2 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka2);


        this_Object.addProperty(Reference_Payload, payload3);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("Replace_transactionNbr", sale_Values1.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values1.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (sale_Object_Kafka1.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values1.get(6));

        sale_Object_Kafka3 = Post_Return(this_Object);
        logger.info("sale_Object_Kafka 111  " + sale_Object_Kafka3);


        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();
        logger.info("db_Balance " + db_Balance);


    }

    @Given("All {string} details should be loaded into Audit database for sale and adjustment for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeSaleAdjustmentTransactionTypesinKafka(String transType, String payload1, String payload2,
                                                           String payload3, String payload4) throws Exception {

        logger.info("running LPF1348");
        logger.info("payload1 " + payload1);
        logger.info("payload2 " + payload2);

        loyaltyId = create_New_Loyalty_ID();


        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);
        sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka1);


        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);
        sale_Values2 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka2);


        this_Object.addProperty(Reference_Payload, payload3);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values2.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (sale_Object_Kafka2.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values2.get(6));

        sale_Object_Kafka3 = Post_Adjustment(this_Object);
        logger.info("sale_Object_Kafka 111  " + sale_Object_Kafka3);

        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();
        logger.info("db_Balance " + db_Balance);

    }

    @Given("All {string} details should be loaded into Audit database for sale, return and void for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeSaleReturnVoidTransactionTypesinKafka(String transType, String payload1, String payload2,
                                                           String payload3, String payload4) throws Exception {

        logger.info("running LPF1348");
        logger.info("payload1 " + payload1);
        logger.info("payload2 " + payload2);

        loyaltyId = create_New_Loyalty_ID();


        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);


        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);
        sale_Values2 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka2);

        this_Object.addProperty(Reference_Payload, payload3);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values2.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (sale_Object_Kafka2.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values2.get(6));

        sale_Object_Kafka3 = Post_Return(this_Object);
        logger.info("sale_Object_Kafka Post_Return  " + sale_Object_Kafka3);

        return_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka3);

        this_Object.addProperty(Reference_Payload, payload4);

        this_Object.addProperty("Replace_transactionNbr", return_Values1.get(0));
        this_Object.addProperty("Replace_transactionDate", return_Values1.get(3));
        this_Object.addProperty("Replace_transactionTime", return_Values1.get(4));
        if (sale_Object_Kafka2.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", return_Values1.get(6));
        logger.info("sale_Object_Kafka Post_Void  " + sale_Object_Kafka4);

        sale_Object_Kafka4 = Post_Void(this_Object);
        logger.info("sale_Object_Kafka Post_Void  " + sale_Object_Kafka4);

        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();
        logger.info("db_Balance " + db_Balance);
    }


    /*@Remove - Todo Is this not needed*/
    @Given("All {string} details should be loaded into Audit database for missing transaction for the valid loyalty Id and payload name as {string},{string},{string},{string},{string}")
    public void placeMissingTransactionTypesinKafka(String transType, String payload1, String payload2, String payload3,
                                                    String payload4, String loyaltyid_Passed) throws Exception {

        logger.info("running LPF1348");

        String db_Balance_beforeSale = get_Rewards_Balance_First_row(loyaltyid_Passed).get("updatedBalance").getAsString();
        logger.info("db_Balance_beforeSale " + db_Balance_beforeSale);

        this_Object.addProperty(Reference_Payload, payload1);
        sale_Object_Kafka1 = Post_Sales(this_Object);


        this_Object.addProperty(Reference_Payload, payload1);
        sale_Object_Kafka2 = Post_Sales(this_Object);

        db_Balance = get_Rewards_Balance_First_row(loyaltyid_Passed).get("updatedBalance").getAsString();


    }

    @Given("All {string} details should be loaded into Audit database for sale, adjustment and void for the valid loyalty Id and payload name as {string},{string},{string},{string}")
    public void placeSaleAdjustmentVoidTransactionTypesinKafka(String transType, String payload1, String payload2,
                                                               String payload3, String payload4) throws Exception {

        logger.info("running LPF1348");
        logger.info("payload1 " + payload1);
        logger.info("payload2 " + payload2);

        loyaltyId = create_New_Loyalty_ID();


        this_Object.addProperty(Reference_Payload, payload1);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka1 = Post_Sales(this_Object);
        sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka1);
        logger.info("sale_Values1 ##" + sale_Values1);


        this_Object.addProperty(Reference_Payload, payload2);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka2 = Post_Sales(this_Object);
        sale_Values2 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka2);
        logger.info("sale_Values2 ##" + sale_Values2);


        this_Object.addProperty(Reference_Payload, payload3);
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("Replace_transactionNbr", sale_Values1.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values1.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (sale_Object_Kafka2.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values1.get(6));

        sale_Object_Kafka3 = Post_Adjustment(this_Object);
        logger.info("sale_Object_Kafka Post_Adjustment  " + sale_Object_Kafka3);

        adjustment_Values1 = get_TransactionValues_From_SaleMessage(sale_Object_Kafka3);
        logger.info("adjustment_Values1 ##" + adjustment_Values1);

        // Posting Void message for Sale 2
        this_Object.addProperty(Reference_Payload, payload4);
        // this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        this_Object.addProperty("Replace_transactionDate", sale_Values2.get(3));
        this_Object.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (sale_Object_Kafka3.toString().contains("barcode"))
            this_Object.addProperty("Replace_barcode", sale_Values2.get(6));
        logger.info("sale_Object_Kafka Post_Void  " + sale_Object_Kafka4);

        sale_Object_Kafka4 = Post_Void(this_Object);
        logger.info("sale_Object_Kafka Post_Void  " + sale_Object_Kafka4);

        db_Balance = get_Rewards_Balance_First_row(loyaltyId).get("updatedBalance").getAsString();


    }


    /*Stored _ 01*/
    @When("Audit Reward Tracker Balance service is hit with valid Loyalty_ID ,Valid headers")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_valid_Loyalty_ID_Valid_headers() throws Exception {
        result_Object = get_Audit_Balance(loyaltyId);
        JsonObject service_body = result_Object.get("Response_Body").getAsJsonObject();
        service_Balance = service_body.get("totalEarnTracker").getAsString();
        logger.info("service_Balance " + service_Balance);

    }

    @When("Audit Reward Tracker Balance service is hit with valid Loyalty_ID {string},Valid headers for missingTransaction")
    public void audit_Reward_Tracker_Balance_service_MissingTrans(String loyaltyid_Passed) throws Exception {

        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyid_Passed);
        result_Object = get_Audit_Balance(loyaltyId);
        JsonObject service_body = result_Object.get("Response_Body").getAsJsonObject();
        service_Balance = service_body.get("totalEarnTracker").getAsString();
        logger.info("service_Balance " + service_Balance);

    }

    @Then("Audit Reward Tracker Balance service should provide totalEarnTracker value in the response")
    public void audit_Reward_Tracker_Balance_service_should_provide_totalEarnTracker_value_in_the_response() {

    }

    @Then("totalEarnTracker {string} will be equal to updated Balance Value in the balance table sorted by latest createdon timestamp")
    public void totalearntracker_will_be_equal_to_updated_Balance_Value_in_the_balance_table_sorted_by_latest_createdon_timestamp(String totalEarnTracker) {

        logger.info("Inside verification ### ");
        assertEquals("Audit service balance is not matching with LBL DB balance ", service_Balance, db_Balance);
        assertEquals("Audit service balance is not matching with expected totalEarnTracker  balance ", service_Balance, totalEarnTracker);


    }

    @Then("totalEarnTracker {string} will be equal to updated Balance Value in the balance table sorted by latest createdon timestamp for missingTransaction")
    public void totalearntrackerValidationMissingTrans(String totalEarnTracker) {
        logger.info("Inside verification ### ");
        assertEquals("Audit service balance is not matching with LBL DB balance ", service_Balance,
                     db_Balance.toString());
    }


    @Given("Transaction details should not be loaded into Audit database")
    public void transaction_details_should_not_be_loaded_into_Audit_database() {

        logger.info("Sending invalid loyalities and testing...");
    }

    @When("Audit Reward Tracker Balance service is hit with {string} for Loyalty ID in endpoint with loyid as {string}")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_for_Loyalty_ID_in_endpoint(String arg1, String loyId) throws Exception {

        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyId);

        this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        this_Object.addProperty("404_example", "404_example");

        service_body_negative = get_Balance_1348(this_Object);

        //removing not to impact other test cases
        this_Object.remove("404_example");

        logger.info("service_body_negative is $$$ :" + service_body_negative.toString());

    }

    @Then("Audit Reward Tracker Balance service sc_three should provide {string}")
    public void audit_Reward_Tracker_Balance_service_should_provide(String status_code) {
        //assertions are done in utility its for this 404 negative case
    }


    //Scenario - 4
    @Given("Transaction details should be loaded into Audit database")
    public void transaction_details_should_be_loaded_into_Audit_database() throws Exception {

        loyaltyId = create_New_Loyalty_ID();

        this_Object.addProperty(Reference_Payload, "1348_Sc1_Ex1_Sale_Message");
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        sale_Object_Kafka = Post_Sales(this_Object);

    }

    @When("Audit Reward Tracker Balance service is hit with invalid value for {string} with header values {string} {string} {string} {string} {string}")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_invalid_value_for(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String status_code) throws Exception {


        //sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "9999-01-27T20:00:23+0530";

        negative_this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", "localtestingsecretkey");
        if (status_code.equals("400") || status_code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");
        
        //passing invalid msg id
        if(MessageID.contains("wrong"))
        	negative_this_Object.addProperty("Invalid_MsgId", "Invalid_MsgId");

        service_body_negative = get_Balance_1348(negative_this_Object);

        if (status_code.equals("400") || status_code.equals("401"))
            negative_this_Object.remove("400_example");

        logger.info("service_body_negative is $$$ :" + service_body_negative.toString());

    }

    @Then("Audit Reward Tracker Balance service should provide {string}")
    public void audit_Reward_Tracker_Balance_service_sc_three_should_provide(String status_code) {
        //logger.info("response code is $$$ :"+service_body_negative.get(Response_Code).getAsString());
        if (status_code.equals("200"))
            assertTrue(service_body_negative.get(Response_Code).getAsString().equals(status_code));
    }


    //Scenario - 5
    @When("Audit Reward Tracker Balance service is hit with {string}> for Authorization header with Authorization values as {string} {string}")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_for_Authorization_header(String string, String header_key, String header_secret) throws Exception {


        negative_this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        negative_this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        negative_this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        negative_this_Object.addProperty("system_Cd", "1231");
        negative_this_Object.addProperty("corrln_Id", "lpfqe");
        negative_this_Object.addProperty("API_KEY", header_key);
        negative_this_Object.addProperty("SecretKey", header_secret);

        negative_this_Object.addProperty("400_example", "400_example");
        if (header_secret.equals("")) {
            negative_this_Object.addProperty("Empty_Secret", "Empty_Secret");
        }
        service_body_negative = get_Balance_1348(negative_this_Object);
        negative_this_Object.remove("400_example");
        if (header_secret.equals("")) {
            negative_this_Object.remove("Empty_Secret");
        }

        logger.info("service_body_negative is $$$ :" + service_body_negative.toString());

    }

    @Then("Audit Reward Tracker Balance service should provide {int} status code")
    public void audit_Reward_Tracker_Balance_service_should_provide_status_code(Integer status_code) {
        //Assert.assertTrue(service_body_negative.get(Response_Code).getAsString().equals("401"));
    }

    //Scenario - 6
    @When("Audit Reward Tracker Balance service is hit with no value for {string} with header values {string} {string} {string} {string} {string} {string}")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_no_value_for(String header, String SystemCode, String MessageID, String CorrelationID, String CreateDateTime, String Secret_Key, String Status_Code) throws Exception {

        //sending invalid header values from feature
        if (CreateDateTime.equals("Dynamic"))
            CreateDateTime = generate_Header_Date_TS();
        else
            CreateDateTime = "";

        negative_this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        negative_this_Object.addProperty("message_Id", MessageID);
        negative_this_Object.addProperty("time_Stamp", CreateDateTime);
        negative_this_Object.addProperty("system_Cd", SystemCode);
        negative_this_Object.addProperty("corrln_Id", CorrelationID);
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", Secret_Key);

        if (header.equals("X-KOHLS-MessageID"))
            negative_this_Object.addProperty("Remove_msgId", "Remove_msgId");

        if (header.equals("X-KOHLS-CreateDateTime"))
            negative_this_Object.addProperty("Remove_date", "Remove_date");

        if (Status_Code.equals("400") || Status_Code.equals("401"))
            negative_this_Object.addProperty("400_example", "400_example");

        service_body_negative = get_Balance_1348(negative_this_Object);

        if (Status_Code.equals("400"))
            negative_this_Object.remove("400_example");

        logger.info("service_body_negative is $$$ :" + service_body_negative.toString());
    }

    @Then("Audit Reward Tracker Balance service sc_six should provide {string} status code")
    public void audit_Reward_Tracker_Balance_service_sc6_should_provide_status_code(String status_code) {
        if (status_code.equals("401"))
            assertTrue(true);
        /*@team to check*/
    }


    //Scenario - 7
    @When("Audit Reward Tracker Balance service is hit with no Headers")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_no_Headers() throws Exception {

        negative_this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        negative_this_Object.addProperty("message_Id", "");
        negative_this_Object.addProperty("time_Stamp", "");
        negative_this_Object.addProperty("system_Cd", "");
        negative_this_Object.addProperty("corrln_Id", "");
        negative_this_Object.addProperty("API_KEY", "local");
        negative_this_Object.addProperty("SecretKey", "localtestingsecretkey");
        negative_this_Object.addProperty("No_Header", "No_Header");
        negative_this_Object.addProperty("400_example", "400_example");
        service_body_negative = get_Balance_1348(negative_this_Object);

        negative_this_Object.remove("400_example");
        negative_this_Object.remove("No_Header");

        logger.info("service_body_negative is $$$ :" + service_body_negative.toString());
    }


    //Scenario - 8
    @When("Audit Reward Tracker Balance service sc_eight is hit with valid loyalty ID,Valid headers")
    public void audit_Reward_Tracker_Balance_service_sc_eight_is_hit_with_valid_loyalty_ID_Valid_headers() throws Exception {

        loyaltyId = create_New_Loyalty_ID();

        this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");

        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyaltyId);
        this_Object.addProperty("404_example", "404_example");

        result_Object = get_Balance_1348(this_Object);

        this_Object.remove("404_example");
        logger.info("result_Object is $$$ :" + result_Object.toString());
    }

    @Then("Audit Reward Tracker Balance service should provide code {int} status code")
    public void audit_Reward_Tracker_Balance_service_should_provide_code_status_code(Integer int1) {
        //Assert.assertTrue(service_body_negative.get(Response_Code).getAsString() == "404");
    }


    //Scenario - 9
    @Given("Transaction details should be loaded into Audit database with valid balance value in balance table")
    public void transaction_details_should_be_loaded_into_Audit_database_with_valid_balance_value_in_balance_table() throws Exception {

        this_Object.addProperty(Reference_Payload, "1348_Sc1_Ex1_Sale_Message");
        sale_Object_Kafka = Post_Sales(this_Object);

    }

    @Given("Bring {string} down")
    public void bring_down(String string) {


    }

    @Then("Audit Reward Tracker Balance service should provide {string} status code")
    public void audit_Reward_Tracker_Balance_service_should_provide_status_code(String status_code) {

        assertTrue(service_body.get(Response_Code).getAsString() == status_code);
    }

    @Then("message should be displayed as {string}")
    public void message_should_be_displayed_as(String error_message) {

        assertTrue(service_body.toString().contains(error_message));
    }


    //Scenario - 10

    @When("Audit Reward Tracker Balance service is hit with invalid resource URL")
    public void audit_Reward_Tracker_Balance_service_is_hit_with_invalid_resource_URL() throws Exception {

        this_Object.addProperty("message_Id", "5319c8f5-55f2-4605-82b5-LPFQEMsgIdb1");
        this_Object.addProperty("time_Stamp", generate_Header_Date_TS());
        this_Object.addProperty("system_Cd", "1231");
        this_Object.addProperty("corrln_Id", "lpfqe");
        this_Object.addProperty("API_KEY", "local");
        this_Object.addProperty("SecretKey", "localtestingsecretkey");
        //this_Object.addProperty("Invalid_URL", "Invalid_URL");
        this_Object.addProperty("404_example", "404_example");
        //giving invalid LoyId
        this_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, "711182373601");
        result_Object = get_Balance_1348(this_Object);

        this_Object.remove("Invalid_URL");

    }

    @Then("Audit Reward Tracker Balance service sc_ten should provide {int} status code")
    public void audit_Reward_Tracker_Balance_service_sc_ten_should_provide_code_status_code(Integer int1) {
        //Assert.assertTrue(service_body_negative.get(Response_Code).getAsString() == "404");
    }


}
