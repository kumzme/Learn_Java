package Step_Defs.V2_Steps.Sprint1;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.bson.Document;

import java.util.ArrayList;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.*;
import static Functional_Utilities.V2_Sale_Functionalities.Post_Sales;
import static Functional_Utilities.V2_Sale_Functionalities.get_TransactionValues_From_SaleMessage;
import static Service_Functions.V2.V2_Audit_Rewards.validateActivityTable;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static Utilities.UtilConstants_Data_Rules_Reference.Total_Loyalty_Ids_Needed;
import static org.junit.Assert.*;

public class LPF_1339_AuditToConsumePOCSaleMessagesForPilotCustomer {
    protected static final Logger logger = get_Logger();
    JsonObject pass_This         = new JsonObject();
    JsonObject this_Object       = new JsonObject();
    JsonObject dynamicValidation = new JsonObject();
    JsonObject kafka_Object_Res_For_Sale1;
    JsonObject kafka_Object_Res_For_Sale2;
    JsonObject Sale1BalanceTable;
    JsonObject Sale2BalanceTable;

    @Given("Create- a Loyalty of scenario for Sale of {string}")
    public void setup_event_period_as_for_Sale_of_for(String total_Sales) throws Exception {

        pass_This.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
        pass_This.addProperty(Total_Loyalty_Ids_Needed, total_Sales);
        this_Object.addProperty("Generic_Loyalty_Id_0", generateLoyaltyIdRandom());
    }


    @Given("A sale1 message for {string} should be there in MKTG_SALE topic")
    public void performing_number_one_transaction_for_a_customer_with(String sale1_payload) throws Exception {
        logger.info("Sale1 Message is posting to kafka..");
        this_Object.addProperty(Reference_Payload, sale1_payload + "_Sale_01");

        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object_Res_For_Sale1 = Post_Sales(this_Object);
        Sale1BalanceTable = get_Rewards_Balance_First_row(this_Object.get("Generic_Loyalty_Id_0").getAsString());

        logger.info("kafka_Object_Res_For_Sale1  $$$$$$ " + kafka_Object_Res_For_Sale1);
        logger.info("Sale2 Message is posted succesfully to kafka..");
    }

    @When("Audit listener process the POC sale message for sale1")
    public void Audit_listener_process_POC_sale_message_for_sale1() throws Exception {
        logger.info("Message successfully send with Offset::" + kafka_Object_Res_For_Sale1.get("Kafka_Message_Offset"));

    }

    @Given("A sale2 message for {string} should be there in MKTG_SALE topic")
    public void performing_number_two_transaction_for_a_customer_with(String sale2_payload) throws Exception {
        logger.info("Sale2 Message is posting to kafka..");
        this_Object.addProperty(Reference_Payload, sale2_payload + "_Sale_02");

        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());

        kafka_Object_Res_For_Sale2 = Post_Sales(this_Object);
        Sale2BalanceTable = get_Rewards_Balance_First_row(this_Object.get("Generic_Loyalty_Id_0").getAsString());
        logger.info("kafka_Object_Res_For_Sale2  $$$$$$ " + kafka_Object_Res_For_Sale2);
        logger.info("Sale2 Message is posted succesfully to kafka..");

    }

    @When("Audit listener process the POC sale message for sale2")
    public void Audit_listener_process_POC_sale_message_for_sale2() {
        logger.info("Message successfully send with Offset::" + kafka_Object_Res_For_Sale2.get("Kafka_Message_Offset"));

    }

    @Then("validate sale1 fields in Activity table and MessageDetail with {string}")
    public void validate_sale1_fields_in_Activity_table(String validationKeyName) throws Exception {
        logger.info("Sale1 Activity Validation is processing with " + validationKeyName + "_Sale_01_Acticity Key");
        dynamicValidation.addProperty("loyaltyId", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        dynamicValidation.addProperty("trnsName", "Sale_01");

        /*@Remove*/
        Document actual = get_Rewards_Activity_Rows(dynamicValidation);
        if (actual != null) {
            this_Object.addProperty("Sale01_Activity_ID", actual.get("_id").toString());
            JsonObject validationData = null;
            if (consolidated_Data.has(validationKeyName + "_Sale_01_Acticity"))
                validationData = consolidated_Data.get(validationKeyName + "_Sale_01_Acticity").getAsJsonObject();
            Document expected = Document.parse(validationData.toString());
            validateActivityTable(expected, actual, dynamicValidation);
        } else {
            fail("Actual response from Activity Table is getting Null");
        }
        logger.info("Sale1 Activity Validation is processed with " + validationKeyName + "_Sale_01_Acticity Key");

    }

    @Then("validate sale2 fields in Activity table and MessageDetail with {string}")
    public void validate_sale2_fields_in_Activity_table(String validationKeyName) throws Exception {
        logger.info("Sale2 Activity Validation is processing with " + validationKeyName + "_Sale_01_Acticity Key");
        dynamicValidation.addProperty("loyaltyId", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        dynamicValidation.addProperty("trnsName", "Sale_02");

        Document actual = get_Rewards_Activity_Rows(dynamicValidation);
        if (actual != null) {
            this_Object.addProperty("Sale02_Activity_ID", actual.get("_id").toString());
            JsonObject validationData = null;
            if (consolidated_Data.has(validationKeyName + "_Sale_02_Acticity"))
                validationData = consolidated_Data.get(validationKeyName + "_Sale_02_Acticity").getAsJsonObject();
            Document expected = Document.parse(validationData.toString());

            validateActivityTable(expected, actual, dynamicValidation);
        } else {
            fail("Actual response from Activity Table is getting Null");
        }
        logger.info("Sale2 Activity Validation is processed with " + validationKeyName + "_Sale_01_Acticity Key");
    }

    @Then("validate sale1 fields in Balance table with {string}")
    public void validate_sale1_fields_in_Balance_table(String validationKeyName) throws Exception {
        logger.info("Sale1 Balance table Validation is processing with " + validationKeyName + "_Sale_01_Balance Key");
        JsonObject actual         = Sale1BalanceTable.get("First_Row").getAsJsonObject();
        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_01_Balance"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_01_Balance").getAsJsonObject();

        assertNotNull("_ID Value is:", actual.get("_id"));
        assertEquals("loyaltyId value is:", actual.get("loyaltyId").getAsString(), this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertEquals("Activity_ID Value is:", actual.get("activityId").getAsString(), this_Object.get("Sale01_Activity_ID").getAsString());
        assertEquals("updatedBalance value is:", validationData.get("updatedBalance").getAsString(), actual.get("updatedBalance").getAsString());
        logger.info("Sale1 Balance table Validation is processed with " + validationKeyName + "_Sale_01_Balance Key");
    }

    @Then("validate sale2 fields in Balance table with {string}")
    public void validate_sale2_fields_in_Balance_table(String validationKeyName) throws Exception {
        JsonObject actual         = Sale2BalanceTable.get("First_Row").getAsJsonObject();
        JsonObject validationData = null;
        if (consolidated_Data.has(validationKeyName + "_Sale_02_Balance"))
            validationData = consolidated_Data.get(validationKeyName + "_Sale_02_Balance").getAsJsonObject();


        assertEquals("Activity_ID Value is:", actual.get("activityId").getAsString(), this_Object.get("Sale02_Activity_ID").getAsString());
        assertNotNull("_ID Value is:", actual.get("_id"));
        assertEquals("loyaltyId value is:", actual.get("loyaltyId").getAsString(), this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertEquals("updatedBalance value is:", validationData.get("updatedBalance").getAsString(), actual.get("updatedBalance").getAsString());

        logger.info("Sale2 Balance table Validation is processed with " + validationKeyName + "_Sale_01_Balance Key");
    }

    @Then("barcode table should be updated as null in Audit database")
    public void barcode_table_should_be_updated_as_null_in_Audit_database() throws Exception {
        /*@Remove check*/
        JsonObject actual = get_Rewards_Kohlscash_Rows_First(this_Object.get("Generic_Loyalty_Id_0").getAsString());
        assertTrue("KohlsKash table should be null but is getting values", actual.entrySet().size() > 0);
    }

    @Then("transaction details should not be loaded in Audit database")
    public void transaction_details_should_not_be_loaded_in_Audit_database() throws Exception {

        ArrayList<String> list   = get_TransactionValues_From_SaleMessage(kafka_Object_Res_For_Sale1);
        JsonObject        actual = get_Rewards_Activity_With_MessageId_First(list.get(5));
        assertTrue("Activity table is", actual.entrySet().size() > 0);

    }

}
