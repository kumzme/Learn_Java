package Step_Defs.V2_Steps.Data_Model_Change;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;

import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.convert_String_To_JsonObject;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static org.junit.Assert.assertEquals;


public class Data_Model_Change {

    protected static final Logger logger = get_Logger();
    public                 String loyaltyId;


    @Given("I do Data model Change For something in unordered Example")
    public void i_do_Data_model_Change_For_something() {
        String aa  = consolidated_Data.get("Data_Orginal_1362_Sc4_Ex2_Payload").getAsString();
        String aa2 = consolidated_Data.get("Data_Modified_Needed_Activity").getAsString();
        //JsonObject aa = consolidated_Data.get("Data_Orginal_1362_Sc4_Ex2_Payload").getAsJsonObject();
        JsonObject aaa  = convert_String_To_JsonObject(aa);
        JsonObject aaac = convert_String_To_JsonObject(aa2);
        logger.info(aa);
        String Newfield_Int = "Newfield_Int";
        aaa.addProperty("Newfield_01", "Newfield_Value");
        aaa.addProperty("Newfield_02_Int", Newfield_Int);
        aaa.addProperty("Newfield_03_Some", 9999);
        aaa.add("Newfield__04_Object", aaac);

        logger.info(aaa);

        logger.info(aaac);

        String final_Val = aaa.toString();
        logger.info(final_Val);
    }

    @Given("I do Data model Change For something in ordered Example")
    public void i_do_Data_model_Change_Ordered() {
        String     orig_String         = consolidated_Data.get("Data_Orginal_1362_Sc4_Ex2_Payload").getAsString();
        JsonObject orig_Object         = convert_String_To_JsonObject(orig_String);
        JsonObject conv_Object         = new JsonObject();
        String     needed_fragment     = consolidated_Data.get("Data_Modified_Needed_Activity").getAsString();
        JsonObject needed_fragment_Obj = convert_String_To_JsonObject(needed_fragment);
        String     Newfield_Int        = "Newfield_Int";
        logger.info(orig_String);

        conv_Object.addProperty("loyaltyId", orig_Object.get("loyaltyId").getAsString());
        conv_Object.addProperty("totalAmount", orig_Object.get("totalAmount").getAsDouble());
        conv_Object.addProperty("Newfield_01", "Newfield_Value");
        conv_Object.addProperty("Newfield_02_Int", Newfield_Int);
        conv_Object.addProperty("Newfield_03_Some", 999999);
        conv_Object.add("Newfield__04_Object", needed_fragment_Obj);
        conv_Object.addProperty("qualifiedAmount", orig_Object.get("qualifiedAmount").getAsInt());
        conv_Object.add("tenders", orig_Object.get("tenders").getAsJsonArray());
        conv_Object.addProperty("transactionDate", orig_Object.get("transactionDate").getAsString());

        logger.info(orig_Object);
        logger.info(needed_fragment_Obj);


        String     expected_Object_S = consolidated_Data.get("Data_Modified_Final_1362_Sc4_Ex2_Payload").getAsString();
        JsonObject expected_Object   = convert_String_To_JsonObject(expected_Object_S);

        assertEquals("Check Expected and actual FORMAT only for correctness here::", expected_Object, conv_Object);
        logger.info("__________________________________");
        logger.info("original_Object_____:-" + orig_Object);
        logger.info("__________________________________");
        logger.info("expected_Object_____:-" + expected_Object);
        logger.info("__________________________________");
        logger.info("converted_Object_____:-" + conv_Object);
        logger.info("__________________________________");
    }

}
