package Step_Defs.Sample_Kafka_Validation;


import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.List;

import static Service_Functions.Rule_Config_Functionalities.get_Rules_Version_To_PostString;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.Kafka_Utilities.seek_Specific_Kafka_Message;
import static Utilities.Kafka_Utilities.send_Kafka_Message;
import static Utilities.UtilConstants.*;


public class Sample_Kafka_Validation {

    private static         JsonObject this_Object = null;
    protected static final Logger     logger      = get_Logger();

    @Given("I execute some sql with Reference {string}")
    public static int executeDB(String sql_KeyName_From_SQLFolder) throws Throwable {

        return get_Rules_Version_To_PostString(sql_KeyName_From_SQLFolder);

    }

    @Given("I post a {string} to Kafka for {string} and {string} for {string}")
    public void iamconnectedtokafka(String message_To_Be_Posted, String kafka_Environment, String kafka_Topic, String message_Key) throws Exception {


        JsonObject all_Values = new JsonObject();
        all_Values.addProperty(Kafka_Topic_name, kafka_Topic);
        all_Values.addProperty(Kafka_Message_Body, message_To_Be_Posted);
        all_Values.addProperty(Kafka_Message_Key, Kafka_Message_Key_LpfQE); //Optional
        this.this_Object = send_Kafka_Message(all_Values);

        logger.info(this.this_Object.get(Kafka_Message_Body).getAsString());
        logger.info(this.this_Object.get(Kafka_Message_Key).getAsString());
        logger.info(this.this_Object.get(Kafka_Message_Offset).getAsString());
        logger.info(this.this_Object.get(Kafka_Message_Partition).getAsString());
        logger.info("\n");
        Thread.sleep(8000);
        this_Object.addProperty(Kafka_Topic_name, kafka_Topic);

    }

    @When("I should be able to connect to {string} and {string} and verify that the {string} exists")
    public void iamconnectedtokafka2(String kafka_Environment, String kafka_Topic, String message_To_Be_Searched) throws Exception {

        JsonObject all_Values = new JsonObject();
        /*Mandatory*/
        all_Values.addProperty(Kafka_Topic_name, this_Object.get(Kafka_Topic_name).getAsString());
        all_Values.addProperty(Kafka_Message_Body, this_Object.get(Kafka_Message_Body).getAsString());
        all_Values.addProperty(Kafka_Message_Partition, this_Object.get(Kafka_Message_Partition).getAsString());
        /*Optional*/
        //all_Values.addProperty(Kafka_Message_Key, this_Object.get(Kafka_Message_Key).getAsString());

        List<JsonObject> search_Sent_Message = seek_Specific_Kafka_Message(all_Values);

        logger.info(search_Sent_Message.get(0).get(Kafka_Message_Body).getAsString());
        logger.info(search_Sent_Message.get(0).get(Kafka_Message_Key).getAsString());
        logger.info(search_Sent_Message.get(0).get(Kafka_Message_Offset).getAsString());
        logger.info(search_Sent_Message.get(0).get(Kafka_Message_Partition).getAsString());
        logger.info("\n");
    }


}
