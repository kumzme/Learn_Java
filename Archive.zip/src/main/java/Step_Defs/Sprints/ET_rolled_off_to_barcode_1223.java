package Step_Defs.Sprints;

import Functional_Utilities.V2_Sale_Functionalities;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.Pilot_Checker_Functionalities.Generate_Pilot_Customers_With_New_Loyalty_IDs;
import static Service_Functions.Rule_Config_Functionalities.post_New_Rule_Config;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class ET_rolled_off_to_barcode_1223 {
	JsonObject passing_Object = new JsonObject();
	JsonObject additional_Object = new JsonObject();
	JsonObject sale_Object = new JsonObject();
	JsonObject sale_Message = new JsonObject();
	JsonObject void_Message = new JsonObject();
	List<String> transaction_ids = new ArrayList<>();
	protected static final Logger logger = get_Logger();

	@Given("Active pilot loyalty profile for a customer1")
	public void active_pilot_loyalty_profile_for_a_customer() throws Exception {

	}

	@Given("The event period is configured as {string} for Sale of {string} for {string}")
	public void event_period_is_configured_as_for_Sale_of(String event_period, String total_sales, String scenario_Name)
			throws Exception {

		passing_Object.addProperty(Total_Loyalty_Ids_Needed, 1);
		passing_Object.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
		additional_Object = Generate_Pilot_Customers_With_New_Loyalty_IDs(passing_Object);
		additional_Object.addProperty(Reference_Scenario, scenario_Name);
		passing_Object.addProperty(Reference_Payload, scenario_Name + "_Rule");
		logger.info(scenario_Name + "_Rule");
		post_New_Rule_Config(passing_Object);

	}

	@Given("I perform four consecutive Sale transactions say {string}, {string}, {string} and {string} for the same pilot Loyalty ID")
	public void multiple_Consequetive_Sales(String Sale_01, String Sale_02, String Sale_03, String Sale_04)
			throws Exception {
		String scenario_Name = additional_Object.get(Reference_Scenario).getAsString();
		String sql_Reference_Name = scenario_Name + "_Check_No_Barcode_Kcc_SQL";
		String loyalty_Id = additional_Object.get("Generic_Loyalty_Id_0").getAsString();
		String[] args = { Sale_01, Sale_02, Sale_03, Sale_04 };
		passing_Object.addProperty(Reference_SQL, sql_Reference_Name);
		for (int i = 0; i < 4; i++) {
			String sale_Name = scenario_Name + "_" + args[i];
			passing_Object.addProperty(Reference_Payload, sale_Name);
			passing_Object.addProperty(Refer_Rule_Replace_Loyalty_Id, loyalty_Id);
            
			if(scenario_Name.equalsIgnoreCase("Void_Cons_Sale_Evnt_Every_Ex_01")||scenario_Name.equalsIgnoreCase("Void_Cons_Sale_Evnt_Every_Ex_03")||scenario_Name.equalsIgnoreCase("Void_Cons_Sale_Evnt_Every_Ex_04")) {
			if (i == 1) {
				ArrayList<String> sale_ValuesBarCode = get_TransactionValues_From_SaleMessage(sale_Message);
				String barcode = sale_ValuesBarCode.get(6);
				passing_Object.addProperty("Replace_barcode", barcode);
			}
			}
			sale_Message = Post_Sales(passing_Object);

            transaction_ids.add(V2_Sale_Functionalities.get_TransactionId_From_SaleMessage(sale_Message));
			
			logger.info("sale_Message is $$$ :" + sale_Message.toString());
			logger.info("Sale" + (i + 1) + "is done...");
			
			ArrayList<String> sale_Values1 = get_TransactionValues_From_SaleMessage(sale_Message);
			sale_Values1.add(scenario_Name);
			
			JsonElement sale_Values = convert_String_ArrayList_To_JsonElement(sale_Values1);
			sale_Object.add(sale_Name, sale_Values);
			// before void DB validations
		}
	}

	@When("The customer is voiding {string} transaction")
	public void second_Addition(String sale_Num) throws Exception {

		for (Map.Entry<String, JsonElement> sale_Item : sale_Object.entrySet()) {
			JsonArray sale_Values = sale_Item.getValue().getAsJsonArray();
			int size_Array = sale_Values.size();
			String scenario_Name = sale_Values.get(size_Array - 1).getAsString();
			String sale_Name = sale_Item.getKey();
            logger.info("condition Val     " + sale_Name.toLowerCase().substring(sale_Name.length() - 1).contains(sale_Num));
			if (sale_Name.toLowerCase().substring(sale_Name.length() - 1).contains(sale_Num)) {
				JsonObject pass_This = new JsonObject();
				pass_This.addProperty(Reference_Payload, scenario_Name + "_Void_" + sale_Num);
				pass_This.addProperty(Rule_Replace_Transaction_Nbr, sale_Values.get(0).getAsString());
				pass_This.addProperty(Rule_Replace_Transaction_Date, sale_Values.get(3).getAsString());
				pass_This.addProperty(Rule_Replace_Transaction_Time, sale_Values.get(4).getAsString());

				JsonObject void_Message = Post_Void(pass_This);
                transaction_ids.add(V2_Sale_Functionalities.get_TransactionId_From_SaleMessage(void_Message));
				logger.info("Void_Message is $$$ :" + void_Message.toString());
				logger.info("Void is done...");
				JsonElement void_Value = convert_JsonObject_To_JsonElement(void_Message);
				void_Message.add(scenario_Name + "_Void_" + sale_Num, void_Value);
			}
			//Thread.sleep(5000);
		}
	}

	@Given("event period is configured as {string} for Sale_1 and Sale_2 for {string}")
	public void event_period_is_configured_as_for_Sale_1_and_Sale2_(String event, String scenario_Name)
			throws Throwable {
		event_period_is_configured_as_for_Sale_of(event, "4", scenario_Name);
	}

	@Given("event period is configured as {string} for Sale_3 and Sale_4")
	public void event_period_is_configured_as_for_Sale_3_and_Sale_4(String scenario_Name) throws Throwable {
        logger.info("same as above");
	}

	@Given("perform Sale_1 and Sale_2 transactions in {string} for the same pilot Loyalty ID when posting {string}, {string}, {string} and {string}")
	public void perform_Sale_1_and_Sale_2_transactions_in_for_the_same_pilot_Loyalty_ID(String event, String Sale_01,
			String Sale_02, String Sale_03, String Sale_04) throws Throwable {
		multiple_Consequetive_Sales(Sale_01, Sale_02, Sale_03, Sale_04);
	}

	@Given("perform Sale_3 and Sale_4 transactions in {string} for the same pilot Loyalty ID")
	public void perform_Sale_3_and_Sale_4_transactions_in_for_the_same_pilot_Loyalty_ID(String event) throws Throwable {
        logger.info("Getting from above");
	}

	@When("the customer is voiding {string} transaction in {string}")
	public void the_customer_is_voiding_transaction_in(String sale_Num, String event_Period2) throws Throwable {
		second_Addition(sale_Num);
	}

	@Then("The earntracker greater than {string} in audit database should roll off to barcode")
	public void the_earntracker_greater_than_in_audit_database_should_roll_off_to_barcode(String arg1)
			throws Exception {
		JsonObject new_Pass = new JsonObject();
		String select_In_Cluase_Query = null;

		new_Pass.addProperty("Replace_Transaction_ID_01", transaction_ids.get(0));
		new_Pass.addProperty("Replace_Transaction_ID_02", transaction_ids.get(1));
		new_Pass.addProperty("Replace_Transaction_ID_03", transaction_ids.get(2));
		new_Pass.addProperty("Replace_Transaction_ID_04", transaction_ids.get(3));

/*		String earnDetail = "Transaction_IDS_For_4_Sales_Of_earn_detail";
		select_In_Cluase_Query = parse_And_Generate_Data(earnDetail, new_Pass);
		ArrayList<List<String>> a1 = execute_SQL_MySQL_DB_CRUD(select_In_Cluase_Query);
		logger.info("EarnTrackerDetails $$ :" + select_In_Cluase_Query);
		logger.info("EarnTrackerDetails After hittting to DB $$ :" + a1.toString());
		
		
		String earnTracker = "Transaction_IDS_For_4_Sales_Of_earn_tracker";
		select_In_Cluase_Query = parse_And_Generate_Data(earnTracker, new_Pass);
		ArrayList<List<String>> a2 = execute_SQL_MySQL_DB_CRUD(select_In_Cluase_Query);
		logger.info("EarnTracker $$ :" + select_In_Cluase_Query);
		logger.info("EarnTracker After hitting to DB $$ :" + a2.toString());
		
		String kohlsCash = "Transaction_IDS_For_4_Sales_Of_kohls_cash";
		select_In_Cluase_Query = parse_And_Generate_Data(kohlsCash, new_Pass);
		ArrayList<List<String>> a3 = execute_SQL_MySQL_DB_CRUD(select_In_Cluase_Query);
		logger.info("KohlsCash $$ :" + select_In_Cluase_Query);
		logger.info("KohlsCash After hitting to DB $$ :" + a3.toString());
		
		String originalTrax = "Transaction_IDS_For_4_Sales_Of_original_transaction";
		select_In_Cluase_Query = parse_And_Generate_Data(originalTrax, new_Pass);
		ArrayList<List<String>> a4 = execute_SQL_MySQL_DB_CRUD(select_In_Cluase_Query);
		logger.info("KohlsCash $$ :" + select_In_Cluase_Query);
		logger.info("KohlsCash After hittting to DB $$ :" + a3.toString());*/
	}

	@Then("the earntracker greater than {string} in audit database should roll off to barcode\\.")
	public void the_earntracker_greater1_than_in_audit_database_should_roll_off_to_barcode(String earnTracker) throws Throwable {
	    
	}
	
	
}
