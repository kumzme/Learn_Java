package Step_Defs.Sprints;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

import static Functional_Utilities.V2_Sale_Functionalities.*;
import static Service_Functions.Pilot_Checker_Functionalities.Generate_Pilot_Customers_With_New_Loyalty_IDs;
import static Service_Functions.Rule_Config_Functionalities.post_New_Rule_Config;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Sql;
import static Utilities.DB_Utilities.execute_SQL_MySQL_DB_CRUD;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static org.junit.Assert.assertEquals;

;

public class Multi_receipt_return_with_Multiple_LoyIDs_1233 {

    JsonObject pass_This     = new JsonObject();
    JsonObject this_Object   = new JsonObject();
    JsonObject kafka_Object1 = new JsonObject();
    JsonObject kafka_Object2 = new JsonObject();
    JsonObject kafka_Object3 = new JsonObject();
    JsonObject kafka_Object4 = new JsonObject();
    JsonObject kafka_Object5 = new JsonObject();
    JsonObject kafka_Object6 = new JsonObject();
    JsonObject kafka_Object7 = new JsonObject();
    JsonObject kafka_Object8 = new JsonObject();

    JsonObject additional_Object1 = new JsonObject();
    JsonObject additional_Object2 = new JsonObject();
    JsonObject additional_Object3 = new JsonObject();
    JsonObject additional_Object4 = new JsonObject();

    JsonObject validation_Object1 = new JsonObject();
    JsonObject validation_Object2 = new JsonObject();
    JsonObject validation_Object3 = new JsonObject();
    JsonObject validation_Object4 = new JsonObject();

    ArrayList<String> sale_Values1;
    ArrayList<String> sale_Values2;
    ArrayList<String> sale_Values3;
    ArrayList<String> sale_Values4;

    protected static final Logger logger = get_Logger();


    @Given("Active pilot loyalty profile for a customer")
    public void active_pilot_loyalty_profile_for_a_customer() throws Exception {
        logger.info("Background...");
    }


    @Given("Configuring event period as {string} for Sale of {string} for {string} and {string}")
    public void configuring_event_period_as_for_Sale(String vent_Period, String total_Sales, String rule_Payload, String kafka_Payload) throws Exception {


        pass_This.addProperty(Total_Loyalty_Ids_Needed, total_Sales);
        pass_This.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
        this_Object = Generate_Pilot_Customers_With_New_Loyalty_IDs(pass_This);
        logger.info("Pilot is done");

        if (!rule_Payload.equals("") || rule_Payload.equals(null)) {
            this_Object.addProperty(Reference_Payload, rule_Payload);
            post_New_Rule_Config(this_Object);
            logger.info("Rule Config is done...");
        }

    }

    @Given("Configuring event period as {string} for returning the sale")
    public void configuring_event_period_as_for_returning_the_sale(String event_period_2) throws Exception {

        logger.info("configure rule config for returning...");
    }


    @Given("Performing {string} numberOne transactions for a customer with {string} and {string}")
    public void performing_numberOne_transactions_for_a_customer_with(String arg1, String arg2, String SaleName) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object1 = Post_Sales(this_Object);
        logger.info("Kafka Sale1 is done...");

        sale_Values1 = get_TransactionValues_From_SaleMessage(kafka_Object1);


        /*Todo @Review add Replace_transactionNbr/Replace_transactionDate/Replace_transactionTime as constant?*/
        additional_Object1.addProperty("Replace_transactionNbr", sale_Values1.get(0));
        additional_Object1.addProperty("Replace_transactionDate", sale_Values1.get(3));
        additional_Object1.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (kafka_Object1.toString().contains("barcode"))
            additional_Object1.addProperty("Replace_barcode", sale_Values1.get(6));
    }

    /*
    @Given("Performing {string} numberOne  transactions for a customer with {string} and {string}")
    public void performing_numberOne_transactions_for_a_customer_with(String arg1, String arg2, String SaleName) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object1 = Post_Sales(this_Object);
        logger.info("Kafka Sale1 is done...");

        sale_Values1 = get_TransactionValues_From_SaleMessage(kafka_Object1);


        Todo @Review add Replace_transactionNbr/Replace_transactionDate/Replace_transactionTime as constant?
        additional_Object1.addProperty("Replace_transactionNbr", sale_Values1.get(0));
        additional_Object1.addProperty("Replace_transactionDate", sale_Values1.get(3));
        additional_Object1.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (kafka_Object1.toString().contains("barcode"))
            additional_Object1.addProperty("Replace_barcode", sale_Values1.get(6));
    }
    */


    @Given("Performing {string} numberTwo transactions for a customer with {string} and {string}")
    public void performing_numberTwo_transactions_for_a_customer_with_and(String arg1, String arg2, String SaleName) throws Exception {

        this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_1").getAsString());
        kafka_Object2 = Post_Sales(this_Object);
        logger.info("Kafka Sale2 is done...");

        sale_Values2 = get_TransactionValues_From_SaleMessage(kafka_Object2);

        additional_Object2.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        additional_Object2.addProperty("Replace_transactionDate", sale_Values2.get(3));
        additional_Object2.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (kafka_Object2.toString().contains("barcode"))
            additional_Object2.addProperty("Replace_barcode", sale_Values2.get(6));
    }

    @Given("Performing {string} numberThree transactions for a customer with {string} and {string}")
    public void performing_numberThree_transactions_for_a_customer_with_and(String arg1, String arg2, String SaleName) throws Exception {

        this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_2").getAsString());
        kafka_Object3 = Post_Sales(this_Object);
        logger.info("Kafka Sale3 is done...");

        sale_Values3 = get_TransactionValues_From_SaleMessage(kafka_Object3);

        additional_Object3.addProperty("Replace_transactionNbr", sale_Values3.get(0));
        additional_Object3.addProperty("Replace_transactionDate", sale_Values3.get(3));
        additional_Object3.addProperty("Replace_transactionTime", sale_Values3.get(4));
        if (kafka_Object3.toString().contains("barcode"))
            additional_Object3.addProperty("Replace_barcode", sale_Values3.get(6));
    }

    @Given("Performing {string} numberFour transactions for a customer with {string} and {string}")
    public void performing_numberFour_transactions_for_a_customer_with_and(String arg1, String arg2, String SaleName) throws Exception {

        this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_3").getAsString());
        kafka_Object4 = Post_Sales(this_Object);
        logger.info("Kafka Sale4 is done...");
        logger.info("__");

        sale_Values4 = get_TransactionValues_From_SaleMessage(kafka_Object4);

        additional_Object4.addProperty("Replace_transactionNbr", sale_Values4.get(0));
        additional_Object4.addProperty("Replace_transactionDate", sale_Values4.get(3));
        additional_Object4.addProperty("Replace_transactionTime", sale_Values4.get(4));
        if (kafka_Object4.toString().contains("barcode"))
            additional_Object4.addProperty("Replace_barcode", sale_Values4.get(6));
    }

    @When("the customer makes multi-receipted {string} for each of the Sales Transaction and {string} {string} {string} {string}")
    public void the_customer_makes_multi_receipted_for_each_of_the_Sales_Transaction_and(String returnType, String Return1Name, String Return2Name, String Return3Name, String Return4Name) throws Exception {
        
       
    	/*String     t_Number = kafka_Object.get("Kafka_Message_Body").getAsString();
        JsonObject aa       = new Gson().fromJson(t_Number, JsonObject.class);
        String     tnumber  = aa.get("messageBody").getAsJsonObject().get("transactionKey").getAsJsonObject().get("transactionNbr").getAsString();
        this_Object.addProperty("laknl;kamn a", t_Number);*/

        additional_Object1.addProperty(Reference_Payload, Return1Name);
        additional_Object2.addProperty(Reference_Payload, Return2Name);
        additional_Object3.addProperty(Reference_Payload, Return3Name);
        additional_Object4.addProperty(Reference_Payload, Return4Name);

        /*Todo @Review add Generic_Loyalty_Id as constant?*/
        additional_Object1.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object5 = Post_Return(additional_Object1);
        logger.info("Post Return1 is done...");

        ArrayList<String> sale_Values5 = get_TransactionValues_From_SaleMessage(kafka_Object5);
        additional_Object2.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object2.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object2.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_1").getAsString());
        kafka_Object6 = Post_Return(additional_Object2);

        logger.info("Post Return2 is done...");

        additional_Object3.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object3.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object3.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_2").getAsString());
        kafka_Object7 = Post_Return(additional_Object3);

        logger.info("Post Return3 is done...");

        additional_Object4.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object4.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object4.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_3").getAsString());
        kafka_Object8 = Post_Return(additional_Object4);

        logger.info("Post Return4 is done...");
        Thread.sleep(5000);

    }


    @Then("the transaction details will be updated in Audit database")
    public void the_transaction_details_will_be_updated_in_Audit_database() throws Exception {

    }


    @Then("the transaction details will be updated in Audit database with ReturnValidation1Name as {string} ReturnValidation2Name {string} ReturnValidation3Name {string} ReturnValidation4Name {string}")
    public void the_transaction_details_will_be_updated_in_Audit_database(String ReturnValidation1Name, String ReturnValidation2Name, String ReturnValidation3Name, String ReturnValidation4Name) throws Exception {


        String ExptranIdsale1 = "";
        String ExptranIdsale2 = "";
        String ExptranIdsale3 = "";
        String ExptranIdsale4 = "";
        String ExptranId      = "";


        validation_Object1 = (JsonObject) consolidated_Data.get(ReturnValidation1Name).getAsJsonObject();
        logger.info("OriginalTransaction_earnTrackerImpact " + validation_Object1.get("OriginalTransaction_earnTrackerImpact"));

        validation_Object2 = (JsonObject) consolidated_Data.get(ReturnValidation2Name).getAsJsonObject();
        logger.info("OriginalTransaction_earnTrackerImpact " + validation_Object2.get("OriginalTransaction_earnTrackerImpact"));

        validation_Object3 = (JsonObject) consolidated_Data.get(ReturnValidation3Name).getAsJsonObject();
        logger.info("OriginalTransaction_earnTrackerImpact " + validation_Object3.get("OriginalTransaction_earnTrackerImpact"));

        validation_Object4 = (JsonObject) consolidated_Data.get(ReturnValidation4Name).getAsJsonObject();
        logger.info("OriginalTransaction_earnTrackerImpact " + validation_Object4.get("OriginalTransaction_earnTrackerImpact"));


        for (int saleNo = 1; saleNo < 5; saleNo++) {

            if (saleNo == 1) {

                logger.info("sale_Values1  " + sale_Values1);
                ExptranIdsale1 = get_TransactionId_From_SaleMessage(kafka_Object1);
                
                /*String transactionNbr  = sale_Values1.get(0);
                String storeNbr        = sale_Values1.get(1);
                String registerId      = sale_Values1.get(2);
                String transactionDate = sale_Values1.get(3).replaceAll("-", "");
                String transactionTime = sale_Values1.get(4).replaceAll(":", "");

                ExptranIdsale1 = transactionNbr.toString() + "-S" + storeNbr + "R" + registerId + "T" + transactionDate.toString() + transactionTime.toString();*/

            }

            if (saleNo == 2) {

                logger.info("sale_Values2  " + sale_Values2);
                ExptranIdsale2 = get_TransactionId_From_SaleMessage(kafka_Object2);
                /*String transactionNbr  = sale_Values2.get(0);
                String storeNbr        = sale_Values2.get(1);
                String registerId      = sale_Values2.get(2);
                String transactionDate = sale_Values2.get(3).replaceAll("-", "");
                String transactionTime = sale_Values2.get(4).replaceAll(":", "");
                ExptranIdsale2 = transactionNbr.toString() + "-S" + storeNbr + "R" + registerId + "T" + transactionDate.toString() + transactionTime.toString();*/
            }

            if (saleNo == 3) {

                logger.info("sale_Values3  " + sale_Values3);
                /*String transactionNbr  = sale_Values3.get(0);
                String storeNbr        = sale_Values3.get(1);
                String registerId      = sale_Values3.get(2);
                String transactionDate = sale_Values3.get(3).replaceAll("-", "");
                String transactionTime = sale_Values3.get(4).replaceAll(":", "");

                ExptranIdsale3 = transactionNbr.toString() + "-S" + storeNbr + "R" + registerId + "T" + transactionDate.toString() + transactionTime.toString();*/
                ExptranIdsale3 = get_TransactionId_From_SaleMessage(kafka_Object3);

            }

            if (saleNo == 4) {

                logger.info("sale_Values4  " + sale_Values4);
                /*String transactionNbr  = sale_Values4.get(0);
                String storeNbr        = sale_Values4.get(1);
                String registerId      = sale_Values4.get(2);
                String transactionDate = sale_Values4.get(3).replaceAll("-", "");
                String transactionTime = sale_Values4.get(4).replaceAll(":", "");

                ExptranIdsale4 = transactionNbr.toString() + "-S" + storeNbr + "R" + registerId + "T" + transactionDate.toString() + transactionTime.toString();*/
                ExptranIdsale4 = get_TransactionId_From_SaleMessage(kafka_Object4);

            }

        }

        ExptranId = ExptranIdsale1 + "','" + ExptranIdsale2 + "','" + ExptranIdsale3 + "','" + ExptranIdsale4;

        logger.info("ExptranId ### " + ExptranId);
        Thread.sleep(15000);
        //Original transaction table
        String sql_originalTrans = consolidated_Sql.get(Rule_Replace_1233_Transaction_Table_query).getAsString();
        sql_originalTrans = sql_originalTrans.replace("Replace_transaction_id", ExptranId);
        logger.info("sql_originalTrans  ##  " + sql_originalTrans);
        ArrayList<List<String>> originalTransaction_table = execute_SQL_MySQL_DB_CRUD(sql_originalTrans);
        logger.info("originalTransaction_table " + originalTransaction_table);

        // Kohls cash table
        String sql_KohlsCash = consolidated_Sql.get(Rule_Replace_1233_kohls_cash_query).getAsString();
        sql_KohlsCash = sql_KohlsCash.replace("Replace_transaction_id", ExptranId);
        logger.info("sql_KohlsCash  ##  " + sql_KohlsCash);
        ArrayList<List<String>> KohlsCash_table = execute_SQL_MySQL_DB_CRUD(sql_KohlsCash);
        logger.info("KohlsCash_table " + KohlsCash_table);

        //earn_detail table

        String sql_earn_detail = consolidated_Sql.get(Rule_Replace_1233_earn_detail_query).getAsString();
        sql_earn_detail = sql_earn_detail.replace("Replace_transaction_id", ExptranId);
        logger.info("sql_earn_detail  ##  " + sql_earn_detail);
        ArrayList<List<String>> earn_detail_table = execute_SQL_MySQL_DB_CRUD(sql_earn_detail);
        logger.info("earn_detail_table " + earn_detail_table);

        for (int saleValue = 0; saleValue < 4; saleValue++) {
            for (int saleNum = 0; saleNum < 4; saleNum++) {
                ArrayList<String> sale_Values       = new ArrayList<>();
                JsonObject        validation_Object = new JsonObject();
                String            ExptranIdsale     = "";
                if (saleNum == 0) {
                    sale_Values.clear();
                    sale_Values = sale_Values1;
                    validation_Object = validation_Object1;
                    ExptranIdsale = ExptranIdsale1;
                } else
                    if (saleNum == 1) {
                        sale_Values.clear();
                        sale_Values = sale_Values2;
                        validation_Object = validation_Object2;
                        ExptranIdsale = ExptranIdsale2;
                    } else
                        if (saleNum == 2) {
                            sale_Values.clear();
                            sale_Values = sale_Values3;
                            validation_Object = validation_Object3;
                            ExptranIdsale = ExptranIdsale3;
                        } else
                            if (saleNum == 3) {
                                sale_Values.clear();
                                sale_Values = sale_Values4;
                                validation_Object = validation_Object4;
                                ExptranIdsale = ExptranIdsale4;
                            }


                logger.info(" ###########################3 validation for sale_Values " + sale_Values);
                //validation in KohlsCash_table
                logger.info("Outside IF  saleValue " + saleValue + " ExptranIdsale1 " + ExptranIdsale1);

                // validation in Original transaction table
                if (originalTransaction_table.get(saleValue).get(1).equals(ExptranIdsale)) {
                    assertEquals("OriginalTransaction_earnTrackerImpact not as expected", validation_Object.get("OriginalTransaction_earnTrackerImpact").toString().replaceAll("\"", ""), originalTransaction_table.get(saleValue).get(3).toString().replaceAll("\"", ""));
                    assertEquals("OriginalTransaction_KohlsCashImpact not as expected", validation_Object.get("OriginalTransaction_KohlsCashImpact").toString().replaceAll("\"", ""), originalTransaction_table.get(saleValue).get(4).toString().replaceAll("\"", ""));
                    assertEquals("OriginalTransaction_EveryDayUnearnedNonKCC not as expected", validation_Object.get("OriginalTransaction_EveryDayUnearnedNonKCC").toString().replaceAll("\"", ""), originalTransaction_table.get(saleValue).get(7).toString().replaceAll("\"", ""));
                }


                // validation in earn_detail_table
                if (earn_detail_table.get(saleValue).get(0).equals(ExptranIdsale)) {
                    assertEquals("earnDetail_EveryDayEarnedNonKCC not as expected", validation_Object.get("earnDetail_EveryDayEarnedNonKCC").toString().replaceAll("\"", ""), earn_detail_table.get(saleValue).get(2).toString().replaceAll("\"", ""));
                    assertEquals("earnDetail_EventEarned not as expected", validation_Object.get("earnDetail_EventEarned").toString().replaceAll("\"", ""), earn_detail_table.get(saleValue).get(3).toString().replaceAll("\"", ""));
                    assertEquals("earnDetail_ETammountApplied not as expected", validation_Object.get("earnDetail_ETammountApplied").toString().replaceAll("\"", ""), earn_detail_table.get(saleValue).get(4).toString().replaceAll("\"", ""));
                }

                if (saleValue < 2) {
                    if (KohlsCash_table.get(saleValue).get(1).equals(ExptranIdsale)) {
                        logger.info("saleValue111111 " + saleValue + " ExptranIdsale " + ExptranIdsale);
                        logger.info("### inside KohlsCash_table");
                        assertEquals("KohlsCash_barcode is not as expected", sale_Values.get(6).toString(), KohlsCash_table.get(saleValue).get(0).toString());
                        assertEquals("KohlsCash OriginalAmmountApplied is not as expected ", validation_Object.get("KohlsCash_OriginalAmmountApplied").toString().replaceAll("\"", ""), KohlsCash_table.get(saleValue).get(3).toString().replaceAll("\"", ""));
                    }

                }
            }
        }

    }


    //Scenario - 2 Steps


    @Given("Configuring event period as {string} for SaleOne and SaleTwo for {string} and {string}")
    public void configuring_event_period_as_for_SaleOne_and_SaleTwo(String arg1, String total_Sales, String rule_Payload) throws Exception {
        // Write code here that turns the phrase above into concrete actions
    	
    	/*pass_This.addProperty(Total_Loyalty_Ids_Needed, total_Sales);
        pass_This.addProperty(Reference_Payload, "Balance_Lookup_Payload_New_Loyalty_No_Points");
        this_Object = Generate_Pilot_Customers_With_New_Loyalty_IDs(pass_This);
        logger.info("Pilot is done");

        if(!rule_Payload.equals("") || rule_Payload.equals(null))
        {
	        this_Object.addProperty(Reference_Payload, rule_Payload);
	        post_New_Rule_Config(this_Object);
	        logger.info("Rule Config is done...");
        }*/

        configuring_event_period_as_for_Sale("", "4", rule_Payload, "");

    }

    @Given("Configuring event period as {string} for SaleThree and SaleFour")
    public void configuring_event_period_as_for_SaleThree_and_SaleFour(String arg1) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        logger.info("configuration is done....");
    }

    @Given("Performing SaleOne transactions for a customer with {string} and {string}")
    public void performing_SaleOne_transactions_for_a_customer_with(String arg1, String SaleName) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    	/*this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object1 = Post_Sales(this_Object);
        logger.info("Kafka Sale1 is done...");

        ArrayList<String> sale_Values1 = get_TransactionValues_From_SaleMessage(kafka_Object1);


        Todo @Review add Replace_transactionNbr/Replace_transactionDate/Replace_transactionTime as constant?
        additional_Object1.addProperty("Replace_transactionNbr", sale_Values1.get(0));
        additional_Object1.addProperty("Replace_transactionDate", sale_Values1.get(3));
        additional_Object1.addProperty("Replace_transactionTime", sale_Values1.get(4));
        if (kafka_Object1.toString().contains("barcode"))
            additional_Object1.addProperty("Replace_barcode", sale_Values1.get(6));*/
        performing_numberOne_transactions_for_a_customer_with("", "", SaleName);
    }

    @Given("Performing SaleTwo transactions for a customer with {string} and {string}")
    public void performing_SaleTwo_transactions_for_a_customer_with(String arg1, String SaleName) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        
    	/*this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_1").getAsString());
        kafka_Object2 = Post_Sales(this_Object);
        logger.info("Kafka Sale2 is done...");

        ArrayList<String> sale_Values2 = get_TransactionValues_From_SaleMessage(kafka_Object2);

        additional_Object2.addProperty("Replace_transactionNbr", sale_Values2.get(0));
        additional_Object2.addProperty("Replace_transactionDate", sale_Values2.get(3));
        additional_Object2.addProperty("Replace_transactionTime", sale_Values2.get(4));
        if (kafka_Object2.toString().contains("barcode"))
            additional_Object2.addProperty("Replace_barcode", sale_Values2.get(6));*/
        performing_numberTwo_transactions_for_a_customer_with_and("", "", SaleName);
    }

    @Given("Performing SaleThree transactions for a customer with {string} and {string}")
    public void performing_SaleThree_transactions_for_a_customer_with(String arg1, String SaleName) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        
    	/*this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_2").getAsString());
        kafka_Object3 = Post_Sales(this_Object);
        logger.info("Kafka Sale3 is done...");

        ArrayList<String> sale_Values3 = get_TransactionValues_From_SaleMessage(kafka_Object3);

        additional_Object3.addProperty("Replace_transactionNbr", sale_Values3.get(0));
        additional_Object3.addProperty("Replace_transactionDate", sale_Values3.get(3));
        additional_Object3.addProperty("Replace_transactionTime", sale_Values3.get(4));
        if (kafka_Object3.toString().contains("barcode"))
            additional_Object3.addProperty("Replace_barcode", sale_Values3.get(6));*/
        performing_numberThree_transactions_for_a_customer_with_and("", "", SaleName);
    }

    @Given("Performing SaleFour transactions for a customer with {string} and {string}")
    public void performing_SaleFour_transactions_for_a_customer_with(String arg1, String SaleName) throws Exception {
        // Write code here that turns the phrase above into concrete actions
    	/*this_Object.addProperty(Reference_Payload, SaleName);
        this_Object.addProperty("Replace_Loyalty_Id", this_Object.get("Generic_Loyalty_Id_3").getAsString());
        kafka_Object4 = Post_Sales(this_Object);
        logger.info("Kafka Sale4 is done...");
        logger.info("__");

        ArrayList<String> sale_Values4 = get_TransactionValues_From_SaleMessage(kafka_Object4);

        additional_Object4.addProperty("Replace_transactionNbr", sale_Values4.get(0));
        additional_Object4.addProperty("Replace_transactionDate", sale_Values4.get(3));
        additional_Object4.addProperty("Replace_transactionTime", sale_Values4.get(4));
        if (kafka_Object4.toString().contains("barcode"))
            additional_Object4.addProperty("Replace_barcode", sale_Values4.get(6));*/
        performing_numberFour_transactions_for_a_customer_with_and("", "", SaleName);

    }

    @When("the customer makes multi-receipted {string} for each of the Sales Transaction scenarioTwo and {string} {string} {string} {string}")
    public void the_customer_makes_multi_receipted_for_each_of_the_Sales_Transaction(String returnType, String Return1Name, String Return2Name, String Return3Name, String Return4Name) throws Exception {
        // Write code here that turns the phrase above into concrete actions
    	/*additional_Object1.addProperty(Reference_Payload, Return1Name);
        additional_Object2.addProperty(Reference_Payload, Return2Name);
        additional_Object3.addProperty(Reference_Payload, Return3Name);
        additional_Object4.addProperty(Reference_Payload, Return4Name);

        Todo @Review add Generic_Loyalty_Id as constant?
        additional_Object1.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_0").getAsString());
        kafka_Object5 = Post_Return(additional_Object1);
        logger.info("Post Return1 is done...");

        ArrayList<String> sale_Values5 = get_TransactionValues_From_SaleMessage(kafka_Object5);
        additional_Object2.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object2.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object2.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_1").getAsString());
        kafka_Object6 = Post_Return(additional_Object2);

        logger.info("Post Return2 is done...");

        additional_Object3.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object3.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object3.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_2").getAsString());
        kafka_Object7 = Post_Return(additional_Object3);

        logger.info("Post Return3 is done...");

        additional_Object4.addProperty("Replace_Constant_transactionNbr", sale_Values5.get(0));
        additional_Object4.addProperty(Refer_Rule_Replace_MessageId, sale_Values5.get(5));
        additional_Object4.addProperty(Refer_Rule_Replace_Loyalty_Id, this_Object.get("Generic_Loyalty_Id_3").getAsString());
        kafka_Object8 = Post_Return(additional_Object4);
        
        logger.info("Post Return4 is done...");*/
        the_customer_makes_multi_receipted_for_each_of_the_Sales_Transaction_and(returnType, Return1Name, Return2Name, Return3Name, Return4Name);
    }


    //Scenario - 3 Steps

    @Given("Configuring event period as {string} for SaleOne and SaleTwo for rule {string}")
    public void configuring_event_period_as_for_SaleOne_and_SaleTwo(String arg1, String rule_Payload) throws Throwable {

        configuring_event_period_as_for_Sale("", "4", rule_Payload, "");
    }

    @Given("Performing SaleOne transactions for a customer with {string} for {string}")
    public void performing_sc3_SaleOne_transactions_for_a_customer_with(String arg1, String SaleName) throws Throwable {

        performing_numberOne_transactions_for_a_customer_with("", "", SaleName);
    }

    @Given("Performing SaleTwo transactions for a customer with {string} for {string}")
    public void performing_sc3_SaleTwo_transactions_for_a_customer_with(String arg1, String SaleName) throws Throwable {

        performing_numberTwo_transactions_for_a_customer_with_and("", "", SaleName);
    }

    @Given("Performing SaleThree transactions for a customer with {string} for {string}")
    public void performing_sc3_SaleThree_transactions_for_a_customer_with(String arg1, String SaleName) throws Throwable {

        performing_numberThree_transactions_for_a_customer_with_and("", "", SaleName);
    }

    @Given("Performing SaleFour transactions for a customer with {string} for {string}")
    public void performing_sc3_SaleFour_transactions_for_a_customer_with(String arg1, String SaleName) throws Throwable {

        performing_numberFour_transactions_for_a_customer_with_and("", "", SaleName);
    }

    @When("the customer makes multi-receipted {string} for each of the Sales Transaction scenarioThree and {string} {string} {string} {string}")
    public void the_customer_makes_scenario3_multi_receipted_for_each_of_the_Sales_Transaction(String returnType, String Return1Name, String Return2Name, String Return3Name, String Return4Name) throws Throwable {

        the_customer_makes_multi_receipted_for_each_of_the_Sales_Transaction_and(returnType, Return1Name, Return2Name, Return3Name, Return4Name);
    }

}
