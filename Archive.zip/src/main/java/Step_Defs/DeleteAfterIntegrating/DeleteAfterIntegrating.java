package Step_Defs.DeleteAfterIntegrating;

import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.net.URL;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.*;


public class DeleteAfterIntegrating {

    protected static final Logger logger = get_Logger();


    @Given("I Logged in to a website and did some operations")
    public void i_Logged_in_to_a_website_and_did_some_operations() throws Throwable {

        final String fbContent                    = "fbContent";
        String       tibco_user_Name              = "sundari.samuthirapandi@kohls.com";
        String       tibco_password_Value         = "Rt21PcrGhb5sZQsi13+Ezg==";
        String       aaa                          = decrypt_Pwd(tibco_password_Value);
        String       tibco_Login_Wrapper          = "//div[contains(@id,'loginWrapper')]";
        String       tibco_user_Name_Locator      = tibco_Login_Wrapper + "//input[contains(@name, 'UserName') and contains(@id,'UserName')]";
        String       tibco_password_Value_Locator = tibco_Login_Wrapper + "//input[contains(@name, 'Password') and contains(@id,'Password')]";
        String       tibco_Login_Button_Locator   = tibco_Login_Wrapper + "//input[contains(@name, 'Login')    and @type='submit']";
        String       tibco_Url                    = project_Parameters.get("tibCo_Url").getAsString();
        System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir") + "/src/main/resources/Drivers_Check_If_Fine_Jenkins/geckodriver");
        WebDriver driver1 = new FirefoxDriver();

        // And now use this to visit Google
        driver1.get("http://www.google.com");

        WebDriver    driver                       = get_WebDriver();
        driver.navigate().to(new URL(tibco_Url));
        driver.findElement(By.ByXPath.xpath(tibco_user_Name_Locator)).sendKeys(tibco_user_Name);
        driver.findElement(By.ByXPath.xpath(tibco_password_Value_Locator)).sendKeys(decrypt_Pwd(tibco_password_Value));
        driver.findElement(By.ByXPath.xpath(tibco_Login_Button_Locator)).click();

        String search_Criteria_Form                     = "//div[contains(@id, 'search_shoppers')]";
        String search_Criteria_Form_Item                = search_Criteria_Form + "//div[contains(@class, 'formItem')]";
        String search_Criteria_Butn_Item                = search_Criteria_Form + "//div[contains(@class, 'btns')]";
        String search_Criteria_Loyalty_Id_Locator       = search_Criteria_Form_Item + "//input[contains(@name, 'CardNumber')     and contains(@id,'CardNumber')    ]";
        String search_Criteria_LyltyId_DpDwn_Locator    = search_Criteria_Form_Item + "//select[contains(@name, 'CardOption')    and contains(@id,'CardOption')    ]";
        String search_Criteria_Transcn_Id_Locator       = search_Criteria_Form_Item + "//input[contains(@name, 'TransactionId')  and contains(@id,'TransactionId') ]";
        String search_Criteria_Phone_No_Locator         = search_Criteria_Form_Item + "//input[contains(@name, 'PhoneNumber')    and contains(@id,'PhoneNumber')   ]";
        String search_Criteria_Zip_Code_Locator         = search_Criteria_Form_Item + "//input[contains(@name, 'Zip')            and contains(@id,'Zip')           ]";
        String search_Criteria_Last_Name_Locator        = search_Criteria_Form_Item + "//input[contains(@name, 'LastName')       and contains(@id,'LastName')      ]";
        String search_Criteria_Email_Locator            = search_Criteria_Form_Item + "//input[contains(@name, 'Email')          and contains(@id,'Email')         ]";
        String search_Criteria_Activ_Stat_Locator       = search_Criteria_Form_Item + "//input[contains(@name, 'Active')        and contains(@id,'Active')    ]";
        String search_Criteria_InActiv_Stat_Locator     = search_Criteria_Form_Item + "//input[contains(@name, 'Inactive')      and contains(@id,'Inactive')  ]";
        String search_Criteria_LoyMemb_Enrlld_Locator   = search_Criteria_Form_Item + "//input[contains(@name, 'Enrolled')      and contains(@id,'Enrolled')  ]";
        String search_Criteria_LoyMemb_UnEnrlld_Locator = search_Criteria_Form_Item + "//input[contains(@name, 'Unenrolled')    and contains(@id,'Unenrolled')]";
        String search_Criteria_Btn_Search_Locator       = search_Criteria_Butn_Item + "//a[ contains(@id,'Search')               and contains(.//span, 'Search') ]";
        String search_Criteria_Btn_Reset_Locator        = search_Criteria_Butn_Item + "//a[ contains(@class, 'btn')              and contains(.//span, 'Reset')  ]";
        String search_Results_Expnd_Btn_Locator         = "//input[ @type='submit'                   and contains(@id, 'BtnExpandColumn') ]";
        String search_Results_Action_Bar                = "//div[contains(@class, 'ActionBar')]/ul[contains(@class, 'ActionBar')]";
        String search_Results_Adj_Pts_Locator           = search_Results_Action_Bar + "/li/a[contains(@class, 'AdjustPoints')   ]/span[contains(text(),'Adjust Points')]";
        String search_Results_Vw_Dtls_Locator           = search_Results_Action_Bar + "/li/a[contains(@class, 'ViewDetails')    ]/span[contains(text(),'View Details')]";
        String search_Results_Ed_Info_Locator           = search_Results_Action_Bar + "/li/a[contains(@class, 'EditInfo')       ]/span[contains(text(),'Edit Info')]";
        String search_Results_Merge_Locator             = search_Results_Action_Bar + "/li/a[contains(@class, 'Merge')          ]/span[contains(text(),'Merge')]";
        String search_Results_Chg_Sta_Locator           = search_Results_Action_Bar + "/li/a[contains(@class, 'ChangeStatus')   ]/span[contains(text(),'Change Status')]";
        String points_Add_Iframe_Locator                = "//iframe";
        String points_Add_Select_Locator                = "//select[  contains(@id, 'adjusttype')                     ]"; //and ancestor::iframe
        String points_Add_Select_Value_Locator          = "//input[   contains(@id, 'adjust_shopper_points')          ]";
        String points_Reason_Select_Locator             = "//select[  contains(@id, 'Reason')                         ]";
        String points_Next_Btn_Locator                  = "//a[  contains(@id, 'next')      ]/span[contains(text(),'Next')]";
        String points_Cnfrm_Btn_Locator                 = "//a[  contains(@id, 'confirm')   ]/span[contains(text(),'Confirm')]";
        String points_Done_Btn_Locator                  = "//a[  contains(@id, 'Done')      ]/span[contains(text(),'Done')]";

        //This is example for VerifyPoints inside Tesnt Ng code -- @Step("Step: Verify the points in CSR")
        String search_Results_Table_Locator           = "//table[contains(@id, 'SearchResults')]";
        String search_Results_Avlb_Points_Row_Locator = "//tr[ td/strong[ contains(text(),'Available') and contains(text(),'Points') ]  ] ";
        String search_Results_Avlb_Points_Val_Locator = search_Results_Table_Locator + search_Results_Avlb_Points_Row_Locator + "/td[ not( .//strong ) ]";


        //Todo Overall wait strategy needs to be adopted.
        driver.findElement(By.ByXPath.xpath(search_Criteria_Btn_Reset_Locator)).click();
        driver.findElement(By.ByXPath.xpath(search_Criteria_Loyalty_Id_Locator)).sendKeys("81136792298");
        driver.findElement(By.ByXPath.xpath(search_Criteria_Btn_Search_Locator)).click();
        Thread.sleep(1000);//Todo Remove this and add waits.


        driver.findElement(By.ByXPath.xpath(search_Results_Expnd_Btn_Locator)).click();
        Thread.sleep(1000);//Todo Remove this and add waits.


        /*driver.findElement(By.ByXPath.xpath(search_Results_Adj_Pts_Locator)).click(); Thread.sleep(4000);//Todo Remove this and add waits.


        //driver.switchTo().frame(driver.findElement(By.ByXPath.xpath(points_Add_Iframe_Locator)));
        driver.switchTo().frame(fbContent);
        driver.findElement(By.ByXPath.xpath(points_Add_Select_Locator)).sendKeys("Add");
        driver.findElement(By.ByXPath.xpath(points_Add_Select_Value_Locator)).sendKeys("6181");
        driver.findElement(By.ByXPath.xpath(points_Reason_Select_Locator)).sendKeys("Adjustment");

        driver.findElement(By.ByXPath.xpath(points_Next_Btn_Locator)).click(); Thread.sleep(1000);//Todo Remove this and add waits.
        driver.findElement(By.ByXPath.xpath(points_Cnfrm_Btn_Locator)).click(); Thread.sleep(1000);//Todo Remove this and add waits.
        driver.findElement(By.ByXPath.xpath(points_Done_Btn_Locator)).click(); Thread.sleep(1000);//Todo Remove this and add waits.
        driver.switchTo().defaultContent();*/

        String avlb_Points_Value = driver.findElement(By.ByXPath.xpath(search_Results_Avlb_Points_Val_Locator)).getText();


    }


}
