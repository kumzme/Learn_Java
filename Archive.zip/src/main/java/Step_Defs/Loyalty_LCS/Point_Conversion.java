package Step_Defs.Loyalty_LCS;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Service_Functions.Check_Where_V2_Or_V1_Validation_Methods.pc_Response_Validation;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.LPF_Invoker_Utilities.create_Clean_Directory;
import static org.junit.Assert.assertEquals;


public class Point_Conversion {

    protected static final Logger logger = get_Logger();

    SimpleDateFormat sdf1;
    private Map raw_Headers, loyaltyMap, barcodeMap, mapped_Payload;
    private JsonObject response_From_Api, response_From_Api2;
    private String service_Name, service_Path, lbl_base_Url, lcs_base_Url, rule_base_Url, full_Url, raw_Payload, l_id;
    private        String  loyalty_Id;
    private static boolean got_Parms = false;

    //  JsonObject store_Data1 = new Gson().fromJson("{}", JsonObject.class);
    private Map store_Data_loy = new Gson().fromJson("{}", Map.class);
    JsonObject store_Data = new JsonObject();


    private String service_Payload, service_Uri, name_Space, service_Port;
    private Document xml_Doc;



    /*@Before
    public void setUpForLoyalty_Steps(Scenario Loyalty_Lcs) throws Exception{
        String scenario                         = Loyalty_Lcs.getName(); // Samples
        logger.info(scenario);
    }*/

    @Given("I am able to retrieve and set the project environment data for PointConversion")
    public void setUpForLoyalty_Steps() throws Exception {
        if (got_Parms == false) {
            this.got_Parms = true;
            create_Clean_Directory();
        }

        lbl_base_Url = project_Parameters.get("LBLEndpoint").getAsString();
        lcs_base_Url = project_Parameters.get("LCSEndpoint").getAsString();
        rule_base_Url = project_Parameters.get("RulesEndpoint").getAsString();
    }


    /* @Given("I am connected with Dkc_Service: {string}") public void i_am_connected_with_Dkc_Service(String arg1) throws Throwable { if (arg1.equalsIgnoreCase("Dkc_Service")){ this.service_Payload    = Payload_DKC;
    //Todo - Put in Data - Ram
    this.service_Uri        = DKC_Endpoint_Uri;
    //Todo - Put in Profile Yaml Ram } } //Todo pass other xml parameters also
    @When("I create the payload with Amount: {string}, and Event_Id: {string}") public void i_create_the_payload_with_Amount_and_Event_Id(String amount, String event_Id) throws Exception { this.service_Payload = Payload_DKC  .replace("replace_Amount",      amount) .replace("replace_Event_Id",    event_Id); } @Then("I {string} to DKC service with {string} format, for DKC Service Name Space: {string} and DKC_Service_Name {string} and DKC_Service_Port: {string}") public void i_to_DKC_service_with_format_for_DKC_Service_Name_Space_and_DKC_Service_Name_and_DKC_Service_Port(String soap, String format, String namespace, String service_Name, String service_Port) throws Throwable { if (namespace.equalsIgnoreCase("DKC_namespace"))        this.name_Space = DKC_Namespace; if (service_Name.equalsIgnoreCase("DKC_Service_Name"))  this.service_Name = DKC_Service_Name; if (service_Port.equalsIgnoreCase("DKC_Service_Port"))  this.service_Port = DKC_Service_Port; String response                     =  soap_Client(this.service_Payload, this.service_Uri,this.name_Space, this.service_Name, this.service_Port); this.xml_Doc                        = convert_Soap_Response_To_XML_Doc(response); logger.info(xml_Doc); } @Then("I should be able to verify the Response as {string} for DKC Web Service, TC {string}") public void i_should_be_able_to_verify_the_Response_as_for_DKC_Web_Service(String return_Code, String TC) throws Throwable { String pin                          = xml_Doc.getElementsByTagName("PIN").item(0).getTextContent(); String barCode                      = xml_Doc.getElementsByTagName("Barcode").item(0).getTextContent(); String rc                           = xml_Doc.getElementsByTagName("Status").item(0).getTextContent(); barcodeMap.put(TC, barCode); Assert.assertEquals(Integer.parseInt(return_Code),Integer.parseInt(rc)); }*/


    @Given("I am connected with {string}")
    public void i_am_connected_with_Service(String service_NameFrom_Feature) throws Throwable {

        service_Name = service_NameFrom_Feature;

    }

    @Given("I can check this and see if it works only for conversion")
    public void i_can_check_this_Conv() throws Throwable {
        JsonObject aa = consolidated_Data;
    }


    @Given("I can check this and see if it works only")
    public void i_can_check_this() throws Throwable {
        String full_File = get_Run_Data_Store_Folders() + "/" + "DKC_Generated_Bar_Code.yaml";
        Map    aa        = read_Yaml(full_File);
        logger.info(aa);
    }


    @When("I create the payload with totalEarnTracker: {string}, TotalPendingBalance: {string}, Scenario: {string} for {string} and {string}")
    public void i_create_the_payload_for_Lcs_Loyalty_Put_Service(String totalEarnTracker, String TotalPendingBalance, String Key_for_Store, String file_Name_bc, String file_Name_loy) throws Throwable {


        sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

        loyalty_Id = generateLoyaltyId();
//        store_Data.addProperty(Key_for_Store, loyalty_Id);
        store_Data_loy.put(Key_for_Store, loyalty_Id);
        String full_File_loy = get_Run_Data_Store_Folders() + "/" + file_Name_loy;
        store_Scenario_Data(full_File_loy, store_Data_loy);

        //    loyaltyMap.put(Key_for_Store, loyalty_Id);
        String barcode = (read_Yaml(get_Run_Data_Store_Folders() + "/" + file_Name_bc)).get(Key_for_Store).toString();
        String loyId   = (read_Yaml(get_Run_Data_Store_Folders() + "/" + file_Name_loy)).get(Key_for_Store).toString();

        logger.info("The barcode before hitting is **** " + barcode);
        logger.info("The loyaltyId before hitting is **** " + loyId);

        raw_Payload = consolidated_Data.get("Payload_Template_For_Put_Balances_Service").getAsString();
        raw_Payload = raw_Payload.replace("replace_loyaltyId", loyalty_Id)
                .replace("replace_totalEarnTracker", totalEarnTracker)
                .replace("replace_totalPendingBalance", TotalPendingBalance)
                .replace("replace_pendingBarcode", barcode)
                .replace("replace_pendingExpirationDate", sdf1.format(new Date()));

        mapped_Payload = convert_String_To_Map(raw_Payload);
        logger.info("The payload is: " + mapped_Payload);
    }

    @Then("I {string} to Balances service with {string} format, with headers {string} and  {string} and {string}")
    public void i_POST_with_given_format_and_headers(String method_Name, String format, String XKOHLS_From_System_Code, String XKOHLS_Correlation_ID, String XKOHLS_Message_ID) throws Exception {


        service_Path = "/" + this.service_Name + "/" + loyalty_Id;
        String requestTimestamp    = generate_Header_Date_TS();
        String encoded_Auth_String = getSignature(raw_Payload, service_Path, XKOHLS_Message_ID, method_Name, requestTimestamp);
        /*Todo Check what is needed*/
        //raw_Headers                                    = (Map) this.lcs_Data.get("Header_Template_For_Rest");
        /*raw_Headers.put(Authorization,                  encoded_Auth_String);
        raw_Headers.put(X_KOHLS_CreateDateTime,         requestTimestamp);
        raw_Headers.put(X_KOHLS_MessageID,              XKOHLS_Message_ID);        //Todo Reference Constants
        raw_Headers.put(X_KOHLS_CorrelationID,          XKOHLS_Correlation_ID);
        raw_Headers.put(X_KOHLS_From_SystemCode,        XKOHLS_From_System_Code);

        if(format.equalsIgnoreCase("json")){
            raw_Headers.put("Accept", "application/json");
            raw_Headers.put("Accept-Language", "it-IT,it"); //Todo Direct Constant
            raw_Headers.put("Content-Type", "application/json");
        }*/

        this.raw_Headers = generate_Header("Header_Template_For_Rest", requestTimestamp, "LYB", XKOHLS_Message_ID, "1235", "put", encoded_Auth_String);
        full_Url = this.lbl_base_Url + service_Path;
        logger.info("The LBL URL is: " + full_Url);
        logger.info("The header of LBL is: " + raw_Headers);
        response_From_Api2 = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, method_Name);
        logger.info("Put Balances response :" + response_From_Api2);

    }

    @Then("I should be able to verify the Response as {string} for Put Balances service")
    public void i_should_be_able_to_verify_the_Response_as(String success_Or_Fail) throws Throwable {
        logger.info("___01 Loyalty _04");

        assertEquals(success_Or_Fail, response_From_Api2.get("Response_Code").toString());
//        assertEquals(mapped_Payload.get("totalPendingBalance").toString(), response_From_Api2.get("totalPendingBalance").toString());
//        assertEquals(mapped_Payload.get("totalEarnTracker").toString(),response_From_Api2.get("totalEarnTracker").toString());
        //    assertEquals(response_From_Api2.get("pendingBarcode").toString(),        mapped_Payload.get("pendingBarcode").toString());

    }

    @When("I create the payload with pointsToConvert: {string}, TC: {string}")
    public void i_create_the_payload_with_pointsToConvert(String pointsToConvert, String TC) throws Throwable {

        String loyId = (read_Yaml(get_Run_Data_Store_Folders() + "/" + "Generated_loyaltyId.yaml")).get(TC).toString();
        // String loyID = (String) loyaltyMap.get(TC); //Todo Check conversion
        sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        raw_Payload = consolidated_Data.get("Payload_Template_For_Post_PointConversion_Service").getAsString();
        raw_Payload = raw_Payload.replace("replace_loyaltyId", loyId).replace("replace_pointsToConvert", pointsToConvert);
        mapped_Payload = convert_String_To_Map(raw_Payload);

    }


    @Then("I {string} to {string} with {string} format, with headers {string} and  {string} and  {string}")
    public void i_POST_to_with_format_with_headers_and_and(String api_Method, String service_Name, String format, String XKOHLS_From_System_Code, String XKOHLS_Correlation_ID, String XKOHLS_Message_ID) throws Throwable {
        logger.info("___01 Loyalty _05");
        service_Path = "/" + this.service_Name;
        logger.info("The payload is: " + raw_Payload);
        String method_name = "POST";
        //Todo Check if it will error out
        raw_Headers = (Map) consolidated_Data.get("Header_Template_For_Rest");

        // raw_Headers.put(Authorization,                  encoded_Auth_String);
        /*
        raw_Headers.put(X_KOHLS_CreateDateTime,         new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date()));
        raw_Headers.put(X_KOHLS_MessageID,              XKOHLS_Message_ID);        //Todo Reference Constants
        raw_Headers.put(X_KOHLS_CorrelationID,          XKOHLS_Correlation_ID);
        raw_Headers.put(X_KOHLS_From_SystemCode,        XKOHLS_From_System_Code);

        if(api_Method.equalsIgnoreCase("post")){
            raw_Headers.put("Accept", "application/json");
            raw_Headers.put("Accept-Language", "it-IT,it"); //Todo Direct Constant
            raw_Headers.put("Content-Type", "application/json");
        }*/

        String requestTimestamp    = generate_Header_Date_TS();
        String encoded_Auth_String = getSignature(raw_Payload, this.service_Path, XKOHLS_Message_ID, "Post", requestTimestamp);
        this.raw_Headers = generate_Header("Header_Template_For_Rest", requestTimestamp, "LCS", XKOHLS_Message_ID, "1235", "put", encoded_Auth_String);
        full_Url = this.lcs_base_Url + service_Path;
        logger.info("The full URL of PointConversion is **** " + full_Url);
        Thread.sleep(2000);
        response_From_Api = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, api_Method);
        logger.info("************Post Point Conversion response **** " + response_From_Api);
    }

    @Then("I should be able to verify the Response as {string} against payload sent with pointsToConvert: {string} and totalEarnTracker: {string}")
    public void i_should_be_able_to_verify_the_Response_as_against_payload(String success_fail_code, String pointsToConvert, String totalEarnTracker) throws Throwable {
        logger.info("___01 Loyalty _06");

        Map<String, String> pcMap = pc_Response_Validation(pointsToConvert, totalEarnTracker);

        logger.info("The value of is EarnTrackerDelta: " + response_From_Api.get("earnTrackerDelta") + " The value from calculation is: " + pcMap.get("earnTrackerDelta")); //pcResBean.getEarnTrackerDelta());

        assertEquals("Mismatch of convertedKcAmt expected: " + pcMap.get("convertedKcAmt").toString(), pcMap.get("convertedKcAmt").toString(), response_From_Api.get("convertedKcAmt").toString());
        assertEquals("Mismatch of EarnTrackerDelta expected: " + pcMap.get("earnTrackerDelta").toString(), pcMap.get("earnTrackerDelta").toString(), response_From_Api.get("earnTrackerDelta").toString());
        assertEquals("Mismatch of updatedEarnTrackerBal expected: " + pcMap.get("updatedEarnTrackerBal").toString(), pcMap.get("updatedEarnTrackerBal").toString(), response_From_Api.get("updatedEarnTrackerBal").toString());
        assertEquals("Mismatch of spendAwayEverydayNonKcc expected: " + pcMap.get("spendAwayEverydayNonKcc").toString(), pcMap.get("spendAwayEverydayNonKcc").toString(), response_From_Api.get("spendAwayEverydayNonKcc").toString());



	    /*		Softly.assertEquals("Mismatch of EarnTrackerDelta expected: " + pcMap.get("earnTrackerDelta"),
				pcMap.get("earnTrackerDelta"), pcResBean.getEarnTrackerDelta());*/

    }


    @After
    public void doSomethingAfter(Scenario Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF) throws Exception {
        String   scenario      = Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF.getName(); // Samples
        String[] expectedArray = {"one", "two", "three"};
        String[] resultArray   = {"one", "two", "three", "0"};

        //Check that two objects are equal
        //assertEquals(expectedArray, resultArray);

        //throw  new Exception("__");
    }


}
