package Step_Defs.Loyalty_PreTender;

import Utilities.Date_Util;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static Utilities.UtilConstants.Response_Code;
import static org.junit.Assert.assertEquals;


public class LCSPreTender {

    protected static final Logger logger = get_Logger();


    String sdf1; 
    private Map raw_Headers,raw_Headers_get, rule_config;
    private JsonObject response;
    private String loyalty_Id,version;
    private String service_Name, service_Path, raw_Payload_get,pilot_base_Url, full_Url, raw_Payload, XKohls_Message_ID, secretKey, sys_Cd, corr_Id, message_Hdr, method_Name;
    private static boolean got_Parms = false;
    Date_Util dateUtil = new Date_Util();


    @Given("I am able to retrieve and set the project environment data for LCSPreTender")
    public  void setUpFor_Rule_Config_Steps() throws Exception {

        logger.info("project_Options " + project_Parameters);
    }
    
  //  Given I am connected with <PreTender> service to <ENDPOINT> for <Test_Case_No> type for LCSPretender
  //  When I <Provide> to SpendTracker type with <Given_Format> format, with headers  <Standard_Post_Header> for <XKOHLS_From_System_Code> and  <XKOHLS_Correlation_ID> and  <XKOHLS_Message_ID> and <secretKey>
  //  Then I have create the payload for PreTender with localtyID as <LoyaltyID>, department as <Department>, sku as <SKU>, netPrice as <NetPrice>, quantity as <Quantity> for payload as <PreTenderHeader>
  //  Then I should be able to verify the SpendTracker Response as <Success_Response> and everydayKccPercentage as <keyeverydayEarnKcc> and everydayNonKccPercentage as <keyeverydayEarnNonKcc> and eventKohlsCashEarn as <keyeventKohlsCashEarn> and eventKohlsCashEarnTol as <keyeventKohlsCashEarnTol> and spendAwayEvent as <keyspendAwayEvent>
  
    /*
     * Pre Tender starts
     */


    @Given("I am connected with {string} service to {string} for {string} type for LCSPretender")
    public void i_am_connected_with_Service(String service_NameFrom_Feature,String endpoint, String testCase) throws Exception {
        service_Name                            = service_NameFrom_Feature;
        this.pilot_base_Url                     = project_Parameters.get(endpoint).getAsString();
        logger.info("service_Name "+service_Name +" for testcase +"+testCase);
    }

    @When("I {string} to PreTender type with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
    public void formatHeaderPreTender(String methodType, String format, String standard_Post_Header, String xKOHLS_From_System_Code, String xKOHLS_Correlation_ID, String xKOHLS_Message_ID, String secretKey) throws Exception {
        this.service_Path                      = "/" + this.service_Name ;
        logger.info("xKOHLS_Correlation_ID " + xKOHLS_Correlation_ID);
        logger.info("xKOHLS_Message_ID " + xKOHLS_Message_ID);
        this.sdf1                              = generate_Header_Date_TS();
        this.XKohls_Message_ID                 = xKOHLS_Message_ID  ;
        this.secretKey                         = secretKey  ;
        this.corr_Id                           = xKOHLS_Correlation_ID  ;
        this.sys_Cd                            = xKOHLS_From_System_Code  ;
        this.message_Hdr                       = standard_Post_Header;
        this.method_Name                       = methodType;
        logger.info("corr_Id " + corr_Id);
        logger.info("XKohls_Message_ID " + XKohls_Message_ID);
        
        
    }

    @Then("I have create the payload for PreTender with localtyID as {string}, department as {string}, sku as {string},"
          + " netPrice as {string}, quantity as {string} for payload as {string}")
    public void I_Post_PayloadPreTender_LoyaltyID(String localtyID,String department,String sku,String netPrice,String quantity,String payload) throws Exception {
  	  

   	  loyalty_Id 	= 			localtyID;
   
  	  raw_Payload = consolidated_Data.get(payload).getAsString();
          raw_Payload =   raw_Payload.replace("replace_loyaltyId", loyalty_Id)
        		  .replace("replace_department", department)
        		  .replace("replace_sku", sku)
        		  .replace("replace_netPrice", netPrice)
        		  .replace("replace_quantity", quantity);

        logger.info("The payload is: " + raw_Payload);

           String encoded_Auth_String      = getSignatureForPOSTCallSpendTrackerMash(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);
      
           this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);

        logger.info("The raw_headers url for PreTender is: " + this.raw_Headers);
          full_Url                        = this.pilot_base_Url + service_Path;
        logger.info("The full url is: " + full_Url);

          response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

        logger.info("The response of PreTender: " + response);
        logger.info("The response Code of PreTender:'\n' " + response.get(Response_Code));
          logger.info(response.get(Response_Code));

      }

    @Then("I should be able to verify the LCSPreTender Response as {string} and everydayEarnKcc as {string} and everydayEarnNonKcc as {string} and eventKohlsCashEarn as {string} and eventKohlsCashEarnTol as {string} and spendAwayEvent as {string}")
    public void verifyPreTender(String success_Or_Fail, String everydayEarnKcc, String everydayEarnNonKcc, String eventKohlsCashEarn, String eventKohlsCashEarnTol, String spendAwayEvent) throws Throwable {
    	
    	assertEquals(success_Or_Fail, response.get("Response_Code").toString());
          logger.info("everydayKccPercentage " + ((JsonObject) response.get("Response_Body")).get("everydayEarnKcc"));
          logger.info("everydayKccPercentage " + response.get("Response_Body"));
         assertEquals("everydayEarnKcc is not as expected.",everydayEarnKcc.toString(), ((JsonObject) response.get("Response_Body")).get("everydayEarnKcc").toString());
         assertEquals("everydayEarnNonKcc is not as expected.",everydayEarnNonKcc.toString(),((JsonObject) response.get("Response_Body")).get("everydayEarnNonKcc").toString());
         assertEquals("eventKohlsCashEarn is not as expected.",eventKohlsCashEarn.toString(), ((JsonObject) response.get("Response_Body")).get("eventKohlsCashEarn").toString());
         assertEquals("eventKohlsCashEarnTol is not as expected.",eventKohlsCashEarnTol.toString(),((JsonObject) response.get("Response_Body")).get("eventKohlsCashEarnTol").toString());
         assertEquals("spendAwayEvent is not as expected.",spendAwayEvent.toString(), ((JsonObject) response.get("Response_Body")).get("spendAwayEvent").toString());
     // NEED TO WRITE LOGIN TO GET RULECONFIG DATES AND VERIFY THOSE DATES- STORY IT IN CONSTANT FILE WHICH CAN BE USED EVERYTIME  
    	
    }
    
 /* 
   * Spend Tracker Starts 
   
  //I <Provide> to SpendTracker type with <Given_Format> format, with headers  <Standard_Post_Header> for <XKOHLS_From_System_CodeSpend> and  <XKOHLS_Correlation_IDSpend> and  <XKOHLS_Message_IDSpend> and <secretKeySpend>
  
  @When("I {string} to SpendTracker type with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
  public void formatHeaderSpendTracker(String methodType, String format, String standard_Post_Header, String xKOHLS_From_System_Code, String xKOHLS_Correlation_ID, String xKOHLS_Message_ID, String secretKey) throws Exception {
      this.service_Path                      = "/" + this.service_Name ;
    //  raw_Headers = (Map) this.lcs_Data.get("Header_Template_For_Rest");
      //Header_Template_For_Rest
      //Todo @TEAM logic
      logger.info("xKOHLS_Correlation_ID "+xKOHLS_Correlation_ID);
      logger.info("xKOHLS_Message_ID "+xKOHLS_Message_ID);
      this.sdf1                              = generate_Header_Date_TS();
      this.XKohls_Message_ID                 = xKOHLS_Message_ID  ;
      this.secretKey                         = secretKey  ;
      this.corr_Id                           = xKOHLS_Correlation_ID  ;
      this.sys_Cd                            = xKOHLS_From_System_Code  ;
      this.message_Hdr                       = standard_Post_Header;
      this.method_Name                       = methodType;
      logger.info("corr_Id "+corr_Id);
      logger.info("XKohls_Message_ID "+XKohls_Message_ID);
      
      
  }
  
  @Then("I have create the payload for SpendTracker with localtyID as {string} which is present in LBL")
  public void I_Post_PayloadSpendTracker_LoyaltyID(String localtyID) throws Exception {
	  
	  rule_config = read_Yaml(get_Data_Folders() + Rule_Config);
	  loyalty_Id 	= 			localtyID;
		
	  raw_Payload = (String) rule_config.get("Payload_Template_For_Post_SpendTracker_Service");
      // Map aa = (Map) lcs_Data.get("Payload_Template_For_Post_RuleConfig_Service_puttttt");
        raw_Payload =   raw_Payload.replace("replace_loyaltyId", loyalty_Id);
                                   
        
        logger.info("The payload is: "+raw_Payload);

         String encoded_Auth_String      = getSignatureForPOSTCallSpendTrackerMash(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);
         logger.info("corr_Id "+corr_Id);
        this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);
        
        logger.info("The raw_headers url for SpendTracker is: " +this.raw_Headers);
        full_Url                        = this.pilot_base_Url + service_Path;
        logger.info("The full url is: " +full_Url);

        response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);
        
        logger.info("The response of SpendTracker: "+response);
        logger.info("The response Code of SpendTracker:'\n' "+response.get(Response_Code));
        logger.info(response.get(Response_Code));

    }
  
  @Then("I have create the payload for SpendTracker with localtyID")
  public void I_Create_Post_PayloadSpendTracker() throws Exception {
	  
	  rule_config = read_Yaml(get_Data_Folders() + Rule_Config);
	  loyalty_Id 	= 			generateLoyaltyId();
		
	  raw_Payload = (String) rule_config.get("Payload_Template_For_Post_SpendTracker_Service");
      // Map aa = (Map) lcs_Data.get("Payload_Template_For_Post_RuleConfig_Service_puttttt");
        raw_Payload =   raw_Payload.replace("replace_loyaltyId", loyalty_Id);
                                   
        
        logger.info("The payload is: "+raw_Payload);

         String encoded_Auth_String      = getSignatureForPOSTCallSpendTrackerMash(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);
         logger.info("corr_Id "+corr_Id);
        this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);
        
        logger.info("The raw_headers url for SpendTracker is: " +this.raw_Headers);
        full_Url                        = this.pilot_base_Url + service_Path;
        logger.info("The full url is: " +full_Url);

        response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);
        
        logger.info("The response of SpendTracker: "+response);
        logger.info("The response Code of SpendTracker:'\n' "+response.get(Response_Code));
        logger.info(response.get(Response_Code));

    }
  
 // Then I should be able to verify the SpendTracker Response as <Success_Response> and everydayKccPercentage as <EVERYDAYKCCPERSPEND> and everydayNonKccPercentage as <EVERYDAYNONKCCPERSPEND> and earnTrackerThreshold as <ETTHRESHOLDSPEND> and existingEarnTrackerBal as <EARNTRACKBALSPEND> and spendAwayEverydayNonKcc as <SPENDNONKCC> and spendAwayEverydayKcc as <SPENDKCC>
  @Then("I should be able to verify the SpendTracker Response as {string} and everydayKccPercentage as {string} and everydayNonKccPercentage as {string}"
  		+ " and earnTrackerThreshold as {string} and existingEarnTrackerBal as {string} and spendAwayEverydayNonKcc as {string}"
  		+ " and spendAwayEverydayKcc as {string}")
  public void verify_spendTracker_Response(String success_Or_Fail,String everydayKccPercentage,String everydayNonKccPercentage,String earnTrackerThreshold,
		  String existingEarnTrackerBal,String spendAwayEverydayNonKcc,String spendAwayEverydayKcc) throws Throwable {
      logger.info("___01 Loyalty _04");

      assertEquals(success_Or_Fail, response.get("Response_Code").toString());
      logger.info("everydayKccPercentage "+((JsonObject) response.get("Response_Body")).get("everydayKccPercentage"));
      logger.info("everydayKccPercentage "+response.get("Response_Body"));
      assertEquals(everydayKccPercentage.toString(), ((JsonObject) response.get("Response_Body")).get("everydayKccPercentage").toString());
      assertEquals(everydayNonKccPercentage.toString(),((JsonObject) response.get("Response_Body")).get("everydayNonKccPercentage").toString());
      assertEquals(earnTrackerThreshold.toString(),((JsonObject) response.get("Response_Body")).get("earnTrackerThreshold").toString());
      assertEquals(existingEarnTrackerBal.toString(),((JsonObject) response.get("Response_Body")).get("existingEarnTrackerBal").toString());
      assertEquals(spendAwayEverydayNonKcc.toString(),((JsonObject) response.get("Response_Body")).get("spendAwayEverydayNonKcc").toString());
      assertEquals(spendAwayEverydayKcc.toString(),((JsonObject) response.get("Response_Body")).get("spendAwayEverydayKcc").toString());
      

  }*/
    /*@After
    public void doSomethingAfter(Scenario Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF) throws Exception {
        String scenario = Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF.getName(); // Samples
        String[] expectedArray = {"one", "two", "three"};
        String[] resultArray =  {"one", "two", "three", "0"};
    }

    @Then("I should be able to verify the Response as {string}$ for type")
    public void i_should_be_able_to_verify_the_Response_as(String arg1) throws Exception {
        logger.info("__");
    }*/

}
