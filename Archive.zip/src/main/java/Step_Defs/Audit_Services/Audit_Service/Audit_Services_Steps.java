package Step_Defs.Audit_Services.Audit_Service;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.getSignature;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static Utilities.UtilConstants.*;
import static org.junit.Assert.assertEquals;


public class Audit_Services_Steps {

    protected static final Logger logger = get_Logger();

    private String loyaltyId, service_Path, full_URI, message_ID, transactionID, barcode, transdate,transtime, raw_Payload;
    JsonObject response_From_Api; Map raw_Headers;
    private String sdf1;

    @Given("I am connected with Audit_Services: {string} for {string}")
    public void i_am_connected_with_Audit_Service(String arg1, String transaction_Id) throws Throwable {
    	
        this.service_Path       = "/transactions" + "/" + transaction_Id;
        this.full_URI           = "https://auditservices-qa01.apps.gcpusc1-b.lle.xpaas.kohls.com" + service_Path;


    }

    //@When("I send a (regex_Pattern) to the Audit service {string}")
    @When("I send a {string} to the Audit service {string}")
    public void I_send_a_Get_Request_for_Audit_service(String requestType, String apiName) throws Throwable {


/*
            this.transactionID      = generatetransactionId();
            this.loyaltyId          = generateLoyaltyIdRandom();
            this.barcode            = generatebarcode();
            this.transdate          = generateDate();
            this.transtime          = generateTime();*/


            this.message_ID         = "5319c8f5-55f2-4605-82b5-662914da01b1";


/*            raw_Payload             = lcs_Data.get("Payload_For_Audit_Service_xxxWhat01").toString()
                                           .replace("replace_transno",this.transactionID)
                                           .replace("replace_transactionDate",transdate)
                                           .replace("replace_transactionTime",transtime)
                                           .replace("replace_loyID",loyaltyId)
                                           .replace("replace_bar",barcode);*/

            this.sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        //check if errors out TODO
            raw_Headers = (Map) consolidated_Data.get("Header_Template_For_Rest");
            String payload = "";
            String encoded_Auth_String = getSignature(payload, this.service_Path, this.message_ID, requestType, this.sdf1);


            raw_Headers.put(Authorization, encoded_Auth_String);
            raw_Headers.put(X_KOHLS_CreateDateTime, sdf1);
            raw_Headers.put(X_KOHLS_MessageID, this.message_ID);        //Todo Reference Constants
            raw_Headers.put(X_KOHLS_CorrelationID, "1231");
            raw_Headers.put(X_KOHLS_From_SystemCode, "LAS");

            if (requestType.equalsIgnoreCase("get")) {
                raw_Headers.remove("Accept");
                raw_Headers.remove("Accept-Language");
                raw_Headers.remove("Content-Type");
                /*raw_Headers.put("Accept", "application/json");
                raw_Headers.put("Accept-Language", "it-IT,it");
                raw_Headers.put("Content-Type", "application/json");*/
            }
  
            response_From_Api = restClient_Any_Method(payload, raw_Headers, this.full_URI, "Get");

        logger.info("The response is: " + response_From_Api);

            logger.info(response_From_Api);
        
        //this.message_ID = messageId;

    }

    @Then("I should be able to verify the Response as {string} for Audit Service")
    public void I_should_be_able_to_verify_the_Response(String response_code) throws Exception {
    	 assertEquals(response_code, response_From_Api.get("Response_Code").toString());
    }
    
    
/*    @Given("I am connected with Audit_Service: {string}")
    public void i_am_connected_with_Audit_Service(String arg1) throws Throwable {


        for (int i = 0; i < 12; i++) {


            this.transactionID      = generatetransactionId();
            this.loyaltyId          = generateLoyaltyIdRandom();
            this.barcode            = generatebarcode();
            this.transdate          = generateDate();
            this.transtime          = generateTime();

            this.service_Path       = "/transactions" + "/" + this.loyaltyId;
            this.full_URI           = "https://auditservices-qa01.apps.lle.xpaas.kohls.com" + service_Path;
            this.message_ID         = "5319c8f5-55f2-4605-82b5-662914da01b2";
            this.lcs_Data           = read_Yaml(get_Data_Folders() + Lcs_Data);

            raw_Payload             = lcs_Data.get("Payload_For_Audit_Service_xxxWhat01").toString()
                                           .replace("replace_transno",this.transactionID)
                                           .replace("replace_transactionDate",transdate)
                                           .replace("replace_transactionTime",transtime)
                                           .replace("replace_loyID",loyaltyId)
                                           .replace("replace_bar",barcode);

            this.sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
            raw_Headers = (Map) this.lcs_Data.get("Header_Template_For_Rest");

            String encoded_Auth_String = getSignatureForPOSTCall(this.raw_Payload, this.service_Path, this.message_ID, "VUuUU6OqEcVE5eXM6rN5iFBvgMtGotNaahQJW4c2", this.sdf1);


            raw_Headers.put(Authorization, encoded_Auth_String);
            raw_Headers.put(X_KOHLS_CreateDateTime, sdf1);
            raw_Headers.put(X_KOHLS_MessageID, this.message_ID);        //Todo Reference Constants
            raw_Headers.put(X_KOHLS_CorrelationID, "1234");
            raw_Headers.put(X_KOHLS_From_SystemCode, "LAS");

            if ("get".equalsIgnoreCase("get")) {
                raw_Headers.remove("Accept");
                raw_Headers.remove("Accept-Language");
                raw_Headers.remove("Content-Type");
                raw_Headers.put("Accept", "application/json");
                raw_Headers.put("Accept-Language", "it-IT,it");
                raw_Headers.put("Content-Type", "application/json");
            }

            response_From_Api = restClient_Any_Method(raw_Payload, raw_Headers, this.full_URI, "Post");

            logger.info(response_From_Api);
        }
        //this.message_ID = messageId;

    }

    @When("I create the payload with Amount: {string}, and Event_Id {string} for {string} for {string}")
    public void i_create_the_payload_with_Amount_and_Event_Id_for_for(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        logger.info("__01");
    }

    @Then("I send a {string} to the {string} with {string} format and xml {string} for Property {string}")
    public void i_send_a_to_the_with_format_and_xml_for_Property(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        logger.info("__01");
    }

    @Then("I should be able to verify the Response as {string} for Audit Web Service")
    public void i_should_be_able_to_verify_the_Response_as_for_Audit_Web_Service(String arg1) throws Throwable {
        logger.info("__01");
    }*/

}
