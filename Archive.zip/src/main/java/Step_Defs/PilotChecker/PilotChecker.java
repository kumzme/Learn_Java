package Step_Defs.PilotChecker;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.getSignature;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static Utilities.LPF_Invoker_Utilities.create_Clean_Directory;
import static Utilities.UtilConstants.*;
import static org.junit.Assert.assertEquals;

public class PilotChecker {

    protected static final Logger logger = get_Logger();

    SimpleDateFormat sdf1;
    private Map raw_Headers;
    private JsonObject response_From_Api2;
    private String service_Name, service_Path, pilotchecker_base_Url, full_Url, raw_Payload, l_id;
  //  private String loyalty_Id;
    private static boolean got_Parms = false;
    JsonObject store_Data = new JsonObject();

    @Given("I am able to retrieve and set the project environment data for PilotChecker")
    public  void setUpForLoyalty_Steps() throws Exception {
        if (got_Parms==false) { this.got_Parms = true;create_Clean_Directory(); }

        pilotchecker_base_Url							=  project_Parameters.get("PilotEndpoint").getAsString();
    }

    @Given("I am connected with Pilot Checker Service {string}")
    public void i_am_connected_with_Service(String service_NameFrom_Feature) throws Throwable {

        service_Name                       = service_NameFrom_Feature;

    }

    @Given("I can check this and see if it works only for PilotChecker")
    public void i_can_check_this_PilotChecker() throws Throwable {

        JsonObject aa               = consolidated_Data;
    }

    @When("I create the payload for pilot checker")
    public void i_create_the_payload_for_Pilot_checker_Put_Service() throws Throwable {


        raw_Payload = consolidated_Data.get("Payload_Template_For_Post_PilotChecker_Service").getAsString();
        logger.info("Payload   " + raw_Payload);
    }

    @When("I hit {string} Pilot Checker service for loyaltyId {string} with {string} format, with headers {string} and {string} and {string} and {string}")
    public void i_hit_Pilot_Checker_service_with_format_with_headers_and_and(String method_Name,String loyalty_Id, String format, String XKOHLS_From_System_Code, String XKOHLS_Correlation_ID, String XKOHLS_Message_ID,String testCaseNumber) throws Exception {


   		service_Path                                   = "/" + this.service_Name + "/" + loyalty_Id;
        logger.info("service path ***" + service_Path);
       
        String requestTimestamp     = generate_Header_Date_TS();
        String encoded_Auth_String                     = getSignature(raw_Payload, service_Path, XKOHLS_Message_ID, method_Name,requestTimestamp);

        /*Check get and post for services*/
        raw_Headers                                    = (Map) consolidated_Data.get("Header_Template_For_Rest");

        raw_Headers.put(Authorization,                  encoded_Auth_String);
        raw_Headers.put(X_KOHLS_CreateDateTime,         requestTimestamp);
        raw_Headers.put(X_KOHLS_MessageID,              XKOHLS_Message_ID);        //Todo Reference Constants
        raw_Headers.put(X_KOHLS_CorrelationID,          XKOHLS_Correlation_ID);
        raw_Headers.put(X_KOHLS_From_SystemCode,        XKOHLS_From_System_Code);

        if(format.equalsIgnoreCase("json")){
            raw_Headers.put("Accept", "application/json");
            raw_Headers.put("Accept-Language", "it-IT,it"); //Todo Direct Constant
            raw_Headers.put("Content-Type", "application/json");
        }
        
        if(testCaseNumber.equalsIgnoreCase("TC04"))
    		service_Path                                   = "/" + this.service_Name + "/abcd"  ;
    	else
    		service_Path                                   = "/" + this.service_Name + "/" + loyalty_Id;
        
        full_Url                                            = this.pilotchecker_base_Url + service_Path;

        response_From_Api2                                  = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, method_Name);
        logger.info("Put Balances response :" + response_From_Api2.get("Response_Code").toString());
        logger.info("Put Balances response :"+ response_From_Api2);
    }

    @Then("I should be able to verify the Response as {string} of test case {string} for Pilot Checker Service")
    public void i_should_be_able_to_verify_the_Response_as(String success_Or_Fail,String testCaseNumber) throws Throwable {
        logger.info("Doing Assertion of response...");
        assertEquals(success_Or_Fail, response_From_Api2.get("Response_Code").toString());
    }

}

