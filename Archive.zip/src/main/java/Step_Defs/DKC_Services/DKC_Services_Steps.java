package Step_Defs.DKC_Services;

import com.google.gson.Gson;
import cucumber.api.Scenario;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.w3c.dom.Document;

import java.util.Map;

import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants.*;


public class DKC_Services_Steps {

    protected static final Logger logger = get_Logger();

    private String service_Payload, service_Uri, name_Space, service_Name, service_Port, test_Reference;
    private Document xml_Doc;
    private Map map_Store, store_Data = new Gson().fromJson("{}",Map.class);

    public static void setUpForDKC_Steps(Scenario Dkc_Service) {
        String scenario = Dkc_Service.getName();
        logger.info(scenario);
    }

    @Given("I am connected with Dkc_Service: {string}")
    public void i_am_connected_with_Dkc_Service(String arg1) throws Throwable {
        if (arg1.equalsIgnoreCase("Dkc_Service")){
            this.service_Payload    = Payload_DKC;
            this.service_Uri        = DKC_Endpoint_Uri;
        }

    }

    //Todo pass other xml parameters also
    @When("I create the payload with Amount: {string}, and Event_Id: {string}")
    public void i_create_the_payload_with_Amount_and_Event_Id(String amount, String event_Id) throws Exception {
        this.service_Payload = Payload_DKC  .replace("replace_Amount",      amount)
                                            .replace("replace_Event_Id",    event_Id);

    }

    @Then("I {string} to DKC service with {string} format, for DKC Service Name Space: {string} and DKC_Service_Name {string} and DKC_Service_Port: {string} for {string}")
    public void i_to_DKC_service_with_format_for_DKC_Service_Name_Space_and_DKC_Service_Name_and_DKC_Service_Port(String soap, String format, String namespace, String service_Name, String service_Port, String Test_Reference) throws Throwable {

        if (namespace.equalsIgnoreCase("DKC_namespace"))        this.name_Space   = DKC_Namespace;
        if (service_Name.equalsIgnoreCase("DKC_Service_Name"))  this.service_Name = DKC_Service_Name;
        if (service_Port.equalsIgnoreCase("DKC_Service_Port"))  this.service_Port = DKC_Service_Port;

        String response                     =  soap_Client(this.service_Payload, this.service_Uri,this.name_Space, this.service_Name, this.service_Port);

        this.xml_Doc                        =  convert_Soap_Response_To_XML_Doc(response);
        logger.info(xml_Doc);
        this.test_Reference = Test_Reference;

    }

    @Then("I should be able to verify the Response as {string} for DKC Web Service")
    public void i_should_be_able_to_verify_the_Response_as_for_DKC_Web_Service(String return_Code) throws Throwable {
        String pin                          = xml_Doc.getElementsByTagName("PIN").item(0).getTextContent();
        String barCode                      = xml_Doc.getElementsByTagName("Barcode").item(0).getTextContent();
        String rc                           = xml_Doc.getElementsByTagName("Status").item(0).getTextContent();

        store_Data.put(this.test_Reference, barCode);

        Assert.assertEquals(Integer.parseInt(return_Code),Integer.parseInt(rc));
    }

    @Then("I should save the data I created as {string} to get later")
    public void i_Store_data(String file_Name) throws Throwable {
        String full_File = get_Run_Data_Store_Folders()+ "/" +  file_Name ;
        store_Scenario_Data(full_File, store_Data);
    }

    /*//    @After
        public void doSomethingAfter(Scenario Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF) throws Exception {
            String scenario = Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF.getName(); // Samples
            String[] expectedArray = {"one", "two", "three"};
            String[] resultArray = {"one", "two", "three", "0"};
        }*/


}
