package Step_Defs.Example_BDD_Meeting;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants.Payload_LBL_Create_Account;


public class Sample_Steps {



    private String service_Payload, service_Uri, name_Space, service_Name, service_Port, soapEndpointUrl, soapAction,response;
    private Document xml_Doc;

    protected static final Logger logger = get_Logger();


    @Given("A pilot customer has performed Sale Transaction")
    public void a_pilot_customer_has_performed_Sale_Transaction() throws Throwable {
        logger.info("____");
    }

    @Given("Sale transactions with {string} for a customer")
    public void alnaalknalkanaln(String arg1) throws Throwable {


//        String endpoint =
//                "https://qlty-xi11.kohls.com:8203/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
//
//        Service service = new Service();
//        Call call    = (Call) service.createCall();
//        call.setTargetEndpointAddress( new java.net.URL(endpoint) );
//        call.setOperationName(new QName("http://www.kohls.com/loyalty/service/openapi/", "Kohls_LoyaltyOpenAPI_Service") );
//        call.setPortName(new QName("http://www.kohls.com/loyalty/service/openapi/", "Kohls_LoyaltyOpenAPI_ServiceHTTPPort") );

        //String ret = (String) call.invoke( new Object[]{"'aaa':'aaa'"});

        //Client client = dcf.createClient("/Users/tkma07x/Documents/WSDLK/BW.wsdl");


        //this.service_Uri            = "http://boundaryservice-qa.apps.gcpusc1-b.lle.xpaas.kohls.com/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
        //this.service_Uri            = "https://qlty-xi11.kohls.com:8203/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
        //this.service_Uri            = "https://slty-xi11.kohls.com:8203/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
        //this.name_Space             = "http://www.kohls.com/object/Loyalty/0.1/";
        //this.name_Space             = "http://www.instorecard.com/schema/v1/RetailIntegration/";
        //this.name_Space             = "http://www.loyaltylab.com/loyaltyapi/";
        //this.name_Space             = "http://www.kohls.com/loyalty/service/openapi/";
        //this.name_Space           = "http://qlty-xi11.kohls.com:8203/SharedResources/Service/";
        /* <targetNamespace="http://www.kohls.com/object/Loyalty/0.1/"> <xs:import namespace="http://www.kohls.com/loyalty/service/openapi/"/> */
        //this.service_Name           = "Kohls_LoyaltyOpenAPI_Service.serviceagent";
        //this.service_Name           = "KohlsLoyaltyOpenAPIService";
        //this.service_Port           = "KohlsLoyaltyOpenAPIPort";



        /*http://www.kohls.com/loyalty/service/openapi/}KohlsLoyaltyOpenAPIServiceSoapBinding*/     /* Cloud QA? Check*/
        /*http://www.kohls.com/loyalty/service/openapi/}KohlsLoyaltyOpenAPIHTTPEndpointBinding*/    /* On Prem  Check*/

        this.service_Payload    = Payload_LBL_Create_Account;


        /* On Prem  Check*/
        /*TODO @Gopi Legacy Request ? Check with Dev why Cloud is working while On prem is not and Response is also different*/
        String soap_Host        = "https://qlty-xi11.kohls.com:8203";
        String soap_Uri         = "/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
        String soap_Method      = "/CreateAccount";

        this.soapEndpointUrl    = soap_Host  +   soap_Uri;
        this.soapAction         = soap_Uri  +   soap_Method; /*TODO Check the WSDL for CreateAccount to get the full action name and delete this line*/

        this.response           =   soap_Client_For_Legacy_Apps(soapEndpointUrl, soapAction, this.service_Payload);
        this.xml_Doc            =   convert_Soap_Response_To_XML_Doc(response);


        this.service_Payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:kohls:xml:schemas:message-header:v1_0\" xmlns:ns=\"http://www.kohls.com/object/Loyalty/0.1/\"> <soapenv:Header> <urn:MessageHeader version=\"1.0\"> </urn:MessageHeader> </soapenv:Header> <soapenv:Body> <ns:getShopperByRetailerIDRequest> <ns:LoyaltyID>81129635371</ns:LoyaltyID> <ns:pointChange>0</ns:pointChange> <!--Optional:--> <ns:message>testmsg1</ns:message> </ns:getShopperByRetailerIDRequest> </soapenv:Body> </soapenv:Envelope>";
        this.response           =   soap_Client_For_Legacy_Apps("https://qlty-xi11.kohls.com:8203/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint", "/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent//UpdateMemberPointBalance", this.service_Payload);

        this.xml_Doc            =   convert_Soap_Response_To_XML_Doc(response);
        logger.info(xml_Doc);
        //Examples of processing:
        logger.info(xml_Doc.getElementsByTagName("SOAP-ENV:Envelope").item(0).getTextContent());
        logger.info(xml_Doc.getElementsByTagName("ns:CreateDateTime").item(0).getTextContent());
        //Examples of processing: use common function
        logger.info(get_Xml_elements_By_Tag_Name(xml_Doc, "ns:firstName"));

        /* Cloud QA ? Check Wih Legacy Function*/
        soap_Host               = "https://boundaryservice-qa.apps.gcpusc1-b.lle.xpaas.kohls.com"; /*Uri and Action same*/

        this.soapEndpointUrl    = soap_Host  +   soap_Uri + "";
        this.soapAction         = soap_Uri  +   soap_Method + "";

        this.response           =   soap_Client_For_Legacy_Apps(soapEndpointUrl, soapAction, this.service_Payload);
        this.xml_Doc            =   convert_Soap_Response_To_XML_Doc(response);
        logger.info(xml_Doc);
        //Examples of processing: use common function
        logger.info(get_Xml_elements_By_Tag_Name(xml_Doc, "ns2:firstName"));

        /* Cloud QA? Check*/
        this.service_Uri        = "https://boundaryservice-qa.apps.gcpusc1-b.lle.xpaas.kohls.com/SharedResources/Service/Kohls_LoyaltyOpenAPI_Service.serviceagent/KohlsLoyaltyOpenAPIHTTPEndpoint";
        this.name_Space         = "http://www.kohls.com/loyalty/service/openapi/";
        this.service_Name       = "Kohls_LoyaltyOpenAPI_Service";
        this.service_Port       = "KohlsLoyaltyOpenAPIHTTPPort";
        this.response           =  soap_Client (this.service_Payload, this.service_Uri,this.name_Space, this.service_Name, this.service_Port);

    }

    @Given("Sale (\\d+) Date is in {string} using {string}")
    public void sale_Date_is_in(int arg1, String arg2, String arg3) throws Throwable {
        logger.info("____");
    }

    @When("The customer makes {string} from {string} Transaction in {string}")
    public void the_customer_makes_from_Transaction_in(String arg1, String arg2, String arg3) throws Throwable {
        logger.info("____");
    }

    @Then("return service should provide unearned kohls cash with event earn delta as (\\d+) for sale (\\d+)")
    public void return_service_should_provide_unearned_kohls_cash_with_event_earn_delta_as_for_sale(int arg1, int arg2) throws Throwable {
        logger.info("____");
    }
    
}
