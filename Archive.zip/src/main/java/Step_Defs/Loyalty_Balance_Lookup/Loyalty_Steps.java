package Step_Defs.Loyalty_Balance_Lookup;

import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.*;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.getSignature;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants.*;
import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;


public class Loyalty_Steps {

    protected static final Logger logger = get_Logger();

    private String loyaltyId, service_Path, full_URI, message_ID;
    private JsonObject response_From_Api, response_From_Api_put;
    private String time_stamp, raw_Payload;
    private Map  raw_Headers, project_Options_put, mapped_Payload;
    SimpleDateFormat sdf1;

    @Given("I am able to retrieve and set the project environment data for Loyalty Balance Lookup")
    public  void setUpForLoyalty_Steps() throws Exception {

    }

    @Given("I am connected with Balance lookup service at {string} for {string} and {string} and {string} and {string}")
    public void i_am_connected_with_Balance_lookup(String Balances, String Method, String Test_Case_Number, String loyalty_Id, String messageId) throws Exception {


        this.loyaltyId = loyalty_Id;
        this.service_Path = "/" +  Balances + "/" + this.loyaltyId;
        this.full_URI = "https://balancelookup-qa01.apps.gcpusc1-b.lle.xpaas.kohls.com" + service_Path;
        this.message_ID = messageId;

    }

    @When("I send GET request to get balance in {string}  for {string}  and {string} and {string} with no {string}")
    public void i_send_GET_request_to_get_balance(String Format, String Method, String Test_Case_Number, String Loyalty_Idmap, String Error_Code) throws Exception {

        /*this.arrResp = executeRestServiceRequest(Loyalty_Idmap, Method, 1); logger.info("arrResp  **** " +this.arrResp); JsonObject resp_Cont = convert_String_To_JsonObject(arrResp.get(1)); if(!Error_Code.equalsIgnoreCase("null")){ for (int i = 0; i < 60; i++) { if (resp_Cont.has("status")){ String status_Code = ((JsonObject)resp_Cont.get("status")).get("code").toString(); if (status_Code.equals(Error_Code)){ registerRestService(Loyalty_Idmap); project.setPropertyValue("endPoint", "https://balancelookup-qa01.apps.gcpusc1-b.lle.xpaas.kohls.com"); this.arrResp = executeRestServiceRequest(Loyalty_Idmap, Method, 1); } }else{ break; } } }*/

        time_stamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        String encoded_Auth_String                     = getSignature("", this.service_Path, this.message_ID, "get", time_stamp);

        /*String encoded_Auth_String1                     = getSignatureForGetCall(this.service_Path, this.message_ID);*/
        //  time_stamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        raw_Headers =  generate_Header(Rest_Api_Header_Name, time_stamp, "kc", this.message_ID,"1231", "get", encoded_Auth_String);

        response_From_Api = restClient_Any_Method("", raw_Headers, this.full_URI, "Get");

    }

    @When("I send negative GET request to get balance in {string}  for {string}  and {string} and {string} with no {string}")
    public void i_negative_GET_request_to_get_balance(String Format, String Method, String Test_Case_Number, String Loyalty_Idmap, String Error_Code) throws Exception {

        time_stamp                                      = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        Calendar c = Calendar.getInstance();

        String encoded_Auth_String                      = getSignature("", this.service_Path, this.message_ID, "get",time_stamp);
        raw_Headers                                     = generate_Header(Rest_Api_Header_Name, time_stamp, "kc", this.message_ID,"1231", "get", encoded_Auth_String);


        if(Method.contains("Invalid_Signature"))            raw_Headers.put(X_KOHLS_MessageID, "Invalid");
        if(Method.contains("Invalid_Auth"))                 raw_Headers.put(Authorization, "amlnalknaa");
        if(Method.contains("Miss_Auth"))                    raw_Headers.put(Authorization, "");
        if(Method.contains("No_Auth_Header"))               raw_Headers.remove(Authorization);
        if(Method.contains("Create_Date_Invalid"))          raw_Headers.put(X_KOHLS_CreateDateTime, "aaja09ua0918719");;
        if(Method.contains("Create_Date_Miss"))             raw_Headers.put(X_KOHLS_CreateDateTime, "");
        if(Method.contains("Create_Date_Header"))           raw_Headers.remove(X_KOHLS_CreateDateTime);
        if(Method.contains("Missing_System_Cd"))            raw_Headers.put(X_KOHLS_From_SystemCode, "");
        if(Method.contains("No_System_Cd"))                 raw_Headers.remove(X_KOHLS_From_SystemCode);
        if(Method.contains("Missing_CorrelationID"))        raw_Headers.put(X_KOHLS_CorrelationID, "");
        if(Method.contains("No_CorrelationID"))             raw_Headers.remove(X_KOHLS_CorrelationID);
        if(Method.contains("Missing_Message_Id"))           raw_Headers.put(X_KOHLS_MessageID, "");
        if(Method.contains("No_Message_Id"))                raw_Headers.remove(X_KOHLS_MessageID);
        if(Method.contains("Stale_Hit"))                    Thread.sleep(300000);
        if(Method.contains("Un_Authorized"))                raw_Headers.put(Authorization, encoded_Auth_String.replace("QCoE","ABCD"));

        response_From_Api = restClient_Any_Method("", raw_Headers, this.full_URI, "get");

    }

    @Then("I expect the service to return {string} status code with {string} and {string} and {string}")
    public void i_expect_the_service_to_return_status_code(String Response_Status_Code, String Total_Earn_Tracker, String Total_Pending_Balance, String Pending_Bar_Code) throws Exception {

        assertEquals("Assert for the Status Code Good: ", Response_Status_Code, response_From_Api.get("Response_Code").toString());

        //JsonObject resp_Cont = convert_Map_To_JsonObject(response_From_Api);


        assertEquals("Pending barcode Check to be Equal: ", response_From_Api.getAsJsonObject(Response_Body).get("pendingBarcode").toString(), Pending_Bar_Code);
        assertEquals("Total Earn Tracker Check: ",          response_From_Api.getAsJsonObject(Response_Body).get("totalEarnTracker").toString(), Total_Earn_Tracker);
        assertEquals("Total Pending Balance: ",             response_From_Api.getAsJsonObject(Response_Body).get("totalPendingBalance").toString(), Total_Pending_Balance);

    }

    @Then("I expect the service to return {string} status code with {string} and {string}")
    public void i_expect_the_service_to_return_status_code_Negative(String Response_Status_Code,String App_Status_Code, String Error_Message) throws Exception {

        assertEquals("Assert for the Status Code Good: ", Response_Status_Code, response_From_Api.get("Response_Code").toString());

        if (        (!Error_Message.equalsIgnoreCase("null") || !App_Status_Code.equalsIgnoreCase("null"))
                &&  !Response_Status_Code.equalsIgnoreCase("404") ){
            assertEquals("Application status code to be correct: ", response_From_Api.getAsJsonObject(Response_Body).getAsJsonObject("status").get("code").getAsString(), App_Status_Code);
            assertEquals("Application status code to be correct: ", response_From_Api.getAsJsonObject(Response_Body).getAsJsonObject("status").get("message").getAsString(), Error_Message);
        }

    }



    //balance lookup put service steps

    @Given("I am able to retrieve and set the project environment data for Loyalty Balance Lookup Put")
    public  void setUpForLoyaltyPut_Steps() throws Exception {

    }


    @Given("I am connected with Balance lookup Put service at {string} for {string} and {string} and {string}")
    public void i_am_connected_with_Balance_lookup_Put(String Balances, String Test_Case_Number, String loyalty_Id, String messageId) throws Exception {

        logger.info("loyalty_Id is $$$... :" + loyalty_Id);
        this.loyaltyId = loyalty_Id;
        this.service_Path = "/" +  Balances + "/" + this.loyaltyId;
        this.full_URI = project_Parameters.get("LBLEndpoint").getAsString() + service_Path;
        this.message_ID = messageId;

    }

    @When("I send PUT request to get balance in {string} and {string} and {string} and {string} and {string}")
    public void i_send_PUT_request_to_get_balance(String Test_Case_Number, String totalEarnTracker, String TotalPendingBalance, String barcode, String pendingExpirationDate) throws Exception {

        /*this.arrResp = executeRestServiceRequest(Loyalty_Idmap, Method, 1); logger.info("arrResp  **** " +this.arrResp); JsonObject resp_Cont = convert_String_To_JsonObject(arrResp.get(1)); if(!Error_Code.equalsIgnoreCase("null")){ for (int i = 0; i < 60; i++) { if (resp_Cont.has("status")){ String status_Code = ((JsonObject)resp_Cont.get("status")).get("code").toString(); if (status_Code.equals(Error_Code)){ registerRestService(Loyalty_Idmap); project.setPropertyValue("endPoint", "https://balancelookup-qa01.apps.gcpusc1-b.lle.xpaas.kohls.com"); this.arrResp = executeRestServiceRequest(Loyalty_Idmap, Method, 1); } }else{ break; } } }*/


        sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        raw_Payload = consolidated_Data.get("Payload_Template_For_Put_Balances_Service").getAsString();
        raw_Payload = raw_Payload   .replace("replace_loyaltyId", this.loyaltyId)
                .replace("replace_totalEarnTracker", totalEarnTracker)
                .replace("replace_totalPendingBalance", TotalPendingBalance)
                .replace("replace_pendingBarcode", barcode)
                .replace("replace_pendingExpirationDate", pendingExpirationDate);

        mapped_Payload = convert_String_To_Map(raw_Payload);
        logger.info("The payload is: " + mapped_Payload);
        time_stamp                                      = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        String encoded_Auth_String                      = getSignature(raw_Payload, this.service_Path, this.message_ID, "put", time_stamp);

        //    time_stamp                                      = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        raw_Headers                                     = generate_Header(Rest_Api_Header_Name, time_stamp, "LYB", this.message_ID,"1235", "put", encoded_Auth_String);

        //full_Url                                            = this.lbl_base_Url + service_Path;
        this.response_From_Api_put = restClient_Any_Method(raw_Payload, raw_Headers, this.full_URI, "put");
        logger.info("response_From_Api_put is $$$ ... :" + response_From_Api_put.toString());
    }


    @Then("I expect the PUT service to return {string} status code with {string} and {string} and {string}")
    public void i_expect_the_put_service_to_return_status_code(String Response_Status_Code, String Total_Earn_Tracker, String Total_Pending_Balance, String Pending_Bar_Code) throws Exception {

        assertEquals("Assert for the Status Code Good: ", Response_Status_Code, response_From_Api_put.get("Response_Code").toString());

    }


    @Then("I expect the PUT service to return {string} from loyalty_balance_Put")
    public void i_expect_the_PUT_service_to_return_from_loyalty_balance_Put(String arg1) throws Throwable {
        Set<String> resp_Array = new LinkedHashSet(asList(arg1.split(","))) ;
        List<String> abc = asList(arg1.split(","));
        //assertThat(abc);

        //assertThat("Assert for the Status Code Good: ", response_From_Api_put.get("Response_Code").toString(), conta);
        //contains(this.response_From_Api_put.get("Response_Code").toString())

    }




}
