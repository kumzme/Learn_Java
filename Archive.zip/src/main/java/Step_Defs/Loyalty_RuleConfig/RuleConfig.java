package Step_Defs.Loyalty_RuleConfig;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Service_Functions.Rule_Config_Functionalities.post_New_Rule_Config;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static Utilities.UtilConstants.Response_Code;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;
import static org.junit.Assert.assertEquals;


public class RuleConfig {

    final static Logger logger = get_Logger();

    String sdf1;
    private Map raw_Headers, raw_Headers_get;
    private JsonObject response, response_put;
    private String service_Name, service_Path, pilot_base_Url, full_Url, raw_Payload, raw_Payload_get, XKohls_Message_ID, secretKey, sys_Cd, corr_Id, message_Hdr, method_Name;

    private        int     version;
    private static boolean got_Parms = false;

    public RuleConfig() throws Exception {}

    @Given("I am able to retrieve and set the project environment data for RuleConfig")
    public void setUpFor_Rule_Config_Steps() throws Exception {

    }


    @Given("I am connected with {string} service to {string} for {string}")
    public void i_am_connected_with_Service(String service_NameFrom_Feature, String endpoint, String testCase) throws Exception {
        service_Name = service_NameFrom_Feature;
        this.pilot_base_Url = project_Parameters.get(endpoint).getAsString();
        logger.info("service_Name " + service_Name + " for testcase +" + testCase);
    }

    @When("I {string} to Rule_Config with {string} format, with headers {string} for {string} and {string} and {string} and {string}")
    public void i_to_Rule_Config_with_format_with_headers_for_and_and_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Exception {
        this.service_Path = "/" + this.service_Name;


        this.sdf1 = generate_Header_Date_TS_TimeZone();
        this.XKohls_Message_ID = arg6;
        this.secretKey = arg7;
        this.sys_Cd = arg4;
        this.corr_Id = arg5;
        this.message_Hdr = arg3;
        this.method_Name = arg1;
    }


    @Then("I create get service for version {string} and the {string} and {string} and {string} and {string}")
    public void I_Create_Get_rule_config(String loyaltyId, String totalEarnTracker, String totalPendingBalance, String pendingBarcode, String pendingExpirationDate) throws Exception {

        //  this.sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        this.sdf1 = generate_Header_Date_TS_TimeZone();
        String encoded_Auth_String = getSignatureForRuleConfigGetCall(this.service_Path, "5319c8f5-55f2-4605-82b5-662914da01b2", this.sdf1);
        this.raw_Headers_get = generate_Header(message_Hdr, this.sdf1, sys_Cd, "5319c8f5-55f2-4605-82b5-662914da01b2", corr_Id, "get", encoded_Auth_String);

        full_Url = this.pilot_base_Url + this.service_Path;

        raw_Payload_get = "";
        response = restClient_Any_Method(raw_Payload_get, raw_Headers_get, this.full_Url, "get");

        logger.info(response.get(Response_Code));

        JsonArray  aa = response.getAsJsonObject("Response_Body").getAsJsonObject("_embedded").getAsJsonArray("rules");
        JsonObject a1 = (JsonObject) aa.get(aa.size() - 1);
        version = a1.get("version").getAsInt() + 1;
        logger.info("Latest version is $$$ :" + version);
    }

    @Then("I create a payload with version for {string} department and {string} rules Config and {string} everyDay KcId and {string} NonKcc Percent and {string} kcc Percent and {string} start_Date and {string} end_Date and {string} earn_ThresholdDollar and {string} spend_ThresholdDollar and {string} activation_StartDate and {string} activation_EndDate and {string} red_StartDate and {string} red_EndDate and {string} Event_Name and {string} EarnTracker_Threshold and {string} eventKc_Id and {string}")
    public void I_Create_Put_Payload(String dept_Id, String Rules_Config, String EveryDayKcId, String NonKccPercent, String kccPercent, String startDate, String endDate, String earnThresholdDollar, String spendThresholdDollar, String activationStartDate, String activationEndDate, String redStartDate, String redEndDate, String Event_Name, String EarnTrackerThreshold, String eventKc_Id, String feature_Payload) throws Exception {

        raw_Payload = consolidated_Data.get(feature_Payload).getAsString();

        raw_Payload = raw_Payload.replace("replace_version", Integer.toString(version));

        logger.info("raw_Payload is $$$... :" + raw_Payload);

        this.sdf1 = generate_Header_Date_TS_TimeZone();

        String encoded_Auth_String = getSignatureForPOSTCall(raw_Payload, service_Path, XKohls_Message_ID, secretKey, this.sdf1);

        this.raw_Headers = generate_Header(message_Hdr, this.sdf1, sys_Cd, XKohls_Message_ID, corr_Id, "post", encoded_Auth_String);

        response_put = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, "post");

        logger.info(response_put.get(Response_Code));

        logger.info("response_put is $$$..:" + response_put);
    }

    /*@After
    public void doSomethingAfter(Scenario Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF) throws Exception {
        String scenario = Verification_of_Loyalty_Balance_Lookup_Functionality_Of_LPF.getName(); // Samples
        String[] expectedArray = {"one", "two", "three"};
        String[] resultArray =  {"one", "two", "three", "0"};
    }*/

    @Then("I should be able to verify the Response as {string}")
    public void i_should_be_able_to_verify_the_Response_as(String arg1) throws Exception {
        logger.info("__");
        assertEquals("Assert for the Status Code Good: ", "200", response.get("Response_Code").toString());
        assertEquals("Assert for the Status Code Good: ", "201", response_put.get("Response_Code").toString());
    }

    @Given("I Perform a {string} transaction in {string} for a customer with same pilot loyalty ID")
    public void example_Step_Going_Fwd(String sale_Payload, String rule_Payload_Reference) throws Throwable {


        /*

                1. RuleConfig set up. -5 to 10mins.
           Todo 2. Create LoyaltyId using balance lookup
           Todo 3. and updating it in pilot BD  (5-mins)
           Todo 4. Form sale and return messages(with proper data as per loyalty id and dates). - 20 mins(depends on scenario like full/ partial returns)
           Todo 5. Post the sale and return messages in kafka and verify the message gets passes.(5min)
           Todo 6. Verify in auditService DB(contains 9 tables and in LBL 1 table).(20 mins).
            in total each TC takes around 1hr approx.

        */


        JsonObject some_Object           = new JsonObject();
        some_Object.addProperty("Any values that you need to replace, keep this in the Yaml file string", String.valueOf(99));
        some_Object.addProperty(Reference_Payload, rule_Payload_Reference);

        String rule_Payload_Updated = post_New_Rule_Config(some_Object);

        logger.info(rule_Payload_Updated);

    }

}
