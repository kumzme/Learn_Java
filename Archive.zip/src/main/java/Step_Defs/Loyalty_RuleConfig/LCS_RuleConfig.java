
package Step_Defs.Loyalty_RuleConfig;

import Utilities.Date_Util;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.LPF_Invoker_Utilities.get_This_Project_Parameters;
import static Utilities.UtilConstants.*;
import static org.junit.Assert.assertEquals;


public class LCS_RuleConfig {

    protected static final Logger logger = LogManager.getLogger(new Object().getClass().getSimpleName());

    String sdf1; 
    private Map raw_Headers,raw_Headers_get,project_Options, rule_config;
    private JsonObject response;
    public String version;
    private String service_Name, service_Path, raw_Payload_get,pilot_base_Url, full_Url, raw_Payload, XKohls_Message_ID, secretKey, sys_Cd, corr_Id, message_Hdr, method_Name;
    Date_Util dateUtil = new Date_Util();

    /*@Before
    public void setUpForLoyalty_Steps(Scenario Loyalty_Lcs) throws Exception{
        String scenario                         = Loyalty_Lcs.getName(); // Needed ? Todo
        logger.info(scenario);
    }*/

    @Given("I am able to retrieve and set the project environment data for LCSServices")
    public  void setUpFor_Rule_Config_Steps() throws Exception {
        this.project_Options                    = get_This_Project_Parameters();
    }


    @Given("Connected with {string} service to {string} for {string} type")
    public void i_am_connected_with_Service(String service_NameFrom_Feature,String endpoint, String testCase) throws Exception {
        service_Name                            = service_NameFrom_Feature;
        this.pilot_base_Url                     = this.project_Options.get(endpoint).toString();
        logger.info("endpoint " + pilot_base_Url);
        logger.info("service_Name "+service_Name +" for testcase +"+testCase);
    }

    @When("I {string} to Rule_Config type for LCSPostTenderNonPilot with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
    //  @When("I {string} to Rule_Config type1 with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
    public void i_to_Rule_Config_with_format_with_headers_for_and_and_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Exception {
        this.service_Path                      = "/" + this.service_Name ;
      //  raw_Headers = (Map) this.lcs_Data.get("Header_Template_For_Rest");
      
        //Header_Template_For_Rest
        //Todo @team logic
        this.sdf1                              = generate_Header_Date_TS();
        this.XKohls_Message_ID                 = arg6  ;
        this.secretKey                         = arg7  ;
        this.corr_Id                           = arg5  ;
        this.sys_Cd                            = arg4  ;
        this.message_Hdr                       = arg3;
        this.method_Name                       = arg1;
        
        
    }

    @Then("I have create the payload with RuleConfig with types as {string} , version as {string}")
  public void I_Create_Put_Payload(String types, String versionFF) throws Exception {
	  
	  rule_config = read_Yaml(get_Data_Folders() + Rule_Config);
      logger.info("rule_config " + rule_config);
  DateFormat form = new SimpleDateFormat("yyyy-MM-dd");
		Date d = new Date();
		Date edstartdate = new Date();
		Date edenddate = new Date();
		if(types.contains("1")){
			//everydaystartdate < Current date < everydayenddate
			edstartdate = dateUtil.subtractDays(d, 5);
			edenddate = dateUtil.addDays(d,5);
		}else if(types.contains("2")){
			//everydaystartdate == Current date < everydayenddate
			edstartdate = d;
			edenddate = dateUtil.addDays(d,10);
		}else if(types.contains("3")){
			//everydaystartdate == Current date == everydayenddate
			edstartdate = d;
			edenddate = d;
		}else if(types.contains("4")){
			//everydaystartdate < Current date == everydayenddate
			edstartdate = dateUtil.subtractDays(d,10);
			edenddate = d;
		}
		
	  raw_Payload = (String) rule_config.get("Payload_Template_For_Post_RuleConfig_Service_Everydayrule");
      // Map aa = (Map) lcs_Data.get("Payload_Template_For_Post_RuleConfig_Service_puttttt");
	  Integer versionAdded = Integer.parseInt(version)+1;
	  String versionToBeAdded = versionAdded.toString();
      logger.info("versionToBeAdded " + versionToBeAdded);
        raw_Payload =   raw_Payload.replace("replace_version", versionToBeAdded)
                                   .replace("replace_startDate", form.format(dateUtil.subtractDays(edstartdate, 5)))
                                   .replace("replace_endDate", form.format(dateUtil.subtractDays(edstartdate, 1)))
                                   .replace("replace_startDate1", form.format(edstartdate))
                                   .replace("replace_endDate1", form.format(edenddate))
                                   .replace("replace_startDate2", form.format(dateUtil.addDays(edenddate,1)))
                                   .replace("replace_endDate2", form.format(dateUtil.addDays(edenddate,5)));


      logger.info("The payload is: " + raw_Payload);

         String encoded_Auth_String      = getSignatureForPOSTCall(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);

        this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);

      logger.info("The raw_headers url is: " + this.raw_Headers);
        full_Url                        = this.pilot_base_Url + service_Path;
      logger.info("The full url is: " + full_Url);

        response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

      logger.info("The response of RuleConfig: " + response);
      logger.info("The response Code of RuleConfig:'\n' " + response.get(Response_Code));
        logger.info(response.get(Response_Code));

    }


    @Then("I should be able to verify the Response {string} for type of LCSPostTenderNonPilot")
  public void i_should_be_able_to_verify_the_Response_as(String success_Or_Fail) throws Exception {
	  assertEquals(success_Or_Fail, response.get("Response_Code").toString());
  }

  /*
   * Rule config get latest version starts 
   */


    @Then("I created get service for latest version")
  public void I_Create_Get_rule_config() throws Exception {

    //  this.sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
  	this.sdf1 = generate_Header_Date_TS_TimeZone();
      String encoded_Auth_String      = getSignatureForRuleConfigGetCall(this.service_Path, "5319c8f5-55f2-4605-82b5-662914da01b2", this.sdf1);

      this.raw_Headers_get                = generate_Header(message_Hdr, this.sdf1, sys_Cd, "5319c8f5-55f2-4605-82b5-662914da01b2", corr_Id, "get", encoded_Auth_String);

      full_Url                        = this.pilot_base_Url + this.service_Path;

      raw_Payload_get="";
      response                        = restClient_Any_Method(raw_Payload_get, raw_Headers_get, this.full_Url, "get");

      logger.info(response.get(Response_Code));
      
      JsonArray aa = response.getAsJsonObject("Response_Body").getAsJsonObject("_embedded").getAsJsonArray("rules");
      JsonObject a1 = (JsonObject) aa.get(aa.size() - 1);
      version = a1.get("version").getAsString();
      Rules_Version = version;
      logger.info("Latest version in rule config is :" + version);
  }

  /*
   * Rule config get latest version ends
   */
  
  
  /*
   * Pretender Rules change starts here 
   */
  @Then("I have create the payload with RuleConfig with payload as {string} , version as {string}")
  public void I_Create_Rules_Payload(String payload, String versionFF) throws Exception {
	  
	  rule_config = read_Yaml(get_Data_Folders() + Rule_Config);
      logger.info("rule_config " + rule_config);
 
	  raw_Payload = (String) rule_config.get(payload);
      // Map aa = (Map) lcs_Data.get("Payload_Template_For_Post_RuleConfig_Service_puttttt");
	  //String version = Rules_Version;
	  Integer versionAdded = Integer.parseInt(version)+1;
	  String versionToBeAdded = versionAdded.toString();
      logger.info("versionToBeAdded " + versionToBeAdded);
        raw_Payload =   raw_Payload.replace("replace_version", versionToBeAdded);


      logger.info("The payload is: " + raw_Payload);
      logger.info("The service_Path is: " + service_Path);
      logger.info("The XKohls_Message_ID is: " + XKohls_Message_ID);
      logger.info("The secretKey is: " + secretKey);
      logger.info("The sdf1 is: " + sdf1);

         String encoded_Auth_String      = getSignatureForPOSTCall(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);

        this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);

      logger.info("The raw_headers url is: " + this.raw_Headers);
        full_Url                        = this.pilot_base_Url + service_Path;
      logger.info("The full url is: " + full_Url);

        response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

      logger.info("The response of RuleConfig: " + response);
      logger.info("The response Code of RuleConfig:'\n' " + response.get(Response_Code));
        logger.info(response.get(Response_Code));

    }
  
  /*
   * Post tender non pilot rule Config starts 
   */
  @Then("I have create the payload for LCSPostTenderNonPilot with RuleConfig with payload as {string} , version as {string} for LCSpostTenderNonPilot")
  public void rulePayloadForLCSPostTenderNonPilot(String payload, String versionFF) throws Exception {
	  
	  rule_config = read_Yaml(get_Data_Folders() + Rule_Config);
      logger.info("rule_config " + rule_config);
 
	  raw_Payload = (String) rule_config.get(payload);
    
	  DateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
			Date d = new Date();
			Date edstartdate = new Date();
			Date edenddate = new Date();
		/*try {
			d = format1.parse(date);
		} catch (ParseException e) {
			log.info("UNABLE TO PARSE DATE");
		}*/
		
		Date edStartDt = dateUtil.subtractDays(d,90);
		Date edEndDt = dateUtil.addDays(d,90);
		
		Date cActivStartDt = dateUtil.subtractDays(d,2);
		Date cActivEndDt = dateUtil.addDays(cActivStartDt, 10);
		Date cRedeemStarDt = dateUtil.addDays(cActivEndDt, 5);
		Date cRedeemEndDt = dateUtil.addDays(cRedeemStarDt, 15);
		
		Date pRedeemEndDt = dateUtil.subtractDays(cActivStartDt, 10);
		Date pRedeemStartDt = dateUtil.subtractDays(pRedeemEndDt,15);
		Date pActivEndDt = dateUtil.subtractDays(pRedeemStartDt, 1);
		Date pActivStartDt = dateUtil.subtractDays(pActivEndDt, 15);
		
		Date fActivStartDt = dateUtil.subtractDays(cRedeemEndDt,5);
		Date fActivEndDt = dateUtil.addDays(fActivStartDt, 15);
		Date fRedeemStartDt = dateUtil.addDays(fActivEndDt,1);
		Date fRedeemEndDt = dateUtil.addDays(fRedeemStartDt,15);
		
	
	  Integer versionAdded = Integer.parseInt(version)+1;
	  String versionToBeAdded = versionAdded.toString();
      logger.info("versionToBeAdded " + versionToBeAdded);
      raw_Payload =   raw_Payload.replace("replace_version", versionToBeAdded)
							        .replace("replace_EverydaySDate", dateUtil.changeDateFormat1(edStartDt))
							        .replace("replace_EverydayEDate", dateUtil.changeDateFormat1(edEndDt))
							        .replace("replace_EventPastActSDate", dateUtil.changeDateFormat1(cActivStartDt))
							        .replace("replace_EventPastActEDate", dateUtil.changeDateFormat1(cActivEndDt))
							        .replace("replace_EventPastRedSDate", dateUtil.changeDateFormat1(cRedeemStarDt))
							        .replace("replace_EventPastRedEDate", dateUtil.changeDateFormat1(cRedeemEndDt))
							        
							        .replace("replace_EventCurrentActSDate", dateUtil.changeDateFormat1(pActivStartDt))
							        .replace("replace_EventCurrentActEDate", dateUtil.changeDateFormat1(pActivEndDt))
							        .replace("replace_EventCurrentRedSDate", dateUtil.changeDateFormat1(pRedeemStartDt))
							        .replace("replace_EventCurrentRedEDate", dateUtil.changeDateFormat1(pRedeemEndDt))
							        
							        .replace("replace_EventFutureActSDate", dateUtil.changeDateFormat1(fActivStartDt))
							        .replace("replace_EventFutureActEDate", dateUtil.changeDateFormat1(fActivEndDt))
							        .replace("replace_EventFutureRedSDate", dateUtil.changeDateFormat1(fRedeemStartDt))
							        .replace("replace_EventFutureRedEDate", dateUtil.changeDateFormat1(fRedeemEndDt));


      logger.info("The payload is: " + raw_Payload);
      logger.info("The service_Path is: " + service_Path);
      logger.info("The XKohls_Message_ID is: " + XKohls_Message_ID);
      logger.info("The secretKey is: " + secretKey);
      logger.info("The sdf1 is: " + sdf1);

         String encoded_Auth_String      = getSignatureForPOSTCall(raw_Payload, service_Path, XKohls_Message_ID,secretKey,sdf1);

        this.raw_Headers                = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id, method_Name.toLowerCase(), encoded_Auth_String);

      logger.info("The raw_headers url is: " + this.raw_Headers);
        full_Url                        = this.pilot_base_Url + service_Path;
      logger.info("The full url is: " + full_Url);

        response                        = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

      logger.info("The response of RuleConfig: " + response);
      logger.info("The response Code of RuleConfig:'\n' " + response.get(Response_Code));
        logger.info(response.get(Response_Code));

    }

}

