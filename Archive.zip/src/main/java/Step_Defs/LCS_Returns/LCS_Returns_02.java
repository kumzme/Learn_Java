package Step_Defs.LCS_Returns;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import static Utilities.General_Purpose_Utilities.get_Logger;


public class LCS_Returns_02 {

    protected static final Logger logger = get_Logger();


    @Given("I am connected with {string} service at {string} for {string} and {string} and {string}")
    public void aaaalkhana(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        /*logger.log(Level.ERROR, "___");
        logger.log(Level.ERROR, arg1);
        logger.log(Level.ERROR, arg2);
        logger.log(Level.ERROR, arg3);
        logger.log(Level.ERROR, arg4);
        logger.log(Level.ERROR, arg5);*/
    }

    @When("I send PUT request to xxx in {string} and {string} and {string} and {string} and {string}")
    public void aaaalkhanakljana(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        logger.info("___02");
    }

    @Then("I expect the xxxx return {string} status code with {string} and {string} and {string}")
    public void aaaalkhanalknalan(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        logger.info("___02");
    }

}
