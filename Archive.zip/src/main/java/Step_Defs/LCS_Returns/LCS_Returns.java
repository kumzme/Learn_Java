package Step_Defs.LCS_Returns;

import Service_Functions.Check_Where_V2_Or_V1_Validation_Methods;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static org.junit.Assert.assertEquals;


public class LCS_Returns {

    protected static final Logger logger = get_Logger();

    private String loyaltyId, service_Path, full_URI, message_ID, transactionID, barcode, transdate, transtime, raw_Payload;
    JsonObject response_From_Api;
    Map raw_Headers;
    private String sdf1;


    @Given("I am able to retrieve and set the project environment data for lcs Returns")
    public void setUpFor_lcs_returns_Steps() throws Exception {

    }


    @Given("I am connected with LCSReturn Service: {string}")
    public void i_am_connected_with_LCSReturn_Service(String LCS_return_path) throws Throwable {

        this.service_Path = "/" + LCS_return_path;
        this.full_URI = project_Parameters.get("LCSEndpoint").getAsString() + this.service_Path;
        logger.info("The URL of LCS returns is: " + this.full_URI);
        //this.full_URI           = "https://cashservice-qa01.apps.gcpusc1-b.lle.xpaas.kohls.com" + this.service_Path ;


    }


    @When("I send payload for LCSReturn Service {string} using {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string}")
    public void I_send_a_Post_Request_for_LCSReturn_service(String requestType, String loyaltyId,
                                                            String transactionNumber, String storeNumber, String registerId, String transactionDate,
                                                            String transactionTime, String everydayEarnKcc, String everydayEarnNonKcc,
                                                            String eligibleAmount, String lineNumber1, String department1, String sku1,
                                                            String netPrice1, String lineNumber2, String department2, String sku2, String netPrice2,
                                                            String lineNumber3, String department3, String sku3, String netPrice3, String prodCount) throws Throwable {


        this.message_ID = "5319c8f5-55f2-4605-82b5-662914da01b2";

        logger.info("prodCount is $$$... :" + prodCount);
        if (prodCount.equalsIgnoreCase("1")) {
            raw_Payload = consolidated_Data.get("Payload_Template_1Product_For_Post_LCSReturns_Service").getAsString();
        } else
            if (prodCount.equalsIgnoreCase("2")) {
                raw_Payload = consolidated_Data.get("Payload_Template_2Products_For_Post_LCSReturns_Service").getAsString();
                raw_Payload = raw_Payload.replace("replace_lineNumber2", lineNumber2)
                        .replace("replace_department2", department2)
                        .replace("replace_sku2", sku2)
                        .replace("replace_netPrice2", netPrice2);
            } else
                if (prodCount.equalsIgnoreCase("3")) {
                    raw_Payload = consolidated_Data.get("Payload_Template_3Products_For_Post_LCSReturns_Service").getAsString();
                    raw_Payload = raw_Payload.replace("replace_lineNumber2", lineNumber2)
                            .replace("replace_department2", department2)
                            .replace("replace_sku2", sku2)
                            .replace("replace_netPrice2", netPrice2)
                            .replace("replace_lineNumber3", lineNumber3)
                            .replace("replace_department3", department3)
                            .replace("replace_sku3", sku3)
                            .replace("replace_netPrice3", netPrice3);
                }
        logger.info("loyalty id is $$$...: " + loyaltyId + " and payload $$$ :" + raw_Payload);
        raw_Payload = raw_Payload.replace("replace_loyaltyId", loyaltyId)
                .replace("replace_transactionNumber", transactionNumber)
                .replace("replace_storeNumber", storeNumber)
                .replace("replace_registerId", registerId)
                .replace("replace_transactionDate", transactionDate)
                .replace("replace_transactionTime", transactionTime)
                .replace("replace_orderNumber", "")
                .replace("replace_everydayEarnKcc", everydayEarnKcc)
                .replace("replace_everydayEarnNonKcc", everydayEarnNonKcc)
                .replace("replace_eligibleAmount", eligibleAmount)
                .replace("replace_lineNumber1", lineNumber1)
                .replace("replace_department1", department1)
                .replace("replace_sku1", sku1)
                .replace("replace_netPrice1", netPrice1);


        //   this.sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());

        String requestTimestamp = generate_Header_Date_TS();
        //raw_Headers = (Map) this.lcs_Data.get("Header_Template_For_Rest");
        logger.info("The payload is: " + raw_Payload);
        logger.info("The FULL URL  is: " + full_URI);

        String encoded_Auth_String = getSignature(raw_Payload, this.service_Path, this.message_ID, requestType, requestTimestamp);

        this.raw_Headers = generate_Header("Header_Template_For_Rest", requestTimestamp, "KC", this.message_ID, "1231", "post", encoded_Auth_String);

        logger.info("raw_Headers is $$$...:" + raw_Headers);
           /* raw_Headers.put(Authorization, encoded_Auth_String);
            raw_Headers.put(X_KOHLS_CreateDateTime, requestTimestamp);
            raw_Headers.put(X_KOHLS_MessageID, this.message_ID);        //Todo Reference Constants
            raw_Headers.put(X_KOHLS_CorrelationID, "1231");
            raw_Headers.put(X_KOHLS_From_SystemCode, "KC");

            if (requestType.equalsIgnoreCase("get")) {
                raw_Headers.remove("Accept");
                raw_Headers.remove("Accept-Language");
                raw_Headers.remove("Content-Type");
                raw_Headers.put("Accept", "application/json");
                raw_Headers.put("Accept-Language", "it-IT,it");
                raw_Headers.put("Content-Type", "application/json");
            }
            else
            {
                raw_Headers.put("Accept", "application/json");
                raw_Headers.put("Accept-Language", "it-IT,it");
                raw_Headers.put("Content-Type", "application/json");
            }*/
        logger.info("The payload of LCS Returns is: " + raw_Payload);

        response_From_Api = restClient_Any_Method(raw_Payload, raw_Headers, this.full_URI, "Post");

        logger.info("The response of LCS Returns is: " + response_From_Api);

        logger.info(response_From_Api);

        //this.message_ID = messageId;

    }

    @Then("I should be able to verify the ProductDetails Response as {string} for Return Service and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string}")
    public void I_should_be_able_to_verify_the_Return_Response(String response_code, String kohlsCashEligible1, String kohlsCashEligible2, String lineNumber1, String dept1, String sku1, String netPrice1, String lineNumber2, String dept2, String sku2, String netPrice2, String deptcount, String barCode) throws Throwable {
        assertEquals(response_code, response_From_Api.get("Response_Code").toString());
        JsonArray arr = response_From_Api.getAsJsonObject("Response_Body").getAsJsonArray("responseDetails");
        //logger.info("response_From_Api array is  $$$... :"+arr);
        JsonObject rd1 = arr.get(0).getAsJsonObject();
        //JsonObject rd1 = (JsonObject) arr.get(0);
        JsonArray respArray = rd1.getAsJsonArray("products");


        //todo- store response data in list
        assertEquals(response_code, response_From_Api.get("Response_Code").toString());
        //JsonArray respArray = response_From_Api.getAsJsonObject("Response_Body").getAsJsonObject("_embedded").getAsJsonArray("rules");
        HashMap<String, String> respMap = new HashMap<String, String>();
        respMap.put("kohlsCashEligible1", kohlsCashEligible1);
        respMap.put("kohlsCashEligible2", kohlsCashEligible2);
        respMap.put("lineNumber1", lineNumber1);
        respMap.put("lineNumber2", lineNumber2);
        respMap.put("dept1", dept1);
        respMap.put("dept2", dept2);
        respMap.put("sku1", sku1);
        respMap.put("sku2", sku2);
        respMap.put("netPrice1", netPrice1);
        respMap.put("netPrice2", netPrice2);
        Check_Where_V2_Or_V1_Validation_Methods.validateProductDetails(respArray, respMap, deptcount);
        //getEventDates(eventId);
    }


    @SuppressWarnings("deprecation")
    @Then("I should be able to validate the Response of Return Service against {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string} and {string}")
    public void I_should_be_able_to_validate_the_Return_Response(String Exp_transactionNumber, String Exp_storeNumber, String Exp_registerId, String Exp_transactionDate, String Exp_transactionTime,
                                                                 String Exp_orderNumber, String Exp_loyaltyId, String Exp_EarnTrackerStartingBalance, String Exp_everydayEarnKccDelta, String Exp_everydayEarnNonKccDelta, String Exp_earnTrackerDelta, String Exp_refundDeduction, String Exp_barcodes, String Exp_initialCouponValues,
                                                                 String Exp_couponStartingBalance, String Exp_unearnedValue, String Exp_eventEarnDelta, String Exp_eligibleAmountDelta, String Exp_cpnRefundDeduction) throws Throwable {
        //assertEquals(response_code, response_From_Api.get("Response_Code").toString());

        JsonArray  respDetails = response_From_Api.getAsJsonObject("Response_Body").getAsJsonArray("responseDetails");
        JsonObject rd1         = respDetails.get(0).getAsJsonObject();
        validateBasicDetails(rd1, Exp_transactionNumber, Exp_storeNumber, Exp_registerId, Exp_transactionDate, Exp_transactionTime,
                             Exp_orderNumber, Exp_loyaltyId, Exp_EarnTrackerStartingBalance, Exp_everydayEarnKccDelta, Exp_everydayEarnNonKccDelta, Exp_earnTrackerDelta, Exp_refundDeduction);
        //JsonArray couponArray = rd1.getAsJsonArray();
        JsonArray couponArray = rd1.getAsJsonArray("couponDetails");

        String[] barcodeList = Exp_barcodes.split(",");

        logger.info("barcodeList size is $$$... :" + barcodeList.length);
        String eventId = "";
        for (int i = 0; i < barcodeList.length; i++) {
            logger.info("the list of barcodes are $$$ : " + barcodeList[i]);
            eventId = barcodeList[i].substring(0, 5);
            Map<String, String> rule_dates = Check_Where_V2_Or_V1_Validation_Methods.getEventDates(eventId);
            logger.info("rule_dates are ...:" + rule_dates.get("redemptionStartDate"));
            logger.info("rule_dates are ...:" + rule_dates.get("redemptionEndDate"));
            logger.info("rule_dates are $$$ :" + rule_dates.values());

            for (int j = 0; j < barcodeList.length; j++) {
                JsonObject  coupon         = (JsonObject) couponArray.get(j);
                JsonElement actual_barcode = coupon.get("barcode");
                String      actBarcode     = actual_barcode.getAsString();
                logger.info("barcodeList[i] is $$$ :" + barcodeList[i]);
                logger.info("actBarcode is $$$ :" + actBarcode);
                logger.info("coupon values $$$ :" + coupon.toString());
                if (barcodeList[i].equals(actBarcode)) {
                    //eventId = barcodeList[i].substring(0,5);
                    logger.info("validating...");
                    assertEquals("Mismatch happended", rule_dates.get("redemptionStartDate"), coupon.get("redemptionStartDate").getAsString());
                    assertEquals("Mismatch happended", rule_dates.get("redemptionEndDate"), coupon.get("redemptionEndDate").getAsString());
                }

            }


        }
        validateCouponDetails(couponArray, Exp_barcodes, Exp_initialCouponValues, Exp_couponStartingBalance, Exp_unearnedValue, Exp_eventEarnDelta, Exp_eligibleAmountDelta, Exp_cpnRefundDeduction);

    }

    public void validateBasicDetails(JsonObject rd1, String Exp_transactionNumber, String Exp_storeNumber, String Exp_registerId, String Exp_transactionDate, String Exp_transactionTime,
                                     String Exp_orderNumber, String Exp_loyaltyId, String Exp_EarnTrackerStartingBalance, String Exp_everydayEarnKccDelta, String Exp_everydayEarnNonKccDelta, String Exp_earnTrackerDelta, String Exp_refundDeduction) {
        JsonElement actual_transactionNumber = rd1.get("transactionNumber");
        logger.info("The transactionNumber is: " + actual_transactionNumber.toString());
        assertEquals("transactionNumber value mismatch, Expected: " + Exp_transactionNumber, Exp_transactionNumber, actual_transactionNumber.getAsString());

        JsonElement actual_earnTrackerStartingBalance = rd1.get("earnTrackerStartingBalance");
        //	   double act_earnTrackerStartingBalance = Double.valueOf(actual_earnTrackerStartingBalance.toString());
        logger.info("The actual earnTrackerStartingBalance is: " + actual_earnTrackerStartingBalance.getAsDouble());
        //double ex_EarnTrackerStartingBalance = Double.valueOf(Exp_EarnTrackerStartingBalance);
        assertEquals("EarnTrackerStartingBalance value mismatch, Expected: " + Exp_EarnTrackerStartingBalance, Exp_EarnTrackerStartingBalance, actual_earnTrackerStartingBalance.getAsString());

        JsonElement actual_storeNumber = rd1.get("storeNumber");
        logger.info("The storeNumber is: " + actual_storeNumber.toString());
        assertEquals("storeNumber value mismatch, Expected: " + Exp_storeNumber, Exp_storeNumber, actual_storeNumber.getAsString());

        JsonElement actual_registerId = rd1.get("registerId");
        logger.info("The registerId is: " + actual_registerId.toString());
        assertEquals("registerId value mismatch, Expected: " + Exp_registerId, Exp_registerId, actual_registerId.getAsString());

        JsonElement actual_transactionDate = rd1.get("transactionDate");
        logger.info("The transactionDate is: " + actual_transactionDate.toString());
        assertEquals("transactionDate value mismatch, Expected: " + Exp_transactionDate, Exp_transactionDate, actual_transactionDate.getAsString());

        JsonElement actual_transactionTime = rd1.get("transactionTime");
        logger.info("The transactionTime is: " + actual_transactionTime.toString());
        assertEquals("transactionTime value mismatch, Expected: " + Exp_transactionTime, Exp_transactionTime, actual_transactionTime.getAsString());

        JsonElement actual_orderNumber = rd1.get("orderNumber");
        logger.info("The orderNumber is: " + actual_orderNumber.toString() + " and Exp_orderNumber is :" + Exp_orderNumber);
        assertEquals("orderNumber value mismatch : " + Exp_orderNumber, Exp_orderNumber, actual_orderNumber.getAsString());


        JsonElement actual_loyaltyId = rd1.get("loyaltyId");
        logger.info("The loyaltyId is: " + actual_loyaltyId.toString());
        assertEquals("loyaltyId value mismatch, Expected: " + Exp_loyaltyId, Exp_loyaltyId, actual_loyaltyId.getAsString());


        JsonElement actual_everydayEarnKccDelta = rd1.get("everydayEarnKccDelta");
        //   double act_everydayEarnKccDelta = Double.valueOf(actual_everydayEarnKccDelta.toString());
        logger.info("The actual everydayEarnKccDelta is: " + actual_everydayEarnKccDelta.getAsDouble());
        //   double ex_everydayEarnKccDelta = Double.valueOf(Exp_everydayEarnKccDelta);
        assertEquals("EverydayEarnKccDelta value mismatch, Expected: " + Exp_everydayEarnKccDelta, Exp_everydayEarnKccDelta, actual_everydayEarnKccDelta.getAsString());

        JsonElement actual_everydayEarnNonKccDelta = rd1.get("everydayEarnNonKccDelta");
        //	double act_everydayEarnNonKccDelta = Double.valueOf(actual_earnTrackerStartingBalance.toString());
        logger.info("The actual everydayEarnNonKccDelta is: " + actual_earnTrackerStartingBalance);

        assertEquals("everydayEarnNonKccDelta value mismatch, Expected: " + Exp_everydayEarnNonKccDelta, Exp_everydayEarnNonKccDelta, actual_everydayEarnNonKccDelta.getAsString());

        JsonElement actual_earnTrackerDelta = rd1.get("earnTrackerDelta");
        //	   double act_earnTrackerDelta = Double.valueOf(actual_earnTrackerDelta.toString());
        logger.info("The earnTrackerDelta is: " + actual_earnTrackerDelta);

        assertEquals("earnTrackerDelta value mismatch, Expected: " + Exp_earnTrackerDelta, Exp_earnTrackerDelta, actual_earnTrackerDelta.getAsString());

        JsonElement actual_refundDeduction = rd1.get("refundDeduction");
        //	   double act_refundDeduction = Double.valueOf(actual_refundDeduction.toString());
        logger.info("The refundDeduction is: " + actual_refundDeduction.getAsDouble());

        assertEquals("refundDeduction value mismatch, Expected: " + Exp_refundDeduction, Exp_refundDeduction, actual_refundDeduction.getAsString());


    }


    public void validateCouponDetails(JsonArray couponArray, String Exp_barcodes, String Exp_initialCouponValue, String Exp_couponStartingBalance, String Exp_unearnedValue, String Exp_eventEarnDelta, String Exp_eligibleAmountDelta, String Exp_cpnRefundDeduction) {

        String[] barcodeList = Exp_barcodes.split(",");

        logger.info("the list of barcodes are" + barcodeList);

        String[] initialCouponValueList    = Exp_initialCouponValue.split(",");
        String[] couponStartingBalanceList = Exp_couponStartingBalance.split(",");
        String[] unearnedValueList         = Exp_unearnedValue.split(",");
        String[] eventEarnDeltaList        = Exp_eventEarnDelta.split(",");
        String[] eligibleAmountDeltaList   = Exp_eligibleAmountDelta.split(",");
        String[] cpnRefundDeductionList    = Exp_cpnRefundDeduction.split(",");


        for (int i = 0; i < barcodeList.length; i++) {
            logger.info("the list of barcodes are: " + barcodeList[i]);

            for (int j = 0; j < barcodeList.length; j++) {
                JsonObject  coupon         = (JsonObject) couponArray.get(j);
                JsonElement actual_barcode = coupon.get("barcode");
                logger.info("The actual barcode1 is :" + actual_barcode);
                JsonElement actual_initialCouponvalue  = coupon.get("initialCouponValue");
                JsonElement actual_couStBal            = coupon.get("couponStartingBalance");
                JsonElement actual_unEarnedValue       = coupon.get("unearnedValue");
                JsonElement actual_eventEarnDelta      = coupon.get("eventEarnDelta");
                JsonElement actual_eligibleAmountDelta = coupon.get("eligibleAmountDelta");
                JsonElement actual_cpnRefundDeduction  = coupon.get("cpnRefundDeduction");
                JsonElement actual_redemptionStartDate = coupon.get("redemptionStartDate");
                JsonElement actual_redemptionEndDate   = coupon.get("redemptionEndDate");

                if (barcodeList[i].equals(actual_barcode.getAsString())) {
                    logger.info("barcodes are matching ....");
                    assertEquals("Barcode mismatch, Expected: " + barcodeList[i], barcodeList[i], actual_barcode.getAsString());
                    //   logger.info("The barcode is : "+actual_barcode.getAsString());
                    assertEquals("intialCouponValue mismatch, Expected: " + initialCouponValueList[i], Double.valueOf(initialCouponValueList[i]), Double.valueOf(actual_initialCouponvalue.getAsString()));
                    assertEquals("couponStartingBalance mismatch, Expected: " + couponStartingBalanceList[i], Double.valueOf(couponStartingBalanceList[i]), Double.valueOf(actual_couStBal.getAsString()));
                    //  logger.info("The unEarnedValue is : "+actual_unEarnedValue.getAsString());
                    assertEquals("unearnedValue mismatch, Expected: " + unearnedValueList[i], Double.valueOf(unearnedValueList[i]), Double.valueOf(actual_unEarnedValue.getAsString()));
                    assertEquals("eventEarnDelta mismatch, Expected: " + eventEarnDeltaList[i], Double.valueOf(eventEarnDeltaList[i]), Double.valueOf(actual_eventEarnDelta.getAsString()));
                    assertEquals("eligibleAmountDelta mismatch, Expected: " + eligibleAmountDeltaList[i], Double.valueOf(eligibleAmountDeltaList[i]), Double.valueOf(actual_eligibleAmountDelta.getAsString()));
                    //   logger.info("The eligibleAmountDelta is : "+actual_eligibleAmountDelta.getAsString());
                    assertEquals("cpnRefundDeduction mismatch, Expected: " + cpnRefundDeductionList[i], Double.valueOf(cpnRefundDeductionList[i]), Double.valueOf(actual_cpnRefundDeduction.getAsString()));
                    //   assertEquals("intialCouponValue mismatch, Expected: "+unearnedValueList[i], Double.valueOf(unearnedValueList[i]),Double.valueOf(actual_redemptionStartDate.getAsString()));
                    //   assertEquals("intialCouponValue mismatch, Expected: "+unearnedValueList[i], Double.valueOf(unearnedValueList[i]),Double.valueOf(actual_redemptionEndDate.getAsString()));
                    //assertEquals("intialCouponValue mismatch, Expected: "+unearnedValueList[i], Double.valueOf(unearnedValueList[i]),Double.valueOf(actual_unEarnedValue.getAsString()));

                }

            }

        }

    }
}
