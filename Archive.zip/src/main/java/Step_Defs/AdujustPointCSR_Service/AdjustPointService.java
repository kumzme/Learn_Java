package Step_Defs.AdujustPointCSR_Service;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.w3c.dom.Document;

import static Utilities.General_Purpose_Utilities.soap_Client_For_Legacy_Apps;
import static Utilities.UtilConstants.*;


public class AdjustPointService {

    protected static final Logger logger = LogManager.getLogger(Object.class.getClass().getSimpleName());

    private String soapEndpointUrl, soapActionForCreateAccount, soapActionForUpdateMemberPoints;
    private String servicePayloadForCreateAccount, servicePayloadForUpdatePointMember, responseOfCreateAccount, responseOfUpdateMemberPoints;
    private Document xml_Doc;

    @Given("Create a payload with Email {string} and Points {string}")
    public void create_a_payload_with_Email(String email_Id, String points) throws Throwable {
        this.servicePayloadForCreateAccount = CREATE_ACCOUNT_PAYLOAD.replace("email_id", email_Id);
        //Todo @Team Add this url in project options.
        String soap_Host                  = ADJUST_POINT_SOAP_HOST;
        String soap_Uri                   = ADJUST_POINT_SOAP_URI;
        String soapMethodForCreateAccount = CREATE_ACCOUNT_METHOD;

        String soapMethodForUpdateMemberPoints = UPDATE_MEMBER_POINT_METHOD;
        this.servicePayloadForUpdatePointMember = UPDATE_MEMBER_POINT_PAYLOAD.replace("Loyalty_Point", points);

        this.soapEndpointUrl = soap_Host + soap_Uri;
        this.soapActionForCreateAccount = soap_Uri + soapMethodForCreateAccount;
        this.soapActionForUpdateMemberPoints = soap_Uri + soapMethodForUpdateMemberPoints;

    }

    @When("Send SOAP request to create account and Update Member Points")
    public void i_send_SOAP_request_to_create_account() throws Exception {
        this.responseOfCreateAccount = soap_Client_For_Legacy_Apps(this.soapEndpointUrl, this.soapActionForCreateAccount, this.servicePayloadForCreateAccount);
        String loyalyId = this.responseOfCreateAccount.substring(responseOfCreateAccount.lastIndexOf("<ns0:loyaltyNbr>") + 16, responseOfCreateAccount.lastIndexOf("</ns0:loyaltyNbr>"));
        this.servicePayloadForUpdatePointMember = this.servicePayloadForUpdatePointMember.replace("Loyalty_Id", loyalyId);
        this.responseOfUpdateMemberPoints = soap_Client_For_Legacy_Apps(this.soapEndpointUrl, this.soapActionForUpdateMemberPoints, this.servicePayloadForUpdatePointMember);
        logger.info("hello   " + responseOfUpdateMemberPoints);
        //    	this.xml_Doc            =   convert_Soap_Response_To_XML_Doc(response);
    }

    @Then("I should be able to verify the Response of Update Member Points")
    public void i_should_be_able_to_verify_the_Response_as_for_Create_Account_Service() throws Throwable {
        String loyalyId = this.responseOfCreateAccount.substring(responseOfCreateAccount.lastIndexOf("<ns0:loyaltyNbr>") + 16, responseOfCreateAccount.lastIndexOf("</ns0:loyaltyNbr>"));
        Assert.assertNotNull(loyalyId);
    }

}
