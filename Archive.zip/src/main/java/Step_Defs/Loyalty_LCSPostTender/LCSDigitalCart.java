
package Step_Defs.Loyalty_LCSPostTender;

import Utilities.Date_Util;
import com.google.gson.JsonObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import java.util.Map;

import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generate_Header;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.*;
import static Service_Functions.Rule_Config_Functionalities.post_New_Rule_Config;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.LPF_Invoker_Utilities.get_This_Project_Parameters;
import static Utilities.UtilConstants.Lcs_Data;
import static Utilities.UtilConstants.Response_Code;
import static Utilities.UtilConstants_Data_Rules_Reference.Reference_Payload;


public class LCSDigitalCart {

    protected static final Logger logger = LogManager.getLogger(new Object().getClass().getSimpleName());

    String sdf1;
    private Map raw_Headers, raw_Headers_get, project_Options, rule_config, lcs_Data;
    private JsonObject response;
    private String loyalty_Id, version;
    private String service_Name, service_Path, raw_Payload_get, pilot_base_Url, full_Url, raw_Payload,
            XKohls_Message_ID, secretKey, sys_Cd, corr_Id, message_Hdr, method_Name;
    private static boolean got_Parms = false;
    Date_Util dateUtil = new Date_Util();
    JsonObject this_Object = new JsonObject();

    @Given("Able to retrieve and set the rule {string} config for LCSpostTender")
    public void setUpFor_Rule_Config_Steps(String rule_Payload) throws Exception {
        this_Object.addProperty(Reference_Payload, rule_Payload);
        post_New_Rule_Config(this_Object);
        this.project_Options = get_This_Project_Parameters();

    }

    /*@Duplicate @Team*/
    @Given("Connected with {string} service to {string} for {string} type for LCSpostTender DigitalCart")
    public void serviceConnection(String service_NameFrom_Feature, String endpoint, String testCase) throws Exception {
        service_Name = service_NameFrom_Feature;
        this.pilot_base_Url = this.project_Options.get(endpoint).toString();
        logger.info("urls   " + pilot_base_Url);
        logger.info("service_Name " + service_Name + " for testcase +" + testCase);
    }

    @When("I {string} to LCSpostTender type with {string} format, with headers  {string} for {string} and  {string} and  {string} and {string}")
    public void formatHeaderPreTender(String methodType, String format, String standard_Post_Header,
                                      String xKOHLS_From_System_Code, String xKOHLS_Correlation_ID, String xKOHLS_Message_ID, String secretKey)
            throws Exception {
        this.service_Path = "/" + this.service_Name;
        logger.info("xKOHLS_Correlation_ID " + xKOHLS_Correlation_ID);
        logger.info("xKOHLS_Message_ID " + xKOHLS_Message_ID);
        this.sdf1 = generate_Header_Date_TS();
        this.XKohls_Message_ID = xKOHLS_Message_ID;
        this.secretKey = secretKey;
        this.corr_Id = xKOHLS_Correlation_ID;
        this.sys_Cd = xKOHLS_From_System_Code;
        this.message_Hdr = standard_Post_Header;
        this.method_Name = methodType;
        logger.info("corr_Id " + corr_Id);
        logger.info("XKohls_Message_ID " + XKohls_Message_ID);

    }

    @When("I have create the payload for LCSpostTender Test Case Number {string} with loyaltyID as {string} storeNumber as {string} departmentOne as {string} skuOne as {string} yourPriceOne as {string} quantityOne as {string} departmenTwo as {string} skuTwo as {string} yourPriceTwo as {string} quantityTwo as {string} departmentThree as {string} skuThree as {string} yourPriceThree as {string} quantityThree as {string} typeCode as {string} tenderAmount as {string} transactionDate as {string} for payload as {string}")
    public void I_Post_PayloadPreTender_LoyaltyID(String testCaseNumber, String localtyID, String storeNumber, String department1, String sku1,
                                                  String yourPrice1, String quantity1, String department2, String sku2, String yourPrice2, String quantity2,
                                                  String department3, String sku3, String yourPrice3, String quantity3, String typeCode, String tenderAmount, String transactionDate,
                                                  String payload) throws Exception {

        lcs_Data = read_Yaml(get_Data_Folders() + Lcs_Data);
        raw_Payload = (String) lcs_Data.get(payload);
        String TransactionDate = dateUtil.returndate(1);

        String encoded_Auth_String = getSignatureForPOSTCallSpendTrackerMash(raw_Payload, service_Path,
                XKohls_Message_ID, secretKey, sdf1);

        this.raw_Headers = generate_Header(message_Hdr, sdf1, sys_Cd, XKohls_Message_ID, corr_Id,
                method_Name.toLowerCase(), encoded_Auth_String);

        full_Url = this.pilot_base_Url + service_Path;
        logger.info("The full url is: " + full_Url);

        response = restClient_Any_Method(raw_Payload, raw_Headers, this.full_Url, this.method_Name);

        logger.info(response.get(Response_Code));

    }

    @Then("Should be able to verify the LCSpostTender Response of test case number {string} as {string}")
    public void verifyPostTenderNonPilot(String testCaseNum, String success_Or_Fail) throws Throwable {
        if(testCaseNum.equals("Test_001") ){
            Assert.assertEquals("200", response.get("Response_Code").getAsString());
        }
    }

}
