package Service_Functions;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import java.util.Map;

import static Service_Functions.V2.V2_Audit_Balance_Functions.v1_Create_New_Loyid_With_Bal_Servc;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.UtilConstants.Pilot_Service_Pilot_Members;
import static Utilities.UtilConstants.Pilot_Service_Url;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class Pilot_Checker_Functionalities {
    protected static final Logger logger = get_Logger();

    /*Reviewer Changes*/
    /*@Remove How to check for Pilot changes Ask QA*/
    @Step
    public static JsonObject Generate_Pilot_Customers_With_New_Loyalty_IDs(JsonObject got_Data) throws Exception {

        /* Service-1 : Create loyids with balance lookup */
        JsonObject loyalty_Data = v1_Create_New_Loyid_With_Bal_Servc(got_Data);
        String     raw_Payload  = consolidated_Data.get("Payload_Template_For_Post_PilotChecker_Service").getAsString();

        for (Map.Entry<String, JsonElement> loyalty_Id : loyalty_Data.entrySet()) {

            JsonObject send_This = new JsonObject();
            send_This.addProperty(Reference_Method, Reference_Method_Put);
            send_This.addProperty(Reference_Payload, raw_Payload);
            send_This.addProperty(Reference_Api_Path, Pilot_Service_Pilot_Members + "/" + loyalty_Id.getValue().getAsString());
            send_This.addProperty(Reference_Api_Url, Pilot_Service_Url);
            logger.info("send_This value is $$$ : " + send_This.toString());

            /* Service-2 : Pilot checker code to store loyid */
            JsonObject response_From_Api = restClient_Method(send_This);

            logger.info("response_From_Api for loyid " + loyalty_Id.getValue() + " is :" + response_From_Api);
        }
        return loyalty_Data;
    }

    public static void get_Pilot_Data(String payload_Reference, JsonObject any_Other_Values) throws Exception {

    }


}
