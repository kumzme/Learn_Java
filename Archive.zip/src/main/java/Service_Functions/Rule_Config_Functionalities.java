package Service_Functions;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Sql;
import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.DB_Utilities.execute_SQL_MySQL_DB_CRUD;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.Lpf_Assert_Utilities.assert_200_Or_201;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class Rule_Config_Functionalities {

    protected static final Logger logger = get_Logger();

    /**
     * @param all_Values
     * <br> Reference_Payload for Rule
     * @return Updated Rule
     * @throws Exception
     */
    @Step
    public static String post_New_Rule_Config(JsonObject all_Values) throws Exception {

        String Rule_Key_Reference  = all_Values.get(Reference_Payload).getAsString();
        int    rule_Version        = get_Rules_Version_To_PostString(Get_Rule_Config_Latest_Version);
        String rule_Version_String = String.valueOf(rule_Version);

        all_Values.addProperty(Rule_Replace_Latest_Rule_Version, String.valueOf(rule_Version));

        String     rule_Updated = parse_And_Generate_Data(Rule_Key_Reference, all_Values);
        JsonObject send_This    = new JsonObject();

        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Payload, rule_Updated);
        send_This.addProperty(Reference_Api_Path, Rules_Service);
        send_This.addProperty(Reference_Api_Url, Rules_Service_Url);
        JsonObject response = restClient_Method(send_This);

        String rule_Config_Version = response.get(Response_Body).getAsJsonObject().get("version").getAsString();
        ensure_That_LCS_Has_Been_Synced_With_Latest_Rules(rule_Config_Version);

        assert_200_Or_201(response.get(Response_Code).getAsInt());


        return rule_Updated;
    }


    @Step
    public static int get_Rules_Version_To_PostString(String sql_KeyName_From_SQLFolder) throws Exception {

        String                  sql                = consolidated_Sql.get(sql_KeyName_From_SQLFolder).getAsString();
        ArrayList<List<String>> sql_Result         = execute_SQL_MySQL_DB_CRUD(sql);
        String                  max_Rule_Version   = sql_Result.get(0).get(0);
        int                     need_Rules_Version = Integer.parseInt(max_Rule_Version) + 1;
        logger.info(need_Rules_Version);
        return need_Rules_Version;

    }

    @Step
    public static void ensure_That_LCS_Has_Been_Synced_With_Latest_Rules(String latest_Version_That_We_Posted) throws Exception {
        JsonObject send_This          = new JsonObject();
        String     Rules_Url_to_Check = project_Parameters.get(Rules_Service_Url).getAsString() + Rules_Service + "/" + latest_Version_That_We_Posted;

        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Payload, "Blanks");
        send_This.addProperty(Reference_Api_Path, LCS_Path_Update_Rules);
        send_This.addProperty(Reference_Api_Param, LCS_Path_Update_Rules_rulesUrl_Param + Rules_Url_to_Check);
        send_This.addProperty(Reference_Api_Url, LCS_Url);

        JsonObject response = restClient_Method(send_This);

        assert_200_Or_201(response.get(Response_Code).getAsInt());

    }

}
