package Service_Functions;

import Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS;
import Utilities.Date_Util;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.log4j.Logger;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static Step_Defs.XHooks.Project_Before_Hooks.project_Parameters;
import static Utilities.DB_Utilities.execute_SQL_MySQL_DB_CRUD;
import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Any_Method;
import static Utilities.UtilConstants.Response_Code;
import static jdk.nashorn.internal.objects.NativeMath.round;
import static org.junit.Assert.assertEquals;

public class Check_Where_V2_Or_V1_Validation_Methods {

    protected static final Logger logger = get_Logger();

    public static ArrayList<List<String>> DBValidate(JsonObject data, String sql_KeyName_From_SQLFolder) throws Exception {

        /*
        String transactionNbr = data.get("transactionNbr").getAsString();
        String storeNbr = data.get("storeNbr").getAsString();
        String registerId = data.get("registerId").getAsString();
        String transactionDate = data.get("transactionDate").getAsString();
        String transactionTime = data.get("transactionTime").getAsString();

        String ExptranId = transactionNbr.toString() + "-S" + storeNbr + "R" + registerId + "T" + StringUtils.remove(transactionDate.toString(), "-") + StringUtils.remove(transactionTime.toString(), ':');
        */

       /* String sql = "select * from  auditservices.original_transaction where loyalty_id='Replace_LoyId'";//81712570000 consolidated_Sql.get(sql_KeyName_From_SQLFolder).getAsString();
        if(sql.contains("Replace_LoyId"))
        	sql.replace("Replace_LoyId", data.get("Generic_Loyalty_Id_0").getAsString());*/

        ArrayList<List<String>> sql_Result = execute_SQL_MySQL_DB_CRUD(sql_KeyName_From_SQLFolder);
        logger.info("sql_Result is $$$ :" + sql_Result.toString());
        return sql_Result;
    }

    public static Map<String, String> pc_Response_Validation(String pointsToConvert, String totalEarnTracker) {
        Map<String, String> pcMap = new HashMap<>();
        pcMap.put("convertedKcAmt", "");
        pcMap.put("earnTrackerDelta", "");
        pcMap.put("updatedEarnTrackerBal", "");
        pcMap.put("spendAwayEverydayNonKcc", "");
        pcMap.put("spendAwayEverydayKcc", "");

        String        updatedEarnTrackerBal;
        String        convertedKcAmt;
        String        earnTrackerDelta;
        DecimalFormat decimal = new DecimalFormat("0.00");

        float update = (float) (Float.parseFloat(totalEarnTracker) + (Float.parseFloat(pointsToConvert) * 0.05));

        float modvalue = update % 5;
        updatedEarnTrackerBal = modvalue + "";
        logger.info("The value of updatedEarnTracker before is : " + updatedEarnTrackerBal);
        updatedEarnTrackerBal = Float.parseFloat(updatedEarnTrackerBal) + "";
        logger.info("The value of updatedEarnTracker after is : " + updatedEarnTrackerBal);
        String formatted_updatedEarnTrackerBal = decimal.format(Float.parseFloat(updatedEarnTrackerBal));
        float  kcamt                           = update - modvalue;
        convertedKcAmt = kcamt + "";
        String formatted_convertedKcAmt = decimal.format(Float.parseFloat(convertedKcAmt));
        //		earnTrackerDelta=modvalue-Float.parseFloat(totalEarnTracker)+"";
        //		earnTrackerDelta=round(Float.parseFloat(earnTrackerDelta),2)+"";
			/*if(!System.getProperty("PointsConvert").equalsIgnoreCase("0"))
				updatedEarnTrackerBal=Float.parseFloat(System.getProperty("PointsConvert"))*0.05+Float.parseFloat(System.getProperty("totalEarnTracker"))+"";
			else
				updatedEarnTrackerBal=Float.parseFloat(System.getProperty("totalEarnTracker"))+"";
			Float convertkc=Float.parseFloat(updatedEarnTrackerBal);
			convertkc=convertkc-(convertkc%5);
			updatedEarnTrackerBal=convertkc%5+"";
			String convertedKcAmt=convertkc+"";
			String earnTrackerDelta=Float.parseFloat(System.getProperty("updatedEarnTrackerBal"))-Float.parseFloat(System.getProperty("totalEarnTracker"))+"";*/

        String redemptionStartDate;
        String redemptionEndDate;

        //   DecimalFormat decimal = new DecimalFormat("0.00");
        String spendAwayEverydayNonKcc;

        float beforeFormat = (5 - (Float.parseFloat(updatedEarnTrackerBal))) * 20;
        logger.info("Before formatting spendAwayEverydayNonKcc: " + beforeFormat);
        spendAwayEverydayNonKcc = decimal.format(beforeFormat);

        logger.info("After formatting spendAwayEverydayNonKcc: " + spendAwayEverydayNonKcc);
        logger.info("Before formatting earnTrackerDelta: " + (modvalue - Float.parseFloat(totalEarnTracker)));

        earnTrackerDelta = decimal.format((modvalue - Float.parseFloat(totalEarnTracker)));

        logger.info("After formatting earnTrackerDelta: " + earnTrackerDelta);

        //	String spendAwayEverydayNonKcc=round(((5-(Float.parseFloat(updatedEarnTrackerBal)))*20),2)+"";
        String spendAwayEverydayKcc = round(((5 - (Float.parseFloat(updatedEarnTrackerBal))) * 10), 2) + "";
        String barcode;

        /*
            System.setProperty("convertedKcAmt",convertedKcAmt);
			System.setProperty("earnTrackerDelta",earnTrackerDelta);
			System.setProperty("updatedEarnTrackerBal",updatedEarnTrackerBal);
			System.setProperty("redemptionStartDate","");
			System.setProperty("redemptionEndDate","");
			System.setProperty("spendAwayEverydayNonKcc",spendAwayEverydayNonKcc);
			System.setProperty("spendAwayEverydayKcc",spendAwayEverydayKcc);
			System.setProperty("barcode","");
        */

        pcMap.put("convertedKcAmt", formatted_convertedKcAmt);
        pcMap.put("earnTrackerDelta", earnTrackerDelta);
        pcMap.put("updatedEarnTrackerBal", formatted_updatedEarnTrackerBal);
        pcMap.put("spendAwayEverydayNonKcc", spendAwayEverydayNonKcc);
        pcMap.put("spendAwayEverydayKcc", spendAwayEverydayKcc);

        return pcMap;
    }

    public static void validateProductDetails(JsonArray pdet, HashMap<String, String> expRespMap, String deptcount) {

        logger.info("validating product details...line number $$$" + expRespMap.get("lineNumber1"));
        logger.info("map is $$$" + expRespMap.values());

        logger.info("response details $$$ :" + pdet.toString());
        for (int i = 1; i <= Integer.parseInt(deptcount); i++) {
            for (int j = 1; j <= Integer.parseInt(deptcount); j++) {
                JsonObject jobj          = (JsonObject) pdet.get(j - 1);
                String     actualLinenum = jobj.get("lineNumber").getAsString();
                if (expRespMap.get("lineNumber" + i).equalsIgnoreCase(actualLinenum)) {
                    logger.info("lineNumber is $$$...:" + actualLinenum + " and exp $$$ :" +
                                                                     expRespMap.get("lineNumber" + i));
                    assertEquals("lineNumber:", expRespMap.get("lineNumber" + i), actualLinenum);
                    String dept = jobj.get("department").getAsString();
                    assertEquals("department:", expRespMap.get("dept" + i), dept);
                    String actualSku = jobj.get("sku").getAsString();
                    assertEquals("sku:", expRespMap.get("sku" + i), actualSku);
                    String actualNetPrice = jobj.get("netPrice").getAsString();
                    assertEquals("NetPrice:", expRespMap.get("netPrice" + i), actualNetPrice);
                    String actualEligibleAmt = jobj.get("kohlsCashEligible").getAsString();
                    assertEquals("kohlsCashEligible:", expRespMap.get("kohlsCashEligible" + i), actualEligibleAmt);
                }
            }
        }

    }

    public static Map<String, String> getEventDates(String id) throws Exception {

        String                  sdf1;
        Map                     raw_Headers_get;
        JsonObject              response;
        String                  service_Name, pilot_base_Url, full_Url;
        String                  message_Hdr            = "Header_Template_For_Rest";
        String                  sys_Cd                 = "kc";
        String                  corr_Id                = "1231";
        String                  version                = "version";
        String                  keyid                  = "id";
        String                  keyeventName           = "eventName";
        String                  keyactivationStartDate = "activationStartDate";
        String                  keyactivationEndDate   = "activationEndDate";
        String                  keyredemptionStartDate = "redemptionStartDate";
        String                  keyredemptionEndDate   = "redemptionEndDate";
        HashMap<String, String> evntdet                = new HashMap<>();



        service_Name = "rules";
        String service_Path = "/" + service_Name;
        pilot_base_Url = project_Parameters.get("RulesEndpoint").getAsString();

        sdf1 = LPF_Functional_Utilities_Loyalty_LCS.generate_Header_Date_TS_TimeZone();
        String encoded_Auth_String = LPF_Functional_Utilities_Loyalty_LCS.getSignatureForRuleConfigGetCall(service_Path, "5319c8f5-55f2-4605-82b5-662914da01b2", sdf1);

        raw_Headers_get = LPF_Functional_Utilities_Loyalty_LCS.generate_Header(message_Hdr, sdf1, sys_Cd, "5319c8f5-55f2-4605-82b5-662914da01b2", corr_Id, "get", encoded_Auth_String);
        full_Url = pilot_base_Url + service_Path;

        String raw_Payload_get = "";
        response = restClient_Any_Method(raw_Payload_get, raw_Headers_get, full_Url, "get");

        logger.info("Response for dates $$$... :" + response);
        logger.info(response.get(Response_Code));

        JsonArray  aa        = response.getAsJsonObject("Response_Body").getAsJsonObject("_embedded").getAsJsonArray("rules");
        JsonObject pare      = (JsonObject) aa.get(aa.size() - 1);
        JsonArray  evntrules = pare.getAsJsonArray("eventKohlsCash");
        evntdet.put(version, "" + pare.get(version).getAsInt());

        //Todo
        //for( JsonElement evntrule: evntrules) if ( ! evntrule.getAsJsonObject().get(keyid).getAsString().equalsIgnoreCase(id)) evntrules.remove(evntrule) ; return evntrules;

        for (int i = 0; i < evntrules.size(); i++) {
            JsonObject evntrule = (JsonObject) evntrules.get(i);
            String     evntid   = "" + evntrule.get(keyid).getAsInt();
            if (id.equalsIgnoreCase(evntid.trim())) {
                String evntname = evntrule.get(keyeventName).getAsString();
                String sdate    = Date_Util.changeDateFormat(evntrule.get(keyactivationStartDate).getAsString());
                String edate    = Date_Util.changeDateFormat(evntrule.get(keyactivationEndDate).getAsString());
                String restart  = Date_Util.changeDateFormat(evntrule.get(keyredemptionStartDate).getAsString());
                String reend    = Date_Util.changeDateFormat(evntrule.get(keyredemptionEndDate).getAsString());
                evntdet.put(keyid, evntid);
                evntdet.put(keyeventName, evntname);
                evntdet.put(keyactivationStartDate, sdate);
                evntdet.put(keyactivationEndDate, edate);
                evntdet.put(keyredemptionStartDate, restart);
                evntdet.put(keyredemptionEndDate, reend);
                break;
            }
        }
        return evntdet;

    }

}
