package Service_Functions.V2;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import static Functional_Utilities.Functional_Data_Generator.parse_And_Generate_Data;
import static Functional_Utilities.LPF_Functional_Utilities_Loyalty_LCS.generateLoyaltyIdRandom;
import static Step_Defs.XHooks.Project_Before_Hooks.consolidated_Data;
import static Utilities.General_Purpose_Utilities.*;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class V2_Audit_Balance_Functions {
    protected static final Logger logger = get_Logger();


    @Step
    public static JsonObject get_Audit_Balance(String loyalty_Id) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Audit_Balance_Service + "/" + loyalty_Id);
        send_This.addProperty(Reference_Api_Url, Audit_Balance_Service_Url);
        JsonObject response_From_Api = restClient_Method(send_This);
        return response_From_Api;
    }


    @Step
    public static JsonObject get_Balance_1348(JsonObject got_Data) throws Exception {

        String raw_Payload = consolidated_Data.get("Payload_Template_For_Balance_Service").getAsString();

        String loyalty_Id = got_Data.get("Replace_Loyalty_Id").getAsString();

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Payload, raw_Payload);
        send_This.addProperty(Reference_Api_Path, Audit_Balance_Service + "/" + loyalty_Id);
            
            /*if(got_Data.toString().contains("Invalid_URL"))
            	send_This.addProperty(Reference_Api_Url, "Invalid_URL");
            else */
        send_This.addProperty(Reference_Api_Url, Audit_Balance_Service_Url);

        //adding header values
        send_This.addProperty("message_Id", got_Data.get("message_Id").getAsString());
        send_This.addProperty("time_Stamp", got_Data.get("time_Stamp").getAsString());
        send_This.addProperty("system_Cd", got_Data.get("system_Cd").getAsString());
        send_This.addProperty("corrln_Id", got_Data.get("corrln_Id").getAsString());
        send_This.addProperty("API_KEY", got_Data.get("API_KEY").getAsString());
        send_This.addProperty("SecretKey", got_Data.get("SecretKey").getAsString());

        if (got_Data.toString().contains("No_Header"))
            send_This.addProperty("No_Header", "No_Header");
        if (got_Data.toString().contains("404_example"))
            send_This.addProperty("404_example", "404_example");
        if (got_Data.toString().contains("400_example"))
            send_This.addProperty("400_example", "400_example");
        if (got_Data.toString().contains("Empty_Secret"))
            send_This.addProperty("Empty_Secret", "Empty_Secret");
        if (got_Data.toString().contains("Remove_msgId"))
            send_This.addProperty("Remove_msgId", "Remove_msgId");
        if (got_Data.toString().contains("Remove_date"))
            send_This.addProperty("Remove_date", "Remove_date");
        if (got_Data.toString().contains("Invalid_MsgId"))
            send_This.addProperty("Invalid_MsgId", "Invalid_MsgId");

        logger.info("send_This value is $$$ : " + send_This.toString());

        JsonObject response_From_Api = restClient_Method_Negative(send_This);

        if (got_Data.toString().contains("No_Header"))
            send_This.remove("No_Header");
        if (got_Data.toString().contains("404_example"))
            send_This.remove("404_example");
        if (got_Data.toString().contains("400_example"))
            send_This.remove("400_example");

        logger.info("response_From_Api for loyid " + loyalty_Id + " is :" + response_From_Api);
        return response_From_Api;
    }

    @Step
    public static JsonObject v1_Create_New_Loyid_With_Bal_Servc(JsonObject got_Data) throws Exception {

        String     loyaltyId, raw_Payload;
        JsonObject response_From_Api_put;
        JsonObject return_Data = new JsonObject();
        JsonObject pass_Data   = new JsonObject();
        int        count       = got_Data.get(Total_Loyalty_Ids_Needed).getAsInt();


        for (int i = 0; i < count; i++) {

            /*@Remove? Changes Todo ?? check  */ //loyaltyId = get_Value_From_Data_Folders("Generic_Loyalty_Id_" + i);
            loyaltyId = generateLoyaltyIdRandom();

            return_Data.addProperty("Generic_Loyalty_Id_" + i, loyaltyId);


            String payload_reference_Key = got_Data.get(Reference_Payload).getAsString();
            pass_Data.addProperty("Replace_Loyalty_Id", loyaltyId);
            raw_Payload = parse_And_Generate_Data(payload_reference_Key, pass_Data);


            JsonObject send_This = new JsonObject();
            send_This.addProperty(Reference_Method, Reference_Method_Put);
            send_This.addProperty(Reference_Payload, raw_Payload);
            send_This.addProperty(Reference_Api_Path, Loyalty_Balance_Balances + "/" + loyaltyId);
            send_This.addProperty(Reference_Api_Url, Loyalty_Balance_Url);


            response_From_Api_put = restClient_Method(send_This);

            logger.info("response_From_Api_put is $$$ ... :" + response_From_Api_put.toString());
        }

        return return_Data;
    }
}
