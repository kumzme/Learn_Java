package Service_Functions.V2;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;

import static Functional_Utilities.V2_Audit_Rewards_Mongo_Functions.get_Rewards_Activity_First_Row;
import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.General_Purpose_Utilities.restClient_Method_Negative;
import static Utilities.UtilConstants.Audit_Balance_Service_Url;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class V2_Get_ActivityId_Service {
	
	@Step
    public static JsonObject get_Activity_Details(String activity_Id) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, "/audit/activities" + "/" + activity_Id);
        send_This.addProperty(Reference_Api_Url, Audit_Balance_Service_Url);
        JsonObject response_From_Api = restClient_Method(send_This);
        return response_From_Api;
    }

    @Step
    public static String get_Activity_Id_From_Activity_Document(String loyalty_Id) throws Exception {

        JsonObject first_Row = get_Rewards_Activity_First_Row(loyalty_Id);
        return first_Row.get("_id").getAsJsonObject().get("$oid").getAsString();
    }

	
	@Step
    public static JsonObject get_Activity_Details_Negative(JsonObject got_Data) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, "/audit/activities" + "/" + got_Data.get("activity_Id").getAsString());
        send_This.addProperty(Reference_Api_Url, Audit_Balance_Service_Url);
        
      //adding header values
        send_This.addProperty("message_Id", got_Data.get("message_Id").getAsString());
        send_This.addProperty("time_Stamp", got_Data.get("time_Stamp").getAsString());
        send_This.addProperty("system_Cd", got_Data.get("system_Cd").getAsString());
        send_This.addProperty("corrln_Id", got_Data.get("corrln_Id").getAsString());
        send_This.addProperty("API_KEY", got_Data.get("API_KEY").getAsString());
        send_This.addProperty("SecretKey", got_Data.get("SecretKey").getAsString());

        if (got_Data.toString().contains("No_Header"))
            send_This.addProperty("No_Header", "No_Header");
        if (got_Data.toString().contains("404_example"))
            send_This.addProperty("404_example", "404_example");
        if (got_Data.toString().contains("400_example"))
            send_This.addProperty("400_example", "400_example");
        if (got_Data.toString().contains("Empty_Secret"))
            send_This.addProperty("Empty_Secret", "Empty_Secret");
        if (got_Data.toString().contains("Remove_msgId"))
            send_This.addProperty("Remove_msgId", "Remove_msgId");
        if (got_Data.toString().contains("Remove_date"))
            send_This.addProperty("Remove_date", "Remove_date");
        if (got_Data.toString().contains("Invalid_MsgId"))
            send_This.addProperty("Invalid_MsgId", "Invalid_MsgId");
        
        
        
        JsonObject response_From_Api = restClient_Method_Negative(send_This);
        return response_From_Api;
    }
}
