package Service_Functions.V2;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.bson.Document;

import java.text.DecimalFormat;
import java.util.ArrayList;

import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class V2_Audit_Rewards {

    protected static final Logger logger = get_Logger();

    @Step
    public static JsonObject calculateEarnDetail(JsonObject sale) {

        String tender = sale.get(TenderType).getAsString().replaceAll("Giftcard_and_", "");
        String type = "";
        switch (tender) {
            case "Amex":
                type = "08";
                break;
            case "Discover":
                type = "07";
                break;
            case "VISA":
                type = "05";
                break;
            case "Mastercard":
                type = "06";
                break;
            case "Giftcard":
                type = "13";
                break;
            case "KCC":
                type = "04";
                break;
            default:
                type = "00";
                break;
        }

        sale.addProperty(Tender_Typecode, type);
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println("The value of sale object is: "+ sale.toString());
        Double qual = sale.get(Qualifying_Amount).getAsDouble();

        sale.addProperty(Total_Amount, df.format(qual + qual * 5 / 100));
        if(sale.get(TenderType).getAsString().contains("Giftcard_and")) {
        	Double tenderAmt = qual + qual * 5 / 100;
        	sale.addProperty(Total_1Amount, df.format(tenderAmt*0.3));
        	sale.addProperty(Total_2Amount, df.format(tenderAmt*0.7));
        }

        if (type.equals("04")) {
        	if(sale.get(TenderType).getAsString().contains("Giftcard_and_KCC")) {
                sale.addProperty(Everyday_Kcc_Earned, df.format((qual*0.7) * 10 / 100));
                sale.addProperty(Everyday_NonKcc_Earned, df.format((qual*0.3) * 5 / 100));
        	}else {
                sale.addProperty(Everyday_Kcc_Earned, df.format(qual * 10 / 100));
                sale.addProperty(Everyday_NonKcc_Earned, 0.0);
			}
        } else {
            sale.addProperty(Everyday_Kcc_Earned, 0.0);
            sale.addProperty(Everyday_NonKcc_Earned, df.format(qual * 5 / 100));
        }
        
        if (sale.get(Event_kohlscash).getAsString().equals("Yes")) {
            Double val = (qual + 2) / 50;
            sale.addProperty("Replace_eventAmount", val.intValue() * 10.00);
        } else {
            sale.addProperty("ReplaceBarcode62486GenerateRandomNum_000", "");
            sale.addProperty("Replace_eventAmount", 0.0);
        }
        if (sale.get(Return_Type) != null)
            if (sale.get(Return_Type).getAsString().equals("Partial")) {
                sale.addProperty(SKU1_Amount, sale.get(Return_Amount).getAsString());
                sale.addProperty(SKU2_Amount, df.format(qual - sale.get(Return_Amount).getAsDouble()));
            }


        return sale;
    }


    @Step
    public static JsonObject createReturnPayload(JsonObject saleResp) {
        JsonObject retunReq = new JsonObject();
        JsonObject body = saleResp.getAsJsonObject("messageBody");
        DecimalFormat df = new DecimalFormat("#.##");

        retunReq.addProperty(Refer_Rule_Replace_Loyalty_Id, body.get("loyaltyId").getAsString());
        retunReq.addProperty(Tender_Typecode, body.get("tenders").getAsJsonArray().get(0).getAsJsonObject().get("typeCode").getAsString());

        JsonObject transKey = saleResp.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");
        retunReq.addProperty(Rule_Replace_Transaction_Nbr, transKey.get("transactionNbr").getAsString());
        retunReq.addProperty(Rule_Replace_Transaction_Date, transKey.get("transactionDate").getAsString());
        retunReq.addProperty(Rule_Replace_Transaction_Time, transKey.get("transactionTime").getAsString());
        retunReq.addProperty("ReplaceBarcode62486GenerateRandomNum_000", body.get("coupons").getAsJsonArray().get(0).getAsJsonObject().get("barcode").getAsString());
        
        if(body.get("tenders").getAsJsonArray().size() > 1)
        retunReq.addProperty(Tender_Typecode, body.get("tenders").getAsJsonArray().get(1).getAsJsonObject().get("typeCode").getAsString());

        if (saleResp.get(Return_Type).getAsString().equals("Full")) {
            retunReq.addProperty(Qualifying_Amount, "-" + body.get("earnDetail").getAsJsonObject().get("qualifyingAmt").getAsString());
            if(body.get("tenders").getAsJsonArray().size() > 1) {
            	retunReq.addProperty(Total_1Amount, "-" + body.get("tenders").getAsJsonArray().get(0).getAsJsonObject().get("amount").getAsString());
            	retunReq.addProperty(Total_2Amount, "-" + body.get("tenders").getAsJsonArray().get(1).getAsJsonObject().get("amount").getAsString());
            	
            }
            retunReq.addProperty(Total_Amount, "-" + body.get("totalAmount").getAsString());
            String eventAmount = body.get("coupons").getAsJsonArray().get(0).getAsJsonObject().get("eventAmount").getAsString();
            if (eventAmount.equals("0.0")) {
                retunReq.addProperty("Replace_eventAmount", eventAmount);
            } else {
                retunReq.addProperty("Replace_eventAmount", "-" + eventAmount);
            }

            String everydayKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayKccEarned").getAsString();
            if (everydayKccEarned.equals("0.0")) {
                retunReq.addProperty(Everyday_Kcc_Earned, everydayKccEarned);

            } else {
                retunReq.addProperty(Everyday_Kcc_Earned, "-" + everydayKccEarned);
                retunReq.addProperty(Earn_Tracker_ReductionAmt, "-" + everydayKccEarned);
            }

            String everydayNonKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayNonKccEarned").getAsString();
            if (everydayNonKccEarned.equals("0.0")) {
                retunReq.addProperty(Everyday_NonKcc_Earned, everydayNonKccEarned);

            } else {
                retunReq.addProperty(Everyday_NonKcc_Earned, "-" + everydayNonKccEarned);
                retunReq.addProperty(Earn_Tracker_ReductionAmt, "-" + everydayNonKccEarned);
            }
        }

        if (saleResp.get(Return_Type).getAsString().equals("Partial")) {
            Double qualifying = body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble();
            retunReq.addProperty(Qualifying_Amount, "-" + qualifying);
            retunReq.addProperty(Total_Amount, "-" + df.format(qualifying + qualifying * 5 / 100));

            if(body.get("tenders").getAsJsonArray().size() > 1) {
            	retunReq.addProperty(Total_1Amount, "-" + df.format((qualifying + qualifying * 5 / 100)*0.3));
            	retunReq.addProperty(Total_2Amount, "-" + df.format((qualifying + qualifying * 5 / 100)*0.7));
            }
            //Event Amount
            Double val = (qualifying + 2) / 50;
            retunReq.addProperty("Replace_eventAmount", "-"+val.intValue() * 10.00);

            //EarnDetail
            String everydayKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayKccEarned").getAsString();

            if (everydayKccEarned.equals("0.0")) {
                retunReq.addProperty(Everyday_Kcc_Earned, everydayKccEarned);

            } else {
                retunReq.addProperty(Everyday_Kcc_Earned, "-" + df.format(qualifying * 10 / 100));
                if(body.get("tenders").getAsJsonArray().size() > 1)
                	retunReq.addProperty(Everyday_Kcc_Earned, "-" + df.format((qualifying*0.7) * 10 / 100));
            }

            String everydayNonKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayNonKccEarned").getAsString();
            if (everydayNonKccEarned.equals("0.0")) {
                retunReq.addProperty(Everyday_NonKcc_Earned, everydayNonKccEarned);

            } else {
                retunReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format(qualifying * 5 / 100));
                if(body.get("tenders").getAsJsonArray().size() > 1)
                	retunReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format((qualifying*0.3) * 5 / 100));
            }
        }


        return retunReq;
    }

    @Step
    @Deprecated
    public static void validateActivityTable(Document expd, Document actl, JsonObject dynmc) {
        SoftAssertions soft = new SoftAssertions();
        String trnsName = dynmc.get("trnsName").toString();

        soft.assertThat(actl.get("loyaltyId").toString()).as(trnsName + " loyaltyId is :").isEqualTo(dynmc.get("loyaltyId").toString().replaceAll("\"", ""));


        soft.assertThat(actl.get("_id")).as(trnsName + " ActivityID is:").isNotNull();
        soft.assertThat(actl.get("createdOn")).as(trnsName + " createdOn is :").isNotNull();
        if (expd.get("orderNbr") != null)
            soft.assertThat(actl.get("orderNbr")).as(trnsName + " orderNbr is :").isEqualTo(expd.get("orderNbr"));


        //soft.assertThat(actl.get("activityDate")).as(trnsName+" activityDate is :").isEqualTo(expd.get("activityDate"));
        //soft.assertThat(actl.get("activityTime")).as(trnsName+" activityTime is :").isEqualTo(expd.get("activityTime"));
        soft.assertThat(actl.get("activityDate")).as(trnsName + " activityDate is :").isNotNull();
        soft.assertThat(actl.get("activityTime")).as(trnsName + " activityTime is :").isNotNull();

        soft.assertThat(actl.get("sourceSystemCode")).as(trnsName + " sourceSystemCode is :").isEqualTo(expd.get("sourceSystemCode"));
        soft.assertThat(actl.get("fulfillment")).as(trnsName + " fulfillment is :").isEqualTo(expd.get("fulfillment"));
        soft.assertThat(actl.get("activityTypeCode")).as(trnsName + " activityTypeCode is :").isEqualTo(expd.get("activityTypeCode"));
        soft.assertThat(actl.get("activityDesc")).as(trnsName + " activityDesc is :").isEqualTo(expd.get("activityDesc"));
        soft.assertThat(actl.get("transactionAmt")).as(trnsName + " transactionAmt is :").isEqualTo(expd.get("transactionAmt"));
        soft.assertThat(actl.get("everydayKcc")).as(trnsName + " everydayKcc is :").isEqualTo(expd.get("everydayKcc"));
        soft.assertThat(actl.get("everydayNonkcc")).as(trnsName + " everydayNonkcc is :").isEqualTo(expd.get("everydayNonkcc"));
        soft.assertThat(actl.get("everydayImpactAmt")).as(trnsName + " everydayImpactAmt is :").isEqualTo(expd.get("everydayImpactAmt"));
        /*soft.assertThat(actl.get("everydayTotalAmt")).as(trnsName + " everydayTotalAmt is :").isEqualTo(expd.get("everydayTotalAmt"));*//*Mahesh*/
        soft.assertThat(actl.get("qualifyingAmt")).as(trnsName + " qualifyingAmt is :").isEqualTo(expd.get("qualifyingAmt"));
        soft.assertThat(actl.get("refundDeduction")).as(trnsName + " refundDeduction is :").isEqualTo(expd.get("refundDeduction"));
        soft.assertThat(actl.get("createdBy")).as(trnsName + " createdBy is :").isEqualTo(expd.get("createdBy"));

        Document actlTrnsKey = (Document) actl.get("tranKey");
        Document expdTrnsKey = (Document) expd.get("tranKey");

        soft.assertThat(actlTrnsKey.get("storeNbr")).as(trnsName + " tranKey.storeNbr is :").isEqualTo(expdTrnsKey.get("storeNbr"));
        soft.assertThat(actlTrnsKey.get("registerId")).as(trnsName + " tranKey.registerId is :").isEqualTo(expdTrnsKey.get("registerId"));

        soft.assertThat(actlTrnsKey.get("transactionNbr")).as(trnsName + " tranKey.transactionNbr is :").isNotNull();
        soft.assertThat(actlTrnsKey.get("transactionDate")).as(trnsName + " tranKey.transactionDate is :").isNotNull();
        soft.assertThat(actlTrnsKey.get("transactionTime")).as(trnsName + " tranKey.transactionTime is :").isNotNull();

        Document actlmessageDetail = (Document) actl.get("messageDetail");
        Document expdmessageDetail = (Document) expd.get("messageDetail");

        soft.assertThat(actlmessageDetail.get("fromApp")).as(trnsName + " messageDetail.fromApp is :").isEqualTo(expdmessageDetail.get("fromApp"));
        soft.assertThat(actlmessageDetail.get("topic")).as(trnsName + " messageDetail.topic is :").isEqualTo(expdmessageDetail.get("topic"));

        soft.assertThat(actlmessageDetail.get("messageId")).as(trnsName + " messageDetail.messageId is :").isNotNull();
        soft.assertThat(actlmessageDetail.get("partition")).as(trnsName + " messageDetail.partition is :").isNotNull();
        soft.assertThat(actlmessageDetail.get("offset")).as(trnsName + " messageDetail.offset is :").isNotNull();

        ArrayList<Document> actlItemsList = (ArrayList<Document>) actl.get("items");
        ArrayList<Document> expdItemsList = (ArrayList<Document>) expd.get("items");
        if (expdItemsList.size() == actlItemsList.size()) {

            for (int i = 0; i < expdItemsList.size(); i++) {
                Document expdItems = expdItemsList.get(i);
                Document actlItems = actlItemsList.get(i);
                soft.assertThat(actlItems.get("skuNbr")).as(trnsName + " items.skuNbr is :").isEqualTo(expdItems.get("skuNbr"));
                soft.assertThat(actlItems.get("deptNbr")).as(trnsName + " items.deptNbr is :").isEqualTo(expdItems.get("deptNbr"));
                soft.assertThat(actlItems.get("lineItemSeqNbr")).as(trnsName + " items.lineItemSeqNbr is :").isEqualTo(expdItems.get("lineItemSeqNbr"));
                soft.assertThat(actlItems.get("customerChargedAmt")).as(trnsName + " items.customerChargedAmt is :").isEqualTo(expdItems.get("customerChargedAmt"));
                soft.assertThat(actlItems.get("soldQuantity")).as(trnsName + " items.soldQuantity is :").isEqualTo(expdItems.get("soldQuantity"));
            }

        } else {
            soft.assertThat(actlItemsList.size()).as(trnsName + " ItemsList Size is :").isEqualTo(expdItemsList.size());
        }

        ArrayList<Document> actltendersList = (ArrayList<Document>) actl.get("tenders");
        ArrayList<Document> expdtendersList = (ArrayList<Document>) expd.get("tenders");
        if (actltendersList.size() == expdtendersList.size()) {

            for (int i = 0; i < expdtendersList.size(); i++) {
                Document expdtenders = expdtendersList.get(i);
                Document actltenders = actltendersList.get(i);
                soft.assertThat(actltenders.get("typeCode")).as(trnsName + " tenders.typeCode is :").isEqualTo(expdtenders.get("typeCode"));
                soft.assertThat(actltenders.get("amount")).as(trnsName + " tenders.amount is :").isEqualTo(expdtenders.get("amount"));

                if (expdtenders.get("accountNbr") != null)
                    soft.assertThat(actltenders.get("accountNbr")).as(trnsName + " tenders.accountNbr is :").isEqualTo(expdtenders.get("accountNbr"));

            }

        } else {
            soft.assertThat(actltendersList.size()).as(trnsName + " tendersList Size is :").isEqualTo(expdtendersList.size());
        }


        soft.assertAll();

    }

    @Step
    public static void validateActivity(JsonObject expd, JsonObject actl, JsonObject dynmc) {
        SoftAssertions soft     = new SoftAssertions();
        //String         trnsName = dynmc.get("trnsName").toString();
        String         trnsName = "Sale Transaction";
        String			fromApp	= dynmc.getAsJsonObject("messageHeader").get("fromApp").getAsString();
        
        soft.assertThat(actl.get("createdBy").getAsString()).as(trnsName + " createdBy is :").isEqualTo(fromApp);
        soft.assertThat(actl.get("loyaltyId").getAsString()).as(trnsName + " loyaltyId is :").isEqualTo(dynmc.getAsJsonObject("messageBody").get("loyaltyId").getAsString());

        //TODO
        //soft.assertThat(actl.get("_id")).as(trnsName + " ActivityID is:").isNotNull();

        soft.assertThat(actl.get("createdOn")).as(trnsName + " createdOn is :").isNotNull();
        if (fromApp.equals("OMS"))
            soft.assertThat(actl.get("orderNbr").getAsString()).as(trnsName + " orderNbr is :").isEqualTo(dynmc.getAsJsonObject("messageBody").get("orderNbr").getAsString());


        //soft.assertThat(actl.get("activityDate")).as(trnsName+" activityDate is :").isEqualTo(expd.get("activityDate"));
        //soft.assertThat(actl.get("activityTime")).as(trnsName+" activityTime is :").isEqualTo(expd.get("activityTime"));
        soft.assertThat(actl.get("activityDateTime")).as(trnsName + " activityDate is :").isNotNull();

        //Raghu - put if condition to null check
        if (expd.get("sourceSystemCode") != null)
        	soft.assertThat(actl.get("sourceSystemCode")).as(trnsName + " sourceSystemCode is :").isEqualTo(expd.get("sourceSystemCode"));
      //Raghu - put if condition to null check
        if (expd.get("fulfillment") != null)
        	soft.assertThat(actl.get("fulfillment")).as(trnsName + " fulfillment is :").isEqualTo(expd.get("fulfillment"));
        soft.assertThat(actl.get("activityTypeCode")).as(trnsName + " activityTypeCode is :").isEqualTo(expd.get("activityTypeCode"));
        soft.assertThat(actl.get("activityDesc")).as(trnsName + " activityDesc is :").isEqualTo(expd.get("activityDesc"));
        

        JsonObject actlTrnsAmount= actl.get("amount").getAsJsonObject();
        JsonObject expdTrnsAmount= expd.get("amount").getAsJsonObject();
        soft.assertThat(actlTrnsAmount.get("transactionAmt")).as(trnsName + " transactionAmt is :").isEqualTo(expdTrnsAmount.get("transactionAmt"));
        soft.assertThat(actlTrnsAmount.get("everydayKcc")).as(trnsName + " everydayKcc is :").isEqualTo(expdTrnsAmount.get("everydayKcc"));
        soft.assertThat(actlTrnsAmount.get("everydayNonkcc")).as(trnsName + " everydayNonkcc is :").isEqualTo(expdTrnsAmount.get("everydayNonkcc"));
        soft.assertThat(actlTrnsAmount.get("everydayImpactAmt")).as(trnsName + " everydayImpactAmt is :").isEqualTo(expdTrnsAmount.get("everydayImpactAmt"));
        /*soft.assertThat(actlTrnsAmount.get("everydayTotalAmt")).as(trnsName + " everydayTotalAmt is :").isEqualTo(expdTrnsAmount.get("everydayTotalAmt"));*/ /*Mahesh*/
        soft.assertThat(actlTrnsAmount.get("qualifyingAmt")).as(trnsName + " qualifyingAmt is :").isEqualTo(expdTrnsAmount.get("qualifyingAmt"));
        soft.assertThat(actlTrnsAmount.get("refundDeduction")).as(trnsName + " refundDeduction is :").isEqualTo(expdTrnsAmount.get("refundDeduction"));

        JsonObject actlTrnsKey = actl.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();
        JsonObject expdTrnsKey = expd.get("tranKeys").getAsJsonArray().get(0).getAsJsonObject();

        soft.assertThat(actlTrnsKey.get("storeNbr")).as(trnsName + " tranKey.storeNbr is :").isEqualTo(expdTrnsKey.get("storeNbr"));
        soft.assertThat(actlTrnsKey.get("registerId")).as(trnsName + " tranKey.registerId is :").isEqualTo(expdTrnsKey.get("registerId"));

        soft.assertThat(actlTrnsKey.get("transactionNbr")).as(trnsName + " tranKey.transactionNbr is :").isNotNull();
        soft.assertThat(actlTrnsKey.get("transactionDate")).as(trnsName + " tranKey.transactionDate is :").isNotNull();
        soft.assertThat(actlTrnsKey.get("transactionTime")).as(trnsName + " tranKey.transactionTime is :").isNotNull();

        System.out.println("trans assertions are complete...");

/*        JsonObject actlmessageDetail = actl.getAsJsonObject("messageDetail");
        JsonObject expdmessageDetail = expd.getAsJsonObject("messageDetail");

        soft.assertThat(actlmessageDetail.get("fromApp")).as(trnsName + " messageDetail.fromApp is :").isEqualTo(expdmessageDetail.get("fromApp"));
        soft.assertThat(actlmessageDetail.get("topic")).as(trnsName + " messageDetail.topic is :").isEqualTo(expdmessageDetail.get("topic"));
        soft.assertThat(actlmessageDetail.get("messageId")).as(trnsName + " messageDetail.messageId is :").isNotNull();
        soft.assertThat(actlmessageDetail.get("partition")).as(trnsName + " messageDetail.partition is :").isNotNull();
        soft.assertThat(actlmessageDetail.get("offset")).as(trnsName + " messageDetail.offset is :").isNotNull();
*/
        JsonArray actlItemsList =  actl.getAsJsonArray("items");
        JsonArray expdItemsList =  expd.getAsJsonArray("items");
        if (expdItemsList.size() == actlItemsList.size()) {

            for (int i = 0; i < expdItemsList.size(); i++) {
                JsonObject expdItems = expdItemsList.get(i).getAsJsonObject();
                JsonObject actlItems = actlItemsList.get(i).getAsJsonObject();
                soft.assertThat(actlItems.get("skuNbr")).as(trnsName + " items.skuNbr is :").isEqualTo(expdItems.get("skuNbr"));
                soft.assertThat(actlItems.get("deptNbr")).as(trnsName + " items.deptNbr is :").isEqualTo(expdItems.get("deptNbr"));
                soft.assertThat(actlItems.get("lineItemSeqNbr")).as(trnsName + " items.lineItemSeqNbr is :").isEqualTo(expdItems.get("lineItemSeqNbr"));
                soft.assertThat(actlItems.get("customerChargedAmt")).as(trnsName + " items.customerChargedAmt is :").isEqualTo(expdItems.get("customerChargedAmt"));
                soft.assertThat(actlItems.get("soldQuantity")).as(trnsName + " items.soldQuantity is :").isEqualTo(expdItems.get("soldQuantity"));

                System.out.println("Items assertions are complete...");
            }

        } else {
            soft.assertThat(actlItemsList.size()).as(trnsName + " ItemsList Size is :").isEqualTo(expdItemsList.size());
        }

        JsonArray actltendersList = actl.getAsJsonArray("tenders");
        JsonArray expdtendersList = expd.getAsJsonArray("tenders");
        if (actltendersList.size() == expdtendersList.size()) {

            for (int i = 0; i < expdtendersList.size(); i++) {
            	JsonObject expdtenders = expdtendersList.get(i).getAsJsonObject();
            	JsonObject actltenders = actltendersList.get(i).getAsJsonObject();
                soft.assertThat(actltenders.get("typeCode")).as(trnsName + " tenders.typeCode is :").isEqualTo(expdtenders.get("typeCode"));
                soft.assertThat(actltenders.get("amount")).as(trnsName + " tenders.amount is :").isEqualTo(expdtenders.get("amount"));

                if (expdtenders.get("accountNbr") != null)
                    soft.assertThat(actltenders.get("accountNbr")).as(trnsName + " tenders.accountNbr is :").isEqualTo(expdtenders.get("accountNbr"));

                System.out.println("tenders assertions are complete...");
            }

        } else {
            soft.assertThat(actltendersList.size()).as(trnsName + " tendersList Size is :").isEqualTo(expdtendersList.size());
        }

        JsonArray actltDeductionList = actl.getAsJsonArray("deductions");
        JsonArray expdDeductionList = expd.getAsJsonArray("deductions");

      //Raghu - put if condition to null check
        if(actltDeductionList != null && expdDeductionList != null) {
        	if (actltDeductionList.size() == expdDeductionList.size()) {

	            for (int i = 0; i < expdDeductionList.size(); i++) {
	            	JsonObject expdDeduction = expdDeductionList.get(i).getAsJsonObject();
	            	JsonObject actltDeduction = actltDeductionList.get(i).getAsJsonObject();

	            	soft.assertThat(actltDeduction.get("activityTypeCode")).as(trnsName + " Deduction.activityTypeCode is :").isEqualTo(expdDeduction.get("activityTypeCode"));
	            	soft.assertThat(actltDeduction.get("activityDesc")).as(trnsName + " Deduction.activityDesc is :").isEqualTo(expdDeduction.get("activityDesc"));
	            	soft.assertThat(actltDeduction.get("createdBy").getAsString()).as(trnsName + " Deduction.createdBy is :").isEqualTo(fromApp);
	            	soft.assertThat(actltDeduction.get("createdOn")).as(trnsName + " Deduction.createdOn is :").isNotNull();

	            	JsonObject expdamount = expdDeduction.getAsJsonObject("amount");
	            	JsonObject actlamount = actltDeduction.getAsJsonObject("amount");
	            	soft.assertThat(actlamount.get("transactionAmt")).as(trnsName + " Deduction.amount.transactionAmt is :").isEqualTo(expdamount.get("transactionAmt"));
	            	soft.assertThat(actlamount.get("everydayKcc")).as(trnsName + " Deduction.amount.everydayKcc is :").isEqualTo(expdamount.get("everydayKcc"));
	            	soft.assertThat(actlamount.get("everydayNonkcc")).as(trnsName + " Deduction.amount.everydayNonkcc is :").isEqualTo(expdamount.get("everydayNonkcc"));
                    soft.assertThat(actlamount.get("everydayImpactAmt")).as(trnsName + " Deduction.amount.everydayImpactAmt is :").isEqualTo(expdamount.get("everydayImpactAmt"));
                    /*soft.assertThat(actlamount.get("everydayTotalAmt")).as(trnsName + " Deduction.amount.everydayTotalAmt is :").isEqualTo(expdamount.get("everydayTotalAmt"));*//*Mahesh*/
	            	soft.assertThat(actlamount.get("qualifyingAmt")).as(trnsName + " Deduction.amount.qualifyingAmt is :").isEqualTo(expdamount.get("qualifyingAmt"));
	            	soft.assertThat(actlamount.get("refundDeduction")).as(trnsName + " Deduction.amount.refundDeduction is :").isEqualTo(expdamount.get("refundDeduction"));

	            	JsonObject expdtranKey = expdDeduction.getAsJsonObject("tranKey");
	            	JsonObject actltranKey = actltDeduction.getAsJsonObject("tranKey");
	                soft.assertThat(actltranKey.get("storeNbr")).as(trnsName + " Deduction.tranKey.storeNbr is :").isEqualTo(expdtranKey.get("storeNbr"));
	                soft.assertThat(actltranKey.get("registerId")).as(trnsName + " Deduction.tranKey.registerId is :").isEqualTo(expdtranKey.get("registerId"));
	                soft.assertThat(actltranKey.get("transactionNbr")).as(trnsName + " Deduction.tranKey.transactionNbr is :").isNotNull();
	                soft.assertThat(actltranKey.get("transactionDate")).as(trnsName + " Deduction.tranKey.transactionDate is :").isNotNull();
	                soft.assertThat(actltranKey.get("transactionTime")).as(trnsName + " Deduction.tranKey.transactionTime is :").isNotNull();


	                System.out.println("deductions assertions are complete...");
	            }

        	} else {
        		soft.assertThat(actltDeductionList.size()).as(trnsName + " DeductionList Size is :").isEqualTo(expdDeductionList.size());
        	}
        }


        soft.assertAll();

    }
    
    @Step
    public static JsonObject createAdjustmentPayload(JsonObject saleResp) {
        JsonObject adjustmentReq = new JsonObject();
        JsonObject body = saleResp.getAsJsonObject("messageBody");
        DecimalFormat df = new DecimalFormat("#.##");
        String adjAmt = saleResp.get("Adjustment_Amount").getAsString();
        Double adjAmtToDouble = Double.parseDouble(adjAmt);
        Double adjAmtToDouble_wo_Tol = adjAmtToDouble;
        System.out.println("The value of adjAmtToDouble is: "+adjAmtToDouble);
        adjAmtToDouble = adjAmtToDouble + 2.0;
        Double qualAmtOrig = body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble();
        adjustmentReq.addProperty(Refer_Rule_Replace_Loyalty_Id, body.get("loyaltyId").getAsString());
        adjustmentReq.addProperty(Adjustment_Amount, adjAmt);
        adjustmentReq.addProperty(Tender_Typecode, body.get("tenders").getAsJsonArray().get(0).getAsJsonObject().get("typeCode").getAsString());

        JsonObject transKey = saleResp.getAsJsonObject("messageBody").getAsJsonObject("transactionKey");
        adjustmentReq.addProperty(Rule_Replace_Transaction_Nbr, transKey.get("transactionNbr").getAsString());
        adjustmentReq.addProperty(Rule_Replace_Transaction_Date, transKey.get("transactionDate").getAsString());
        adjustmentReq.addProperty(Rule_Replace_Transaction_Time, transKey.get("transactionTime").getAsString());
        adjustmentReq.addProperty("ReplaceBarcode62486GenerateRandomNum_000", body.get("coupons").getAsJsonArray().get(0).getAsJsonObject().get("barcode").getAsString());

        //new code starts here
        if(body.get("tenders").getAsJsonArray().size() > 1)
            adjustmentReq.addProperty(Tender_Typecode, body.get("tenders").getAsJsonArray().get(1).getAsJsonObject().get("typeCode").getAsString());


        if (saleResp.get(Trans_Type).getAsString().equals("Adjustment")) {
            adjustmentReq.addProperty(Qualifying_Amount, "-" + body.get("earnDetail").getAsJsonObject().get("qualifyingAmt").getAsString());
            // new code start here
            if(body.get("tenders").getAsJsonArray().size() > 1) {
                //Double qualifying = body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble();
                adjustmentReq.addProperty(Total_1Amount, "-" + df.format((body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble() - saleResp.get("Adjustment_Amount").getAsDouble())*0.3*1.05));
                adjustmentReq.addProperty(Total_2Amount, "-" + df.format((body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble() - saleResp.get("Adjustment_Amount").getAsDouble())*0.7*1.05));

            }
            //adjustmentReq.addProperty(Total_Amount, "-" + body.get("tenders").getAsJsonArray().get(0).getAsJsonObject().get("amount").getAsString());
            adjustmentReq.addProperty(Total_Amount, "-" +df.format((body.get("earnDetail").getAsJsonObject().get("qualifyingAmt").getAsDouble() - saleResp.get("Adjustment_Amount").getAsDouble())*1.05));
            String eventAmount = body.get("coupons").getAsJsonArray().get(0).getAsJsonObject().get("eventAmount").getAsString();
            if (eventAmount.equals("0.0")) {
                adjustmentReq.addProperty("Replace_eventAmount", eventAmount);
                adjustmentReq.addProperty("Replace_StartingBal",eventAmount);
            } else {
                Double noOfCoupons = null;
                if(adjAmtToDouble >= 50.00)
                {
                    noOfCoupons = adjAmtToDouble / 50;
                    int i = noOfCoupons.intValue();
                    Double totalCouponValue = (i * 10.00);
                    totalCouponValue = Double.parseDouble(eventAmount) - totalCouponValue;
                    String totalCouponValue_str = totalCouponValue.toString();
                    adjustmentReq.addProperty("Replace_eventAmount", "-" + totalCouponValue_str);
                    adjustmentReq.addProperty("Replace_StartingBal",eventAmount);
                }else
                {
                    adjustmentReq.addProperty("Replace_eventAmount", "-" +eventAmount );
                    adjustmentReq.addProperty("Replace_StartingBal",eventAmount);
                }


            }

            String everydayKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayKccEarned").getAsString();
            if (everydayKccEarned.equals("0.0")) {
                adjustmentReq.addProperty(Everyday_Kcc_Earned, everydayKccEarned);
            } else {
                if((body.get("tenders").getAsJsonArray().size() > 1) && body.get("tenders").getAsJsonArray().get(1).getAsJsonObject().get("typeCode").getAsString().equals("04"))
                    adjustmentReq.addProperty(Everyday_Kcc_Earned, "-" + df.format(((qualAmtOrig - adjAmtToDouble_wo_Tol)*0.7) * 0.1));
                else
                    adjustmentReq.addProperty(Everyday_Kcc_Earned, "-" + df.format((qualAmtOrig - adjAmtToDouble_wo_Tol)*0.1));
             //   adjustmentReq.addProperty(Everyday_Kcc_Earned, "-" + everydayKccEarned);
            }

            String everydayNonKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayNonKccEarned").getAsString();
            if (everydayNonKccEarned.equals("0.0")) {
                adjustmentReq.addProperty(Everyday_NonKcc_Earned, everydayNonKccEarned);

            } else {
                if((body.get("tenders").getAsJsonArray().size() > 1) && body.get("tenders").getAsJsonArray().get(1).getAsJsonObject().get("typeCode").getAsString().equals("04"))
                    adjustmentReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format(((qualAmtOrig - adjAmtToDouble_wo_Tol)*0.3) * 0.05));
                else
                    adjustmentReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format((qualAmtOrig - adjAmtToDouble_wo_Tol)*0.05));
              //  adjustmentReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format((body.get("earnDetail").getAsJsonObject().get("qualifyingAmt").getAsDouble() - saleResp.get("Adjustment_Amount").getAsDouble())*0.05));
            }
            adjustmentReq.addProperty("Replace_Adj_Qual_Amt","-" +df.format((body.get("earnDetail").getAsJsonObject().get("qualifyingAmt").getAsDouble() - saleResp.get("Adjustment_Amount").getAsDouble())));
        }

   /*     if (saleResp.get(Return_Type).getAsString().equals("Partial")) {
            Double qualifying = body.get("items").getAsJsonArray().get(0).getAsJsonObject().get("customerChargedAmt").getAsDouble();
            adjustmentReq.addProperty(Qualifying_Amount, "-" + qualifying);
            adjustmentReq.addProperty(Total_Amount, "-" + df.format(qualifying + qualifying * 5 / 100));

            //Event Amount
            Double val = (qualifying + 2) / 50;
            adjustmentReq.addProperty("Replace_eventAmount", val.intValue() * 10.00);

            //EarnDetail
            String everydayKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayKccEarned").getAsString();

            if (everydayKccEarned.equals("0.0")) {
                adjustmentReq.addProperty(Everyday_Kcc_Earned, everydayKccEarned);

            } else {
                adjustmentReq.addProperty(Everyday_Kcc_Earned, "-" + df.format(qualifying * 10 / 100));
            }

            String everydayNonKccEarned = body.get("earnDetail").getAsJsonObject().get("everydayNonKccEarned").getAsString();
            if (everydayNonKccEarned.equals("0.0")) {
                adjustmentReq.addProperty(Everyday_NonKcc_Earned, everydayNonKccEarned);

            } else {
                adjustmentReq.addProperty(Everyday_NonKcc_Earned, "-" + df.format(qualifying * 5 / 100));
            }
        }
*/
        return adjustmentReq;
    }

    @Step
    public static void validateBalance(JsonObject expd, JsonObject actl) {
    	SoftAssertions soft     = new SoftAssertions();
        String         trnsName = "Return Transaction";

        soft.assertThat(actl.get("updatedBalance").getAsString()).as(trnsName + " updatedBalance is :").isEqualTo(expd.get("updatedBalance").getAsString());
        System.out.println("UpdatedBalance assertion is complete...");

        soft.assertAll();
    }
    
    @Step
    public static void validatekohlsCash(JsonArray expdList, JsonArray actlList) {
    	String         trnsName = "KohlsCash";
    	System.out.println(actlList);
    	SoftAssertions soft     = new SoftAssertions();
    	JsonObject expd = expdList.get(0).getAsJsonObject();
    	JsonObject actl = actlList.get(0).getAsJsonObject();

    	soft.assertThat(actl.get("amountApplied").getAsString()).as(trnsName + " amountApplied is :").isEqualTo(expd.get("amountApplied").getAsString());
    	soft.assertThat(actl.get("fullyAllocated").getAsString()).as(trnsName + " fullyAllocated is :").isEqualTo(expd.get("fullyAllocated").getAsString());
    	soft.assertThat(actl.get("barcode")).as(trnsName + " barcode is :").isNotNull();
    	if(expdList.size()>1) {
    		if(expdList.size() == actlList.size()) {
    		
        	JsonObject expd2 = expdList.get(1).getAsJsonObject();
        	JsonObject actl2 = actlList.get(1).getAsJsonObject();
        	soft.assertThat(actl2.get("amountApplied").getAsString()).as(trnsName + "2 amountApplied is :").isEqualTo(expd2.get("amountApplied").getAsString());
        	soft.assertThat(actl2.get("fullyAllocated").getAsString()).as(trnsName + "2 fullyAllocated is :").isEqualTo(expd2.get("fullyAllocated").getAsString());
        	soft.assertThat(actl2.get("barcode")).as(trnsName + " barcode is :").isNotNull();	
    		}else {
    			soft.assertThat(actlList.size()).as("KohlsCash Object Size").isEqualTo(expdList.size());
			}
    	}
    	
    	soft.assertAll();
    	
    }

}
