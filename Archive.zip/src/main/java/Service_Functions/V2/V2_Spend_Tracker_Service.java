package Service_Functions.V2;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;

import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.General_Purpose_Utilities.restClient_Method_Negative;
import static Utilities.UtilConstants.Spend_Tracker_Service_Url;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class V2_Spend_Tracker_Service {

	@Step
    public static JsonObject get_Spend_Tracker_Details(String data_Payload) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, "/spendTracker");
        send_This.addProperty(Reference_Api_Url, Spend_Tracker_Service_Url);
        send_This.addProperty(Reference_Payload, data_Payload);
        JsonObject response_From_Api = restClient_Method(send_This);
        return response_From_Api;
    }

	
	@Step
    public static JsonObject get_Spend_Tracker_Details_Negative(JsonObject got_Data) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, "/spendTracker");
        send_This.addProperty(Reference_Api_Url, Spend_Tracker_Service_Url);
        if(got_Data.has("Invalid_URL"))
        	send_This.addProperty(Reference_Api_Url, "Spend_Tracker_Service_Invalid");
        send_This.addProperty(Reference_Payload, got_Data.get("body_Payload").getAsString());
        
      //adding header values
        send_This.addProperty("message_Id", got_Data.get("message_Id").getAsString());
        send_This.addProperty("time_Stamp", got_Data.get("time_Stamp").getAsString());
        send_This.addProperty("system_Cd", got_Data.get("system_Cd").getAsString());
        send_This.addProperty("corrln_Id", got_Data.get("corrln_Id").getAsString());
        send_This.addProperty("API_KEY", got_Data.get("API_KEY").getAsString());
        send_This.addProperty("SecretKey", got_Data.get("SecretKey").getAsString());

        if (got_Data.toString().contains("No_Header"))
            send_This.addProperty("No_Header", "No_Header");
        if (got_Data.toString().contains("404_example"))
            send_This.addProperty("404_example", "404_example");
        if (got_Data.toString().contains("400_example"))
            send_This.addProperty("400_example", "400_example");
        if (got_Data.toString().contains("Empty_Secret"))
            send_This.addProperty("Empty_Secret", "Empty_Secret");
        if (got_Data.toString().contains("Remove_msgId"))
            send_This.addProperty("Remove_msgId", "Remove_msgId");
        if (got_Data.toString().contains("Remove_date"))
            send_This.addProperty("Remove_date", "Remove_date");
        if (got_Data.toString().contains("Invalid_MsgId"))
            send_This.addProperty("Invalid_MsgId", "Invalid_MsgId");
        if (got_Data.toString().contains("503_example"))
            send_This.addProperty("503_example", "503_example");
        
        
        
        JsonObject response_From_Api = restClient_Method_Negative(send_This);
        return response_From_Api;
    }
}
