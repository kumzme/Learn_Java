package Service_Functions.V2;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Method_Optional_Or_Negative;
import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.UtilConstants.Month_End_Service_Master_Url;
import static Utilities.UtilConstants.Month_End_Execute;
import static Utilities.UtilConstants.V2_Health_Check;
import static Utilities.UtilConstants_Data_Rules_Reference.*;

public class V2_Month_End_Functions {
    protected static final Logger logger = get_Logger();


    @Step
    public static JsonObject get_Month_End_Health_Check(JsonObject unused_For_Now) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, V2_Health_Check);
        send_This.addProperty(Reference_Api_Url, Month_End_Service_Master_Url);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }
    
    @Step
    public static JsonObject post_Month_End_Execute(String data_Payload) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, Month_End_Execute);
        send_This.addProperty(Reference_Api_Url, Month_End_Service_Master_Url);
        send_This.addProperty(Reference_Payload, data_Payload);
        send_This.addProperty(Reference_Payload, data_Payload);
        send_This.addProperty(Response_type, Text);
        JsonObject response_From_Api = restClient_Method(send_This);
        return response_From_Api;
    }


}
