package Service_Functions.V2;

import com.google.gson.JsonObject;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;

import static Utilities.General_Purpose_Utilities.get_Logger;
import static Utilities.General_Purpose_Utilities.restClient_Method_Optional_Or_Negative;
import static Utilities.UtilConstants.*;
import static Utilities.UtilConstants_Data_Rules_Reference.*;
import static Utilities.General_Purpose_Utilities.restClient_Method;
import static Utilities.General_Purpose_Utilities.restClient_Method_Neg;
import static Utilities.General_Purpose_Utilities.restClient_Method_Negative;
import static org.junit.Assert.assertTrue;
import static Utilities.UtilConstants.Audit_Balance_Service_Url;

public class V2_Rule_Config_Functions {
    protected static final Logger logger = get_Logger();


    @Step
    public static JsonObject get_Rule_Config_Health_Check(JsonObject unused_For_Now) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, V2_Health_Check_Actuator);
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject post_Rule_Config(String data_Payload) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Payload, data_Payload);
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service );
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject post_Rule_Config_Neg(JsonObject send_This) throws Exception {

        //  JsonObject send_This = new JsonObject();
        //   send_This.addProperty(Reference_Payload, data_Payload);
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service );
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_latest_Rule_Config() throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + "latest");
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        send_This.addProperty(Response_type, "Text");
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_RuleConfig_by_id(String rule_id) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + rule_id);
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_everydayRule() throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + Rule_Config_everyday);
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject post_Invalid_Rule_Config(String data_Payload) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Payload, data_Payload);
        send_This.addProperty(Reference_Method, Reference_Method_Post);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service );
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url_Invalid);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);

        return response_From_Api;
    }

    @Step
    public static JsonObject get_Rule_Config_Details_Negative(JsonObject got_Data,String url) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        if(url.contains("/rules/rulenumber")) {
            send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + got_Data.get("rule_Id").getAsString());
        }
        else if(url.contains("/rules/latest")) {
            send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + "latest");
            send_This.addProperty(Response_type, "Text");
        }
        else if(url.contains("/geteverdayrule")) {
            send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + "everyday");
        }
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        send_This.addProperty(Reference_Payload, got_Data.get("body_Payload").getAsString());

        //adding header values
        send_This.addProperty("message_Id", got_Data.get("message_Id").getAsString());
        send_This.addProperty("time_Stamp", got_Data.get("time_Stamp").getAsString());
        send_This.addProperty("system_Cd", got_Data.get("system_Cd").getAsString());
        send_This.addProperty("corrln_Id", got_Data.get("corrln_Id").getAsString());
        send_This.addProperty("API_KEY", got_Data.get("API_KEY").getAsString());
        send_This.addProperty("SecretKey", got_Data.get("SecretKey").getAsString());

        if (got_Data.toString().contains("No_Header"))
            send_This.addProperty("No_Header", "No_Header");
        if (got_Data.toString().contains("404_example"))
            send_This.addProperty("404_example", "404_example");
        if (got_Data.toString().contains("400_example"))
            send_This.addProperty("400_example", "400_example");
        if (got_Data.toString().contains("Empty_Secret"))
            send_This.addProperty("Empty_Secret", "Empty_Secret");
        if (got_Data.toString().contains("Remove_msgId"))
            send_This.addProperty("Remove_msgId", "Remove_msgId");
        if (got_Data.toString().contains("Remove_date"))
            send_This.addProperty("Remove_date", "Remove_date");
        if (got_Data.toString().contains("Invalid_MsgId"))
            send_This.addProperty("Invalid_MsgId", "Invalid_MsgId");
        if (got_Data.toString().contains("503_example"))
            send_This.addProperty("503_example", "503_example");
        if(got_Data.has("Invalid_API_KEY"))
            send_This.addProperty("Invalid_API_KEY", "Invalid_API_KEY");
        if(got_Data.has("200_example"))
            send_This.addProperty("200_example", "200_example");
        if (got_Data.toString().contains("401_example"))
            send_This.addProperty("401_example", "401_example");



        JsonObject response_From_Api = restClient_Method_Negative(send_This);
        return response_From_Api;
    }

    public static void validateRuleConfigResponse(JsonObject getRulebyId,JsonObject result_Json)
    {
        String actEventId = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("eventId").getAsString();
        String expEventId = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("eventId").getAsString();
        assertTrue(expEventId.equals(actEventId));

        String actEventName = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("eventName").getAsString();
        String expEventName = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("eventName").getAsString();
        assertTrue(expEventName.equals(actEventName));

        String actStartDate = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("startDate").getAsString();
        String expStartDate = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("startDate").getAsString();
        assertTrue(expStartDate.equals(actStartDate));

        String actEndDate = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("endDate").getAsString();
        String expEndDate = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("endDate").getAsString();
        assertTrue(expEndDate.equals(actEndDate));

        String actualdefaultNonKccPercent = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("defaultNonKccPercent").getAsString();
        String expdefaultNonKccPercent = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("defaultNonKccPercent").getAsString();
        assertTrue(expdefaultNonKccPercent.equals(actualdefaultNonKccPercent));

        String actualdefaultKccPercent = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("defaultKccPercent").getAsString();
        String expdefaultKccPercent = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("defaultKccPercent").getAsString();
        assertTrue(expdefaultKccPercent.equals(actualdefaultKccPercent));

        String actualEarnRuleNonKccPercent = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("nonKccPercent").getAsString();
        String expectEarnRuleNonKccPercent = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("nonKccPercent").getAsString();
        assertTrue(expectEarnRuleNonKccPercent.equals(actualEarnRuleNonKccPercent));

        String actualEarnRuleKccPercent = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("kccPercent").getAsString();
        String expectEarnRuleKccPercent = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("kccPercent").getAsString();
        assertTrue(expectEarnRuleKccPercent.equals(actualEarnRuleKccPercent));

        String actualEarnRuleStartDate = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("startDate").getAsString();
        String expectEarnRuleStartDate = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("startDate").getAsString();
        assertTrue(expectEarnRuleStartDate.equals(actualEarnRuleStartDate));

        String actualEarnRuleEndDate = getRulebyId.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("endDate").getAsString();
        String expectEarnRuleEndDate = result_Json.get("Response_Body").getAsJsonObject().get("eventRule").getAsJsonArray().get(0).getAsJsonObject().get("earnRules").getAsJsonArray().get(0).getAsJsonObject().get("endDate").getAsString();
        assertTrue(expectEarnRuleEndDate.equals(actualEarnRuleEndDate));

    }

    @Step
    public static JsonObject get_latest_Rule_Config_Invalid() throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + "latest");
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url_Invalid);
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_RuleConfig_by_id_Invalid(String rule_id) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + rule_id);
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url_Invalid);
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_everydayRule_Invalid() throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + "/" + "geteverydayrule");
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url_Invalid);
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_latest_Invaid_Rule_Config(String serviceType) throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + serviceType);
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        send_This.addProperty(Response_type, "Text");
        //  JsonObject response_From_Api = restClient_Method(send_This);
        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    public static JsonObject get_Rule_Config_all_rules() throws Exception {

        JsonObject send_This = new JsonObject();
        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service );
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        //   send_This.addProperty(Response_type, "Text");

        JsonObject response_From_Api = restClient_Method_Optional_Or_Negative(send_This);
        return response_From_Api;
    }

    @Step
    public static JsonObject get_Rule_Config_missing_header(JsonObject send_This) throws Exception {

        //  JsonObject send_This = new JsonObject();
        //   send_This.addProperty(Reference_Payload, data_Payload);
        String resource = send_This.get("resource_url").getAsString();
        if (resource.contains("latest")) {
            resource = "/latest";
            send_This.addProperty(Response_type, "Text");
        }
        else if (resource.contains("rulenumber"))
            resource = "/" + send_This.get("rulenumber").getAsString();
        else if(resource.contains("everyday"))
            resource = "/everyday";

        send_This.addProperty(Reference_Method, Reference_Method_Get);
        send_This.addProperty(Reference_Api_Path, Rule_Config_service + resource );
        send_This.addProperty(Reference_Api_Url, Rule_Config_Service_Master_Url);
        JsonObject response_From_Api = restClient_Method_Neg(send_This);
        return response_From_Api;
    }
}
