package Invoker;

public class Parellel {
}
