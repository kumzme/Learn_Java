package Invoker;

import Step_Defs.XHooks.Project_Before_Hooks;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static Utilities.General_Purpose_Utilities.get_Logger;


@RunWith(JUnit4.class)
public class invoke_This_Project_For_All_Services_Test {
    final Logger logger = get_Logger();

    //Team Notes:: Pls Manage which project you are invoking using profiles and Cucumber tags.
    //Todo::  This  Class should be below a wrapper doing parallel runs
    //                  Parallel runs should be directed using the tags in the above mentioned class using a combination Yaml file + Cucumber tags.

    public void invoker() throws Exception {

        /* create_Clean_Directory(); String[] cucke_Options = get_Cucumber_Options(); String allure_Dir  = get_Allure_Reports_Directory(); ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader(); if (allure_Dir != null) System.setProperty("allure.results.directory", allure_Dir); //logger.info("Run with these cuke options:: " + cucke_Options); byte exitstatus = cucumber.api.cli.Main.run(cucke_Options, contextClassLoader); */

        byte exitstatus = Project_Before_Hooks.invoke_Project();
        if (exitstatus > 0)
            throw new Exception("Test QA Build Failed with bad return code :: Pls check the test results report/Allure?:: Exit Code - " + exitstatus);

    }


    //public static void main(String[] args) throws Exception {
    @Test
    public void main() throws Exception {

        /* create_Clean_Directory(); String[] cucke_Options = get_Cucumber_Options(); String allure_Dir  = get_Allure_Reports_Directory(); ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader(); if (allure_Dir != null) System.setProperty("allure.results.directory", allure_Dir); //logger.info("Run with these cuke options:: " + cucke_Options); byte exitstatus = cucumber.api.cli.Main.run(cucke_Options, contextClassLoader); */

        byte exitstatus = Project_Before_Hooks.invoke_Project();
        if (exitstatus > 0) throw new Exception("Test QA Build Failed with bad return code :: Pls check the test results report/Allure?:: Exit Code - " + exitstatus);

    }

}
